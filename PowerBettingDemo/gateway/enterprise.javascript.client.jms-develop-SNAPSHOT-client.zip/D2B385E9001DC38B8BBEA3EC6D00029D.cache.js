(function(){var $gwt_version = "2.5.1";var $wnd = window;var $doc = $wnd.document;var $moduleName, $moduleBase;var $strongName = 'D2B385E9001DC38B8BBEA3EC6D00029D';var $stats = $wnd.__gwtStatsEvent ? function(a) {return $wnd.__gwtStatsEvent(a);} : null;var $sessionId = $wnd.__gwtStatsSessionId ? $wnd.__gwtStatsSessionId : null;$stats && $stats({moduleName:'JmsClient',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalStart'});function VP(){}
function Sc(){}
function dd(){}
function kd(){}
function Kd(){}
function Rd(){}
function RA(){}
function NA(){}
function Tj(){}
function jk(){}
function Ck(){}
function pr(){}
function sr(){}
function Xu(){}
function uv(){}
function UB(){}
function eE(){}
function HG(){}
function GJ(){}
function cO(){}
function hO(){}
function mO(){}
function tO(){}
function uk(){tk()}
function wn(){rn()}
function cn(a){an(a.b)}
function ln(a){jn(a.b)}
function fl(a,b){a.b=b}
function gl(a,b){a.c=b}
function id(a,b){a.c=b}
function il(a,b){a.e=b}
function hl(a,b){a.d=b}
function mo(a,b){a.b=b}
function no(a,b){a.c=b}
function po(a,b){a.i=b}
function qo(a,b){a.j=b}
function ro(a,b){a.k=b}
function so(a,b){a.n=b}
function to(a,b){a.o=b}
function uo(a,b){a.p=b}
function vo(a,b){a.q=b}
function lr(a,b){a.B=b}
function rr(a,b){a.b=b}
function xr(a,b){a.g=b}
function hs(a,b){a.f=b}
function is(a,b){a.i=b}
function js(a,b){a.o=b}
function ks(a,b){a.p=b}
function ms(a,b){a.s=b}
function ns(a,b){a.v=b}
function os(a,b){a.x=b}
function rs(a,b){a.w=b}
function _w(a,b){a.g=b}
function _y(a,b){a.r=b}
function $y(a,b){a.p=b}
function yA(a,b){a.b=b}
function XA(a,b){a.g=b}
function VC(a,b){a.g=b}
function CC(a,b){a.c=b}
function UC(a,b){a.d=b}
function ED(a,b){a.j=b}
function mH(a,b){a.b=b}
function np(){So(this)}
function op(){So(this)}
function oK(){Xc(this)}
function iK(){Xc(this)}
function lK(){Xc(this)}
function PK(){Xc(this)}
function UI(){Xc(this)}
function QJ(){Xc(this)}
function _L(){Xc(this)}
function EP(){Xc(this)}
function QL(){OL(this)}
function XL(){UL(this)}
function zN(){oN(this)}
function cl(a){this.b=a}
function rl(a){this.b=a}
function tl(a){this.b=a}
function _l(a){this.b=a}
function em(a){this.b=a}
function $m(a){this.b=a}
function en(a){this.b=a}
function nn(a){this.b=a}
function dr(a){this.b=a}
function Nu(a){this.b=a}
function hv(a){this.b=a}
function jv(a){this.b=a}
function Qw(a){this.b=a}
function Dx(a){this.b=a}
function Zx(a){this.d=a}
function gy(a){this.d=a}
function jy(a){this.d=a}
function my(a){this.d=a}
function TA(a){this.b=a}
function TJ(a){this.b=a}
function lJ(a){this.b=a}
function vJ(a){this.b=a}
function ZD(a){this.b=a}
function cH(a){this.b=a}
function hH(a){this.b=a}
function nH(a){this.b=a}
function bK(a){this.b=a}
function sK(a){this.b=a}
function FK(a){this.b=a}
function aL(a){this.b=a}
function gM(a){this.b=a}
function vM(a){this.b=a}
function ZM(a){this.b=a}
function IM(a){this.e=a}
function EG(a){this.c=a}
function DI(a){this.c=a}
function jN(a){this.b=a}
function $N(a){this.b=a}
function fP(a){this.b=a}
function td(){this.b=++qd}
function yr(){this.g=null}
function rn(){rn=VP;_k()}
function KI(a){JI&&dH(a)}
function wr(a,b){a.g.od(b)}
function vr(a,b){aB(a.e,b)}
function Hr(a,b){wO(a.b,b)}
function Pr(a,b){yO(a.b,b)}
function jl(a,b){yl(a.f,b)}
function ju(a,b){tD(a.g,b)}
function ru(a,b){Pr(a.c,b)}
function sA(a,b){lu(a.c,b)}
function uA(a,b){ou(a.c,b)}
function mA(a,b){ZF(a.b,b)}
function qA(a,b){gG(a.b,b)}
function aB(a,b){ju(a.b,b)}
function RB(a,b){oI(a.b,b)}
function dB(a,b){xr(a.e,b)}
function wC(a,b){xD(a.c,b)}
function AC(a,b){jG(a.d,b)}
function Xy(a,b){BH(a.n,b)}
function cd(a,b){a.b+=b}
function cB(a,b){a.c.Od(b)}
function _D(a){ar(a.c,a.b)}
function OL(a){a.b=new dd}
function UL(a){a.b=new dd}
function qv(){this.b=new np}
function BI(){this.b=new np}
function zO(){this.b=new np}
function AO(){this.b=new op}
function CH(){this.b=new zN}
function IP(){this.b=new zN}
function Xk(){Xk=VP;Wk=_k()}
function YF(){YF=VP;XF=_k()}
function qH(){qH=VP;pH=_k()}
function HI(){HI=VP;GI=_k()}
function yI(){uI.call(this)}
function Im(a,b){a.gc(xj(b))}
function Jm(a,b){a.lc(xj(b))}
function Mm(a,b){Mx(a,xj(b))}
function Mx(a,b){Hx(a);a.f=b}
function Rv(a,b){b.f=a;a.g=b}
function ar(a,b){a.e=b;_q(a)}
function br(a,b){a.c=b;_q(a)}
function Jk(b,a){b.limit=a}
function ts(a){bs();this.d=a}
function Kv(a){ak();this.b=a}
function $C(a){ak();this.b=a}
function eD(a){ak();this.b=a}
function hD(a){ak();this.b=a}
function LD(a){ak();this.b=a}
function OD(a){ak();this.b=a}
function $I(a){YI();this.b=a}
function Aq(){yq();return Bp}
function Oq(){Mq();return Cq}
function VF(){TF();return MF}
function Pc(){Pc=VP;Oc=new Sc}
function tk(){tk=VP;sk=new td}
function rO(){rO=VP;qO=new tO}
function mv(){mv=VP;lv=new qv}
function YB(){YB=VP;XB=new HG}
function AB(){AB=VP;bs();_k()}
function Bx(){Ax.call(this,1)}
function kA(){Ax.call(this,0)}
function PA(){Ax.call(this,4)}
function kD(){Ax.call(this,4)}
function lc(a){ic.call(this,a)}
function mc(a){lc.call(this,a)}
function vl(a){lc.call(this,a)}
function Jl(a){Gl.call(this,a)}
function Ll(a){Gl.call(this,a)}
function Rl(a){Gl.call(this,a)}
function Vl(a){Gl.call(this,a)}
function Xl(a){Gl.call(this,a)}
function Gn(a){Gl.call(this,a)}
function Hn(a){Hl.call(this,a)}
function Sq(a){Gl.call(this,a)}
function Xq(a){Rq.call(this,a)}
function Yq(a){Sq.call(this,a)}
function hr(a){Sq.call(this,a)}
function Qd(a){Nd.call(this,a)}
function Ev(a){Av.call(this,a)}
function Hv(a){Ev.call(this,a)}
function by(a){Av.call(this,a)}
function aH(a){Sq.call(this,a)}
function $J(a){ic.call(this,a)}
function jK(a){mc.call(this,a)}
function mK(a){mc.call(this,a)}
function pK(a){mc.call(this,a)}
function QK(a){mc.call(this,a)}
function ZK(a){jK.call(this,a)}
function aM(a){mc.call(this,a)}
function Nl(){Gl.call(this,UQ)}
function FC(){Ax.call(this,-1)}
function $z(a){Zz(a);jn(a.c.b)}
function nA(a,b,c){$F(a.b,b,c)}
function oA(a,b,c){cG(a.b,b,c)}
function pA(a,b,c){dG(a.b,b,c)}
function xA(a,b,c){kG(a.b,b,c)}
function zA(a,b,c){qG(a.b,b,c)}
function vp(a,b){return a.c-b.c}
function uJ(a,b){return a.b-b.b}
function Bj(a,b){return !Aj(a,b)}
function Cj(a,b){return !zj(a,b)}
function qm(a){return Kj(a.Nb())}
function rm(a){return Kj(a.Sb())}
function Xj(a){return new Vj[a]}
function Lk(b,a){return b.put(a)}
function Kk(b,a){b.position=a}
function ic(a){Xc(this);this.g=a}
function LB(a){Sv.call(this,a,1)}
function BE(){vE.call(this,1,YQ)}
function KE(){vE.call(this,2,fT)}
function PE(){vE.call(this,4,gT)}
function bF(){vE.call(this,7,hT)}
function hF(){vE.call(this,8,iT)}
function ss(){ts.call(this,null)}
function BP(){this.b=this.c=this}
function cC(){YB();this.c=new zN}
function uC(a){zx(a.b,2);vD(a.c)}
function qI(a){a.b=new BP;a.c=0}
function Vx(a,b){a.b.b||oI(a.c,b)}
function zH(a,b){return tN(a.b,b)}
function RM(a,b){return a.b.$c(b)}
function xO(a,b){return a.b.$c(b)}
function HO(a,b){return a.d.$c(b)}
function HP(a,b){return qN(a.b,b)}
function Lj(a){return a.l|a.m<<22}
function Xo(b,a){return b.j[nS+a]}
function VG(a,b){SC(a.c,al(b.b))}
function JN(a,b,c){a.splice(b,c)}
function dm(a,b){a.onException(b)}
function zq(a,b){wp.call(this,a,b)}
function Nq(a,b){wp.call(this,a,b)}
function xF(){vE.call(this,11,KQ)}
function pp(a){So(this);Ho(this,a)}
function wp(a,b){this.b=a;this.c=b}
function lx(a,b){this.b=a;this.c=b}
function rx(a,b){this.b=a;this.c=b}
function ty(a,b){this.b=a;this.c=b}
function Pz(a,b){this.b=a;this.c=b}
function dA(a,b){this.b=a;this.c=b}
function bD(a,b){this.b=a;this.c=b}
function SD(a,b){this.d=a;this.c=b}
function vE(a,b){this.b=a;this.c=b}
function aE(a,b){this.c=a;this.b=b}
function Fz(a,b){this.c=a;this.b=b}
function AM(a,b){this.c=a;this.b=b}
function BG(a,b){this.b=a;this.c=b}
function TM(a,b){this.b=a;this.c=b}
function dN(a,b){this.b=a;this.c=b}
function mF(a,b){vE.call(this,a,b)}
function UF(a,b){wp.call(this,a,b)}
function qy(a,b){oy(a,new ty(a,b))}
function Au(a){a.b=new BN(Io(a.p))}
function Zu(){this.b=new BI;new np}
function YO(a,b){this.e=a;this.f=b}
function FM(a){return a.c<a.e.cd()}
function Yk(b,a){return b.decode(a)}
function Ok(b,a){return b.putInt(a)}
function xm(a){return Hx(a),Kj(a.f)}
function AH(a,b){return uN(a.b,b,0)}
function SJ(a,b){return UJ(a.b,b.b)}
function PL(a,b){cd(a.b,b);return a}
function lH(a){a.b=a.b+1;return a.b}
function VL(a,b){cd(a.b,b);return a}
function WG(a){xl(a.f.f,TQ);TC(a.c)}
function IC(a){a.f||!!a.c&&RG(a.c)}
function oN(a){a.b=Vd($i,cQ,0,0,0)}
function xN(a){return Sd(a.b,0,a.c)}
function ie(a){return a==null?null:a}
function dk(a){$wnd.clearInterval(a)}
function ek(a){$wnd.clearTimeout(a)}
function Lc(a){$wnd.clearTimeout(a)}
function Ct(){Ct=VP;bs();Bt=_k()}
function JL(){JL=VP;GL={};IL={}}
function RL(){OL(this);this.b.b+=qS}
function YL(a){UL(this);cd(this.b,a)}
function ll(a,b){this.f=Al(this,a,b)}
function SC(a,b){qy(a.n,new bD(a,b))}
function sG(a,b){qy(a.s,new BG(a,b))}
function KN(a,b,c,d){a.splice(b,c,d)}
function pI(a,b,c){new CP(b,c);++a.c}
function ce(a,b){return a.cM&&a.cM[b]}
function vj(a,b){return jj(a,b,false)}
function hj(a){return ij(a.l,a.m,a.h)}
function pL(b,a){return b.indexOf(a)}
function Hk(b,a){return b.getBytes(a)}
function Nk(b,a){return b.putBytes(a)}
function Qk(b,a){return b.putShort(a)}
function jJ(a,b){return parseInt(a,b)}
function NK(a,b){return Math.pow(a,b)}
function WL(a,b){return vL(a.b.b,0,b)}
function xL(a){return Vd(bj,dQ,1,a,0)}
function RD(a){SD.call(this,a,new eE)}
function YE(){vE.call(this,6,'float')}
function cs(a){if(a.y){throw new Tl}}
function sP(a){if(!a.d){throw new lK}}
function ok(){if(!kk){zk();kk=true}}
function KO(a,b){if(a.b){bP(b);aP(b)}}
function bI(a,b){(a<0||a>=b)&&eI(a,b)}
function rA(a,b){a.g=new MO;ku(a.c,b)}
function uI(){this.b=new BP;this.c=0}
function SB(a){this.b=new uI;this.c=a}
function lP(a){this.d=a;this.c=a.b.c.b}
function AN(){oN(this);this.b.length=0}
function su(a){uu(a.b);tu(a.n);tu(a.p)}
function Kc(a){return a.$H||(a.$H=++Cc)}
function he(a){return a.tM==VP||be(a,1)}
function Ik(b,a){return b.getString(a)}
function Mk(c,a,b){return c.putAt(a,b)}
function $k(c,a,b){return c.encode(a,b)}
function mL(b,a){return b.charCodeAt(a)}
function be(a,b){return a.cM&&!!a.cM[b]}
function yO(a,b){return a.b.id(b)!=null}
function MJ(a){return typeof a==ZQ&&a>0}
function tc(a){return ge(a)?Yc(ee(a)):IQ}
function fe(a,b){return a!=null&&be(a,b)}
function Nv(a,b){ak();this.c=a;this.b=b}
function kl(a,b,c){this.f=Bl(this,a,b,c)}
function GE(){vE.call(this,3,'byte[]')}
function UE(){vE.call(this,5,'double')}
function sF(){vE.call(this,10,'short')}
function jn(a){a.callback&&a.callback()}
function cr(a,b){a.c=b;ck(new Nv(a,b),1)}
function qL(c,a,b){return c.indexOf(a,b)}
function ZA(a,b,c){return $A(a.Ld(),b,c)}
function Uw(a,b,c){c?Vx(a.q,b):Vx(a.n,b)}
function tN(a,b){bI(b,a.c);return a.b[b]}
function hA(a){oI(a.d.B,a.c);Yw(a.b,a.c)}
function BD(a){if(a.p){_q(a.p);a.p=null}}
function tI(a){if(a.c==0){throw new EP}}
function Qr(){yr.call(this);this.b=new zO}
function cP(a){dP.call(this,a,null,null)}
function sN(a){a.b=Vd($i,cQ,0,0,0);a.c=0}
function sJ(){sJ=VP;rJ=Vd(Wi,jQ,55,256,0)}
function EJ(){EJ=VP;DJ=Vd(Xi,jQ,58,128,0)}
function MK(){MK=VP;LK=Vd(Zi,jQ,68,256,0)}
function CK(){CK=VP;BK=Vd(Yi,jQ,67,256,0)}
function hL(){hL=VP;gL=Vd(_i,jQ,71,256,0)}
function ak(){ak=VP;_j=new zN;mk(new jk)}
function XN(){XN=VP;VN=new cO;WN=new hO}
function yk(){this.b=new Id;this.c=null}
function Id(){this.e=new np;this.d=false}
function JP(a){this.b=new zN;rN(this.b,a)}
function Gl(a){lc.call(this,a);this.b=null}
function nc(a,b){Xc(this);this.f=b;this.g=a}
function Fd(a,b){var c;c=Gd(a,b);return c}
function Km(a,b,c){var d;d=xj(c);qw(a,b,d)}
function Lm(a,b,c){var d;d=xj(c);a.nc(b,d)}
function zx(a,b){var c;c=kH(a.b,b);return c}
function kH(a,b){var c;c=a.b;a.b=b;return c}
function ZI(a,b){return a.b==b.b?0:a.b?1:-1}
function vL(c,a,b){return c.substr(a,b-a)}
function Pk(c,a,b){return c.putIntAt(a,b)}
function Rk(c,a,b){return c.putShortAt(a,b)}
function Sk(c,a,b){return c.putString(a,b)}
function Fc(a,b,c){return a.apply(b,c);var d}
function pc(a){return ge(a)?qc(ee(a)):a+IQ}
function kC(a,b){return de(a.b.ad(qJ(b)),50)}
function sc(a){return a==null?null:a.name}
function qc(a){return a==null?null:a.message}
function FL(a){return String.fromCharCode(a)}
function Bm(a,b){JI&&dH(FR);return a.rc(b)}
function qN(a,b){Xd(a.b,a.c++,b);return true}
function XO(a,b){var c;c=a.f;a.f=b;return c}
function gH(a){var b;b=a.b;a.b=true;return b}
function LJ(a){var b=Vj[a.d];a=null;return b}
function WA(a){a.j==0&&(a.j=VA++);return a.j}
function Zc(){try{null.a()}catch(a){return a}}
function bk(a){a.d?dk(a.e):ek(a.e);wN(_j,a)}
function Ad(a,b){!a.b&&(a.b=new zN);qN(a.b,b)}
function md(a){var b;if(jd){b=new kd;wd(a,b)}}
function xc(a){var b;return b=a,he(b)?b.cZ:qe}
function vd(a,b,c){return new Kd(Bd(a.b,b,c))}
function Tk(b,a){return b.putUnsignedShort(a)}
function ox(a,b,c){this.b=a;this.c=b;this.d=c}
function ux(a,b,c){this.b=a;this.d=b;this.c=c}
function _z(a,b,c){this.b=a;this.d=b;this.c=c}
function WD(a,b,c){this.b=a;this.d=b;this.c=c}
function YG(a,b,c){this.b=a;this.d=b;this.e=c}
function yG(a,b,c){this.b=a;this.c=b;this.d=c}
function tP(a,b,c){this.e=a;this.c=c;this.b=b}
function Sv(a,b){yr.call(this);a.b=b;this.d=a}
function SI(){mc.call(this,'divide by zero')}
function mC(){YB();cC.call(this);this.b=new np}
function AP(a){a.b.c=a.c;a.c.b=a.b;a.b=a.c=a}
function kJ(a,b){return a.b<b.b?-1:a.b>b.b?1:0}
function aK(a,b){return a.b<b.b?-1:a.b>b.b?1:0}
function rK(a,b){return a.b<b.b?-1:a.b>b.b?1:0}
function _K(a,b){return a.b<b.b?-1:a.b>b.b?1:0}
function uL(b,a){return b.substr(a,b.length-a)}
function sm(a,b){var c;c=mw(a,b);return Kj(c)}
function tm(a,b){var c;c=a.Ub(b);return Kj(c)}
function Cd(a,b,c,d){var e;e=Ed(a,b,c);e.ge(d)}
function Py(a,b){oI(a.o,b);Ym(a.k,b);Ry(a,b)}
function bn(a,b){dn(a.b,Om(b,wm(b),null.ze()))}
function Ax(a){this.b=new nH(-1);mH(this.b,a)}
function BB(a){AB();ts.call(this,a);this.y=true}
function bP(a){a.b.c=a.c;a.c.b=a.b;a.b=a.c=null}
function $w(a){return a.q.c.c==0?Wx(a.n):Wx(a.q)}
function Vk(a){return Kaazing.ByteBuffer.wrap(a)}
function _k(){Xk();return Kaazing.Charset.UTF8}
function pk(){kk&&md((!lk&&(lk=new yk),lk))}
function Xx(){this.c=new yI;this.b=new hH(false)}
function ry(){this.c=new hH(false);this.b=new uI}
function oI(a,b){new CP(b,a.b);++a.c;return true}
function RH(a,b){var c;c=QH(a.he(),b);return !!c}
function SM(a){var b;b=a.c.he();return new ZM(b)}
function cN(a){var b;b=a.c.he();return new jN(b)}
function Io(a){var b;b=a._c();return new dN(a,b)}
function Go(a){var b;b=a._c();return new TM(a,b)}
function uD(a){a.g?rD(a,new Nl):tD(a,new Jl(eT))}
function TH(a){return a.ne(Vd($i,cQ,0,a.cd(),0))}
function ge(a){return a!=null&&a.tM!=VP&&!be(a,1)}
function mk(a){ok();return nk(jd?jd:(jd=new td),a)}
function yc(a){var b;return b=a,he(b)?b.hC():Kc(b)}
function rD(a,b){var c;c=a.g;a.g=null;c.c=b;_q(c)}
function yv(a,b){yH(a.c,b);a.c.b.c==1&&a.f.Pd(a.d)}
function uj(a,b){return ij(a.l&b.l,a.m&b.m,a.h&b.h)}
function Gj(a,b){return ij(a.l|b.l,a.m|b.m,a.h|b.h)}
function Zl(a,b){a.value=b;a.callback&&a.callback()}
function Zm(a,b){a.onMessage!==null&&a.onMessage(b)}
function Zz(a){a.b.e=null;a.b.A.id(a.d);a.b.z=null}
function ke(a){if(a!=null){throw new QJ}return null}
function Tc(a,b){!a&&(a=[]);a[a.length]=b;return a}
function oc(a){Xc(this);this.c=a;this.b=IQ;Wc(this)}
function Hl(a){lc.call(this,a);this.c=a;this.b=null}
function Av(a){yr.call(this);this.c=new CH;this.d=a}
function Nd(a){nc.call(this,Pd(a),Od(a));this.b=a}
function jL(a){this.b='Unknown';this.d=a;this.c=-1}
function ML(){if(HL==256){GL=IL;IL={};HL=0}++HL}
function $d(){$d=VP;Yd=[];Zd=[];_d(new Rd,Yd,Zd)}
function nw(a){var b;b=SM(Go(a.b));return new Qw(b)}
function AI(a){var b;b=TH(Io(a.b));return new DI(b)}
function wO(a,b){var c;c=a.b.bd(b,a);return c==null}
function Vc(a,b){a.length>=b&&a.splice(0,b);return a}
function yH(a,b){return qN((a.b=new BN(a.b),a.b),b)}
function BH(a,b){return wN((a.b=new BN(a.b),a.b),b)}
function wj(a,b){return a.l==b.l&&a.m==b.m&&a.h==b.h}
function Fj(a,b){return a.l!=b.l||a.m!=b.m||a.h!=b.h}
function DD(a,b){wO(a.o,b);b.y||(a.n=true);cu(a.f,b)}
function zC(a,b){b.e==(yq(),Ip)&&zx(a.b,0);iG(a.d,b)}
function nk(a,b){return vd((!lk&&(lk=new yk),lk),a,b)}
function wl(b,a){return b.setDefaultConnectTimeout(a)}
function Rm(a){return new Kaazing.JMS.Queue(peer(a))}
function Vm(a){return new Kaazing.JMS.Topic(peer(a))}
function an(a){a.value=null;a.callback&&a.callback()}
function So(a){a.e=[];a.j={};a.g=false;a.f=null;a.i=0}
function YI(){YI=VP;WI=new $I(false);XI=new $I(true)}
function xD(a,b){a.g?rD(a,new Yq(b)):tD(a,new Jl(eT))}
function TN(a,b){RN(a,0,a.length,b?b:(rO(),rO(),qO))}
function jC(a,b,c){qN(a.c,c);a.b.bd(qJ(b),c);return c}
function iN(a){var b;b=de(a.b.se(),78).ve();return b}
function YM(a){var b;b=de(a.b.se(),78);return b.ue()}
function YN(a){XN();var b;b=new IM(a);return new $N(b)}
function ej(a){if(fe(a,74)){return a}return new oc(a)}
function zm(a){if(xc(a)==Dh){return true}return false}
function ls(a,b){if(b<0||b>9){throw new Gl(wS+b)}a.q=b}
function wc(a,b){var c;return c=a,he(c)?c.eQ(b):c===b}
function EK(a,b){return Bj(a.b,b.b)?-1:zj(a.b,b.b)?1:0}
function ij(a,b,c){return _=new Tj,_.l=a,_.m=b,_.h=c,_}
function Pm(a){return new Kaazing.JMS.Message(peer(a))}
function FP(a,b){return ie(a)===ie(b)||a!=null&&wc(a,b)}
function eI(a,b){throw new pK('Index: '+a+', Size: '+b)}
function Kx(a){try{ck(new Kv(a.i),1)}finally{a.i=null}}
function AA(){this.g=new MO;this.f=new PA;this.d=new uI}
function xo(a){lo();this.e=a;this.g=new np;this.d=new AO}
function iA(a,b,c){this.d=a;this.b=b;this.c=c;c.Hd(this)}
function FD(a){zy();this.o=new zO;this.k=new Zu;this.c=a}
function Ek(a,b,c){this.b=a;this.e=b;this.d=null;this.c=c}
function Lx(a,b){try{cr(a.i,new Gl(b))}finally{a.i=null}}
function $l(a,b){a.exception=b;a.callback&&a.callback()}
function dn(a,b){a.exception=b;a.callback&&a.callback()}
function mn(a,b){a.exception=b;a.callback&&a.callback()}
function RN(a,b,c,d){var e;e=Sd(a,b,c);SN(e,a,b,c,-b,d)}
function Dm(a,b,c,d,e,f,g){return Jx(a,b,c,d,e,xj(f),g)}
function NB(a,b,c,d,e,f){ax.call(this,a,c,d,e,f);this.b=b}
function Pl(){Gl.call(this,'Reached end of BytesMessage')}
function Tl(){Gl.call(this,'Buffer is in write-only mode')}
function Rq(a){Gl.call(this,a.C());this.b=a;gc(this,ec(a))}
function ik(){while((ak(),_j).c>0){bk(de(tN(_j,0),6))}}
function mD(a){if(a.e){throw new mK('Connection closed')}}
function Wx(a){if(a.b.b){return null}return de(sI(a.c),27)}
function UG(a){var b;b=new Gl('WebSocket error');QC(a.c,b)}
function Uk(a){return new Kaazing.ByteBuffer.allocate(a)}
function Qm(a){return new Kaazing.JMS.MapMessage(peer(a))}
function Um(a){return new Kaazing.JMS.TextMessage(peer(a))}
function Nm(a){return new Kaazing.JMS.BytesMessage(peer(a))}
function rj(a){return a.l+a.m*4194304+a.h*17592186044416}
function LG(a,b){if(!b){a.c=(tE(),oE);a.d=null}else{a.d=b}}
function CB(a,b){AB();ts.call(this,b);this.b=a;this.y=false}
function aw(a){Sv.call(this,a,3);this.c=new zO;this.b=new zO}
function jw(a){var b;b=de(es(a),26);b.b=new pp(a.b);return b}
function GG(a,b){var c,d;c=sH(a.b);d=sH(b.b);return BL(c,d)}
function Em(a,b){JI&&dH('session.close()');return Fy(a,b)}
function Fm(a,b){JI&&dH('session.commit()');return Iy(a,b)}
function gm(a,b){JI&&dH('connection.close()');return oD(a,b)}
function yx(a,b,c){if(!jH(a.b,b,c)){return false}return true}
function de(a,b){if(a!=null&&!ce(a,b)){throw new QJ}return a}
function Vd(a,b,c,d,e){var f;f=Ud(e,d);Wd(a,b,c,f);return f}
function xC(a){var b;b=a.b.b.b==2;zx(a.b,1);b&&sC(a);yD(a.c)}
function aP(a){var b;b=a.d.c.c;a.c=b;a.b=a.d.c;b.b=a.d.c.c=a}
function zD(a){var b;!!a.g&&(b=a.g,a.g=null,_q(b),undefined)}
function RG(a){a.f.f.readyState!=3&&(a.f.f.close(),undefined)}
function yC(a){BC(a);tD(a.c,new hr('WebSocket reconnected'))}
function Hx(a){if(a.b.b){throw new Jl('Producer is closed')}}
function By(a){if(a.u.b.b==3){throw new mK('Session closed')}}
function DC(a){this.f=new IP;this.b=new FC;this.d=a;a.j=this}
function sw(a){bs();ts.call(this,a);this.b=new np;this.y=true}
function fH(a){if(a.b){return false}else{a.b=true;return true}}
function nL(a,b){if(!fe(b,1)){return false}return String(a)==b}
function BL(a,b){a=String(a);if(a==b){return 0}return a<b?-1:1}
function sL(c,a,b){b=yL(b);return c.replace(RegExp(a,mT),b)}
function wu(a,b){var c,d;c=new jv(b);d=GS+fu(a,b.d);pA(a.j,c,d)}
function yu(a,b){var c,d;c=new jv(b);d=GS+fu(a,b.d);pA(a.j,c,d)}
function vu(a,b){var c,d;c=new hv(b);d=FS+fu(a,b.d);oA(a.j,c,d)}
function xu(a,b){var c,d;c=new hv(b);d=FS+fu(a,b.d);oA(a.j,c,d)}
function cu(a,b){b.v=a;b.c=a;b.g=a;_y(b,a.o);$y(b,a.j);Hr(a.c,b)}
function pN(a,b,c){(b<0||b>a.c)&&eI(b,a.c);KN(a.b,b,0,c);++a.c}
function dP(a,b,c){this.d=a;YO.call(this,b,c);this.b=this.c=null}
function nu(a,b){var c,d;b.Id(a.f.b);c=b.kd();d=gu(a,c);d.c.qd(b)}
function hc(a){var b,c;b=a.cZ.e;c=a.C();return c!=null?b+GQ+c:b}
function Sm(a){return new Kaazing.JMS.TemporaryQueue(peer(a))}
function Tm(a){return new Kaazing.JMS.TemporaryTopic(peer(a))}
function fk(a,b){return $wnd.setTimeout(FQ(function(){a.F()}),b)}
function lm(a,b){JI&&dH('consumer.setMessageListener()');a.vc(b)}
function im(a,b){JI&&dH('connection.setExceptionListener()');a.i=b}
function _v(a,b){wO(a.c,b.Ob());b.ld(QS+a.d.g+oS+b.Ob());a.f.md(b)}
function kn(a,b){mn(a.b,Om(b,wm(b),b.c!=null?b.c:b.b?b.b.C():b.g))}
function CP(a,b){this.d=a;this.b=b;this.c=b.c;b.c.b=this;b.c=this}
function BN(a){oN(this);LN(this.b,0,0,a.ke());this.c=this.b.length}
function HM(a){if(a.d<0){throw new lK}a.e.qe(a.d);a.c=a.d;a.d=-1}
function nD(a){if(a.e||!a.b){throw new mK('Connection not open')}}
function ec(a){if(a.i==null){return Vd(aj,$P,72,0,0)}return a.i}
function jH(a,b,c){if(a.b==b){a.b=c;return true}else{return false}}
function Ic(a,b,c){var d;d=Gc();try{return Fc(a,b,c)}finally{Jc(d)}}
function IJ(a,b,c){var d;d=new GJ;d.e=a+b;MJ(c)&&NJ(c,d);return d}
function iC(a,b,c,d,e){var f;f=ZB(a,c,d,e);a.b.bd(qJ(b),f);return f}
function Wd(a,b,c,d){$d();ae(d,Yd,Zd);d.cZ=a;d.cM=b;d.qI=c;return d}
function _o(a,b){var c;c=a.f;a.f=b;if(!a.g){a.g=true;++a.i}return c}
function Td(a,b){var c,d;c=a;d=Ud(0,b);Wd(c.cZ,c.cM,c.qI,d);return d}
function MG(a){var b;b='{"'+sH(a.b)+jT+a.c+jT+tH(a.d)+'"}';return b}
function Jy(a,b){var c;c=BH(a.j,b);c&&a.u.b.b==2&&a.j.b.c==0&&Gy(a)}
function zu(a,b){var c,d;c=new TA(hu(a,b));d='DELD:'+b;zA(a.j,c,d)}
function MC(a,b){tD(a.g,!b?new Gl(VS):fe(b,10)?de(b,10):new Rq(b))}
function zy(){zy=VP;mv();xy=new nH(1);yy=new nH(1);wy=new nH(1)}
function ds(a){if(!a.y){throw new Vl('Buffer is in read-only mode')}}
function sH(a){qH();if(!a){return null}return Ik(a.duplicate(),pH)}
function LN(a,b,c,d){Array.prototype.splice.apply(a,[b,c].concat(d))}
function ae(a,b,c){$d();for(var d=0,e=b.length;d<e;++d){a[b[d]]=c[d]}}
function wm(a){var b,c;b=a.cZ.e;c=b.lastIndexOf(WQ);return uL(b,c+1)}
function Zk(a){var b;b=Uk(a.length);b.putBytesAt(0,a);return Yk(Wk,b)}
function cp(a){var b;b=a.f;a.f=null;if(a.g){a.g=false;--a.i}return b}
function KJ(a,b){var c;c=new GJ;c.e=IQ+a;MJ(b)&&NJ(b,c);c.c=1;return c}
function vN(a,b){var c;c=(bI(b,a.c),a.b[b]);JN(a.b,b,1);--a.c;return c}
function Yw(a,b){a.e.b.b==1&&(a.j?qy(a.p,new ux(a,b,true)):Vx(a.q,b))}
function My(a,b){var c;if(fe(b,41)){c=de(b,41).Vd();a.x.id(c)}eu(a.v,b)}
function sI(a){var b;return a.c==0?null:(tI(a),--a.c,b=a.b.b,AP(b),b.d)}
function rc(a){return a==null?JQ:ge(a)?sc(ee(a)):fe(a,1)?KQ:xc(a).e}
function je(a){return ~~Math.max(Math.min(a,2147483647),-2147483648)}
function Mc(){return $wnd.setTimeout(function(){Bc!=0&&(Bc=0);Ec=-1},10)}
function Jc(a){a&&Rc((Pc(),Oc));--Bc;if(a){if(Ec!=-1){Lc(Ec);Ec=-1}}}
function hm(a){JI&&dH('connection.getExceptionListener()');return a.i}
function nm(a,b,c){JI&&dH('createSession('+b+','+c+VQ);return sD(a,b,c)}
function uN(a,b,c){for(;c<a.c;++c){if(FP(b,a.b[c])){return c}}return -1}
function ee(a){if(a!=null&&(a.tM==VP||be(a,1))){throw new QJ}return a}
function Ft(a){cs(a);if(a.b.remaining()<1){throw new Pl}return a.b.get()}
function GM(a){if(a.c>=a.e.cd()){throw new EP}return a.e.pe(a.d=a.c++)}
function lw(a,b){if(b==null||nL(IQ,b)){throw new jK(SS)}return a.b.ad(b)}
function Vo(a,b){return b==null?a.f:fe(b,1)?Xo(a,de(b,1)):Wo(a,b,a.hd(b))}
function ZF(a,b){var c;c=new xo((yq(),Fp));oo(c,UR,b);qy(a.s,new BG(a,c))}
function Nx(a,b){this.b=new hH(false);this.d=a;this.g=b;yH(b.n,this)}
function IF(a){this.b=a;this.d='x-kaazing-'+sL(a.b.toLowerCase(),'_',OQ)}
function $G(){Sq.call(this,'Attempt to reconnect WebSocket failed')}
function fr(){Sq.call(this,'Gateway reported JMS Connection interrupted')}
function QI(){lc.call(this,'Send failed: ByteSocket connection closed')}
function Vq(){Sq.call(this,'WebSocket connection dropped: reconnecting')}
function Od(a){var b;b=a.he();if(!b.re()){return null}return de(b.se(),74)}
function qk(){var a;if(kk){a=new uk;!!lk&&wd(lk,a);return null}return null}
function Dt(a){var b;b=de(es(a),23);b.b=a.b.duplicate();b.c=a.c;return b}
function kP(a){if(a.c==a.d.b.c){throw new EP}a.b=a.c;a.c=a.c.b;return a.b}
function rP(a){sP(a);a.c==a.d?(a.c=a.d.b):--a.b;AP(a.d);a.d=null;--a.e.c}
function Ir(a){var b,c;for(c=SM(Go(a.b.b));c.b.re();){b=de(YM(c),29);b.nd()}}
function Lr(a){var b,c;for(c=SM(Go(a.b.b));c.b.re();){b=de(YM(c),29);b.rd()}}
function Nr(a){var b,c;for(c=SM(Go(a.b.b));c.b.re();){b=de(YM(c),29);b.td()}}
function Or(a){var b,c;for(c=SM(Go(a.b.b));c.b.re();){b=de(YM(c),29);b.ud()}}
function _d(a,b,c){var d=0,e;for(var f in a){if(e=a[f]){b[d]=f;c[d]=e;++d}}}
function ap(e,a,b){var c,d=e.j;a=nS+a;a in d?(c=d[a]):++e.i;d[a]=b;return c}
function gu(a,b){var c;c=de(a.p.ad(b),35);if(!c){throw new mK(ES+b)}return c}
function LO(a,b){var c;c=de(a.d.id(b),75);if(c){bP(c);return c.f}return null}
function wN(a,b){var c;c=uN(a,b,0);if(c==-1){return false}vN(a,c);return true}
function Sd(a,b,c){var d,e;d=a;e=d.slice(b,c);Wd(d.cZ,d.cM,d.qI,e);return e}
function JJ(a,b,c,d){var e;e=new GJ;e.e=a+b;MJ(c)&&NJ(c,e);e.c=d?8:0;return e}
function IO(a,b){var c;c=de(a.d.ad(b),75);if(c){KO(a,c);return c.f}return null}
function qJ(a){var b,c;b=a+128;c=(sJ(),rJ)[b];!c&&(c=rJ[b]=new lJ(a));return c}
function Jr(a,b){var c,d;for(d=SM(Go(a.b.b));d.b.re();){c=de(YM(d),29);c.od(b)}}
function Kr(a,b){var c,d;for(d=SM(Go(a.b.b));d.b.re();){c=de(YM(d),29);c.pd(b)}}
function Mr(a,b){var c,d;for(d=SM(Go(a.b.b));d.b.re();){c=de(YM(d),29);c.sd(b)}}
function bB(a,b){var c;if(fe(b,34)){c=de(b,34).B;c!=null&&XA(a.d,c)}a.c.sd(b)}
function zv(a,b){var c;BH(a.c,b);if(a.c.b.c==0){c=PS+a.d.g;a.f.Qd(a.d,c,false)}}
function NM(a,b){var c;this.b=a;this.e=a;c=a.cd();(b<0||b>c)&&eI(b,c);this.c=b}
function Ly(a,b){var c;if(fe(b,41)){c=de(b,41).Vd();a.x.bd(c,de(b,41))}du(a.v,b)}
function Cy(a){if(fe(a,36)&&!de(a,36).Zd()){throw new Ll(TS+de(a,36).Ld()+US)}}
function Ix(a){if(fe(a,36)&&!de(a,36).Zd()){throw new Ll(TS+de(a,36).Ld()+US)}}
function oy(a,b){if(fH(a.c)){b.Xd(a);return true}else !!b&&oI(a.b,b);return false}
function SH(a,b){var c;c=QH(rI(a,0),b);if(c){c.te();return true}else{return false}}
function dp(d,a){var b,c=d.j;a=nS+a;if(a in c){b=c[a];--d.i;delete c[a]}return b}
function Qc(a){var b,c;if(a.b){c=null;do{b=a.b;a.b=null;c=Uc(b,c)}while(a.b);a.b=c}}
function Rc(a){var b,c;if(a.c){c=null;do{b=a.c;a.c=null;c=Uc(b,c)}while(a.c);a.c=c}}
function JC(a,b){var c,d;if(b){c=new xo((yq(),Lp));WC(a,c)}d=new eD(a);ck(d,a.o.e)}
function Wm(a,b,c,d){var e,f;for(f=0;f<d;++f){e=je(b[c+f])<<24>>24;ds(a);Lk(a.b,e)}}
function Fk(a,b,c,d){var e,f,g;f=a.array;g=c;e=0;while(e<d){b[e++]=f[g++]<<24>>24}}
function zL(a,b,c){a=a.slice(b,c);return String.fromCharCode.apply(null,a)}
function Gm(a,b){JI&&dH('session.setMessageListener()');By(a);Dy(a);a.k=b}
function om(a){JI&&dH('bytesMessage.getBodyLength()');return cs(a),Lj(yj(a.c))}
function vC(a){BC(a);tD(a.c,new hr('Gateway reported JMS Connection restored'))}
function qP(a){if(a.c==a.e.b){throw new EP}a.d=a.c;a.c=a.c.b;++a.b;return a.d.d}
function oL(b,a){if(a==null)return false;return b==a||b.toLowerCase()==a.toLowerCase()}
function Hc(b){return function(){try{return Ic(b,this,arguments)}catch(a){throw a}}}
function XG(b,c){try{jl(b.f,c)}catch(a){a=ej(a);if(fe(a,66)){throw new QI}else throw a}}
function qw(a,b,c){tE();if(!(Aj(c,mQ)&&Cj(c,nQ))){throw new jK(CS)}pw(a,b,new FK(c))}
function Vw(a){if(fe(a.f,36)&&!de(a.f,36).Zd()){throw new Gl(TS+de(a.f,36).Ld()+US)}}
function Ho(a,b){var c,d;for(d=b._c().he();d.re();){c=de(d.se(),78);a.bd(c.ue(),c.ve())}}
function PH(a,b){var c,d;d=b.he();c=false;while(d.re()){a.ge(d.se())&&(c=true)}return c}
function xK(a){var b,c;if(a==0){return 32}else{c=0;for(b=1;(b&a)==0;b<<=1){++c}return c}}
function gj(a){var b,c,d;b=a&4194303;c=a>>22&4194303;d=a<0?1048575:0;return ij(b,c,d)}
function zc(a){var b;return b=a,he(b)?b.tS():b.toString?b.toString():'[JavaScriptObject]'}
function Zo(a,b,c){return b==null?_o(a,c):fe(b,1)?ap(a,de(b,1),c):$o(a,b,c,a.hd(b))}
function $F(a,b,c){var d;d=new xo((yq(),Gp));oo(d,UR,b);oo(d,TR,II(c));qy(a.s,new BG(a,d))}
function kG(a,b,c){var d;d=new xo((yq(),Cp));oo(d,UR,b);oo(d,TR,II(c));qy(a.s,new BG(a,d))}
function CD(a,b){ru(a.f,b);b.y||(a.n=false);yO(a.o,b);a.e&&a.o.b.cd()==0&&!!a.b&&KC(a.b)}
function sn(a,b){var c;while(b.hasRemaining()){c=tn(b);JI&&KI('onFrame: '+wo(c));RC(a.b,c)}}
function Gk(a){var b;b=Vd(Li,fQ,-1,a.remaining(),1);Fk(a,b,a.position,a.remaining());return b}
function pm(a,b){var c,d,e;c=kw(a,b);e=[];for(d=0;d<c.length;++d){e[e.length]=c[d]}return e}
function um(a){var b,c,d;d=[];b=nw(a);while(b.b.b.re()){c=zc(YM(b.b));d[d.length]=c}return d}
function lM(a){var b;this.d=a;b=new zN;a.g&&qN(b,new vM(a));Ro(a,b);Qo(a,b);this.b=new IM(b)}
function AD(a){if(!a.e){a.e=true;pD(a)}a.g?rD(a,new Yq('Connection failed')):tD(a,new Tq)}
function Dy(a){if(a.y){throw new aM('This operation is not supported in transacted sessions')}}
function Tq(){Sq.call(this,'Gateway disconnecting, perhaps due to a fatal error')}
function Dl(){mc.call(this,'An internal error caused a Future to be fulfilled more than once')}
function Gt(a){Ct();ts.call(this,null);this.b=a;this.c=a.remaining();this.y=false;this.b.mark()}
function MO(){So(this);this.c=new cP(this);this.d=new np;this.c.c=this.c;this.c.b=this.c}
function qB(a,b){this.d=a;this.c=new hH(true);this.b=b;!!b&&(!!b.g&&vu(b.g,this),yH(b.w,this))}
function vB(a,b){this.d=a;this.c=new hH(true);this.b=b;!!b&&(!!b.g&&xu(b.g,this),yH(b.w,this))}
function XC(a,b,c){this.n=new ry;this.e=new kD;this.i=a;a.e=this;this.o=b;this.b=c;this.b.b=this}
function HJ(a,b,c,d){var e;e=new GJ;e.e=a+b;MJ(c!=0?-c:0)&&NJ(c!=0?-c:0,e);e.c=4;e.b=d;return e}
function YD(a,b){var c;c=new YG(a.b.b.e,a.b.b.d,Wd(bj,dQ,1,['x-kaazing-bump']));c.c=b;return c}
function QH(a,b){var c;while(a.re()){c=a.se();if(b==null?c==null:wc(b,c)){return a}}return null}
function CJ(a){var b;if(a<128){b=(EJ(),DJ)[a];!b&&(b=DJ[a]=new vJ(a));return b}return new vJ(a)}
function UJ(a,b){if(isNaN(a)){return isNaN(b)?0:1}else if(isNaN(b)){return -1}return a<b?-1:a>b?1:0}
function km(a,b){JI&&dH('connection.stop()');return nD(a),a.r=new cH(b),ck(new OD(a),1),a.r}
function jm(a,b){JI&&dH('connection.start()');return nD(a),a.p=new cH(b),ck(new LD(a),1),a.p}
function lu(a,b){var c,d;Kr(a.k,b);for(d=new IM(a.b);d.c<d.e.cd();){c=de(GM(d),35);c.c.pd(b)}}
function uu(a){var b,c,d;d=new IM(a);while(d.c<d.e.cd()){c=de(GM(d),35);b=c.d.c;fe(b,36)&&HM(d)}}
function yD(a){var b,c;for(c=SM(Go(a.o.b));c.b.re();){b=de(YM(c),32);Vy(b)}!!a.f&&mu(a.f);tD(a,new Vq)}
function QC(a,b){var c;c=new Gl(b.c!=null?b.c:b.b?b.b.C():b.g);tD(a.g,!c?new Gl(VS):c?c:new Rq(null))}
function qG(a,b,c){var d;d=new xo((yq(),Kp));oo(d,$R,b.b);c!=null&&oo(d,TR,II(c));qy(a.s,new BG(a,d))}
function Qy(a){var b,c,d;d=new JP(a.w);for(c=new IM(d.b);c.c<c.e.cd();){b=de(GM(c),36);b.Yd();BH(a.w,b)}}
function pj(a){var b,c;c=wK(a.h);if(c==32){b=wK(a.m);return b==32?wK(a.l)+32:b+20-10}else{return c-12}}
function rN(a,b){var c,d;c=b.ke();d=c.length;if(d==0){return false}LN(a.b,a.c,0,c);a.c+=d;return true}
function $c(a){var b,c,d;d=_c(a);for(b=0,c=d.length;b<c;++b){d[b]=d[b].length==0?'anonymous':d[b]}return d}
function tu(a){var b,c,d;d=a._c().he();while(d.re()){c=de(de(d.se(),78).ve(),35);b=c.d.c;fe(b,36)&&d.te()}}
function Ro(e,a){var b=e.j;for(var c in b){if(c.charCodeAt(0)==58){var d=new AM(e,c.substring(1));a.ge(d)}}}
function aF(a){var b,c;c=Ok(new Kaazing.ByteBuffer.allocate(4),a.b);b=Vd(Li,fQ,-1,4,1);Fk(c,b,0,4);return b}
function rF(a){var b,c;c=Qk(new Kaazing.ByteBuffer.allocate(2),a.b);b=Vd(Li,fQ,-1,2,1);Fk(c,b,0,2);return b}
function rH(a){qH();var b;if(a==null){return null}b=new Kaazing.ByteBuffer;Sk(b,a,pH);b.flip();return b}
function Ht(a){Ct();ts.call(this,a);this.b=new Kaazing.ByteBuffer;this.c=0;this.y=true;this.b.mark()}
function dH(a){$wnd.console&&$wnd.console.log&&typeof $wnd.console.log!==RQ&&$wnd.console.log(a)}
function Rj(){Rj=VP;Nj=ij(4194303,4194303,524287);Oj=ij(0,0,524288);Pj=yj(1);yj(2);Qj=yj(0)}
function gwtOnLoad(b,c,d,e){$moduleName=c;$moduleBase=d;if(b)try{FQ(dj)()}catch(a){b(c)}else{FQ(dj)()}}
function pu(a){var b,c,d;Nr(a.k);d=new BN(Io(a.p));for(c=new IM(d);c.c<c.e.cd();){b=de(GM(c),35);b.c.g.td()}}
function qu(a){var b,c,d;Or(a.k);d=new BN(Io(a.p));for(c=new IM(d);c.c<c.e.cd();){b=de(GM(c),35);b.c.g.ud()}}
function BC(a){var b,c;if(a.f.b.c!=0){c=new uI;PH(c,a.f);sN(a.f.b);while(c.c!=0){b=de(jI(c,0),19);WC(a.e,b)}}}
function lG(a,b){var c,d,e,f;c=sH(b.b);d=b.c;if(d==(tE(),oE)){rw(a,c,null)}else{f=Gk(b.d);e=d.de(f);rw(a,c,e)}}
function nG(a,b){var c,d,e,f;c=sH(b.b);d=b.c;if(d==(tE(),oE)){ps(a,c,null)}else{f=Gk(b.d);e=d.de(f);ps(a,c,e)}}
function kw(a,b){var c;c=lw(a,b);if(c==null){return null}else if(fe(c,2)){return de(c,2)}else throw new Rl(RS)}
function AE(a){switch(a[0]){case 49:return YI(),XI;case 48:return YI(),WI;default:throw new jK(Zk(a));}}
function Am(a){if(xc(a)==Eh||xc(a)==Xh||xc(a)==Qh||xc(a)==Rh||xc(a)==Ih||xc(a)==Mh){return true}return false}
function aC(a,b){var c,d;for(d=new IM(a.c);d.c<d.e.cd();){c=de(GM(d),50);if(wH(c.b,b)){return c}}return null}
function lj(a,b,c,d,e){var f;f=Ij(a,b);c&&oj(f);if(e){a=nj(a,b);d?(fj=Ej(a)):(fj=ij(a.l,a.m,a.h))}return f}
function Hm(a,b,c,d,e){var f,g,i;g=Vd(Li,fQ,-1,e,1);for(i=0;i<e;++i){f=je(c[d+i])<<24>>24;g[i]=f}pw(a,b,g)}
function Al(a,b,c){var d,e;e=null;if(c!=null){e=[];for(d=0;d<c.length;++d){e[e.length]=c[d]}}return zl(a,b,e)}
function Om(a,b,c){var d=b||iR;(c===null||c===undefined)&&(c=a.C());return new Kaazing.JMS.JMSException(c,d)}
function Jj(a,b){var c,d,e;c=a.l-b.l;d=a.m-b.m+(c>>22);e=a.h-b.h+(d>>22);return ij(c&4194303,d&4194303,e&1048575)}
function lC(a,b){var c;c=de(a.b.ad(qJ(b)),50);if(!c){throw new jK('property not exist')}a.b.id(qJ(b));wN(a.c,c)}
function OI(a,b){var c;if(b<0||b>7){throw new mK('Invalid index: Out of range 0 - 7')}c=1<<7-b;return (a&c)!=0}
function py(a){var b;if(!a.c.b){throw new mK('Invalid semaphore state')}b=de(sI(a.b),31);b?b.Xd(a):(a.c.b=false)}
function pw(a,b,c){if(!a.y){throw new Vl('Map not writable')}if(b==null||nL(IQ,b)){throw new jK(SS)}a.b.bd(b,c)}
function SG(a){a.b?(a.f=new kl(a.b,a.d.b,a.e)):(a.f=new ll(a.d.b,a.e));fl(a.f,a);hl(a.f,a);il(a.f,a);gl(a.f,a)}
function Zy(a){var b,c,d;d=new JP(a.j);for(c=new IM(d.b);c.c<c.e.cd();){b=de(GM(c),28);fe(b.Ud(),36)&&BH(a.j,b)}}
function vD(a){var b,c;for(c=SM(Go(a.o.b));c.b.re();){b=de(YM(c),32);Ey(b);Qy(b);Zy(b)}!!a.f&&su(a.f);tD(a,new fr)}
function AK(a){var b,c;if(a>-129&&a<128){b=a+128;c=(CK(),BK)[b];!c&&(c=BK[b]=new sK(a));return c}return new sK(a)}
function fL(a){var b,c;if(a>-129&&a<128){b=a+128;c=(hL(),gL)[b];!c&&(c=gL[b]=new aL(a));return c}return new aL(a)}
function LL(a){JL();var b=nS+a;var c=IL[b];if(c!=null){return c}c=GL[b];c==null&&(c=KL(a));ML();return IL[b]=c}
function gF(a){var b,c;c=new Kaazing.ByteBuffer.allocate(8);vH(c,a.b);b=Vd(Li,fQ,-1,8,1);Fk(c,b,0,8);return b}
function Ww(a,b){var c;c=new cH(b);if(yx(a.e,1,2)){Vw(a);a.d=c;qy(a.p,new lx(a,a))}else{ck(new Kv(c),1)}return c}
function fu(b,c){var d,e;try{e=$A(c,null,null)}catch(a){a=ej(a);if(fe(a,10)){d=a;tD(b.g,d);e=c}else throw a}return e}
function Uo(e,a){var b=e.j;for(var c in b){if(c.charCodeAt(0)==58){var d=b[c];if(e.gd(a,d)){return true}}}return false}
function xJ(a){if(a>=48&&a<58){return a-48}if(a>=97&&a<97){return a-97+10}if(a>=65&&a<65){return a-65+10}return -1}
function qD(a,b){if(a.b){throw new Jl('connect can only be called once')}a.g=new cH(b);a.b=VD(a.j);LC(a.b);return a.g}
function ku(a,b){var c,d;a.o=b.e;a.d=b.b;a.e=b.c;Jr(a.k,b);for(d=new IM(a.b);d.c<d.e.cd();){c=de(GM(d),35);wr(c.c,b)}}
function Hd(a){var b,c;if(a.b){try{for(c=new IM(a.b);c.c<c.e.cd();){b=de(GM(c),7);Cd(b.b,b.e,b.d,b.c)}}finally{a.b=null}}}
function sC(a){var b,c;if(a.f.b.c!=0){c=new uI;PH(c,a.f);sN(a.f.b);while(c.c!=0){b=de(jI(c,0),19);rC(a,b)&&HP(a.f,b)}}}
function NC(a){var b;if(!a.f&&a.o.b>0){b=new hD(a);ck(b,a.o.b)}AC(a.i,false);!!a.k&&JI&&dH('JmsConnection onOpen')}
function KK(a){var b,c;if(zj(a,yQ)&&Bj(a,zQ)){b=Lj(a)+128;c=(MK(),LK)[b];!c&&(c=LK[b]=new FK(a));return c}return new FK(a)}
function Ej(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;return ij(b,c,d)}
function oj(a){var b,c,d;b=~a.l+1&4194303;c=~a.m+(b==0?1:0)&4194303;d=~a.h+(b==0&&c==0?1:0)&1048575;a.l=b;a.m=c;a.h=d}
function gc(a,b){var c,d,e;d=Vd(aj,$P,72,b.length,0);for(e=0,c=b.length;e<c;++e){if(!b[e]){throw new PK}d[e]=b[e]}a.i=d}
function Xc(a){var b,c,d,e;d=Vc($c(Zc()),3);e=Vd(aj,$P,72,d.length,0);for(b=0,c=e.length;b<c;++b){e[b]=new jL(d[b])}gc(a,e)}
function Ey(a){var b,c;JI&&dH('Clearing queued messages');qI(a.B);for(c=new IM(a.j.b);c.c<c.e.cd();){b=de(GM(c),28);b.Td()}}
function vm(a,b){var c;c=ow(a,b);return c==null?null:(xc(c).c&4)!=0&&xc(c).b==le?pm(a,b):xc(c)==Fh?FL(de(c,58).b):c}
function fM(a,b){var c,d,e;if(fe(b,78)){c=de(b,78);d=c.ue();if(a.b.$c(d)){e=a.b.ad(d);return a.b.fd(c.ve(),e)}}return false}
function Gd(a,b){var c,d;d=de(a.e.ad(b),77);if(!d){return XN(),XN(),VN}c=de(d.ad(null),76);if(!c){return XN(),XN(),VN}return c}
function Ed(a,b,c){var d,e;e=de(a.e.ad(b),77);if(!e){e=new np;a.e.bd(b,e)}d=de(e.ad(c),76);if(!d){d=new zN;e.bd(c,d)}return d}
function hu(a,b){var c;if(b==null||a.e==null||a.d==null){c=b}else{c=rL(a.e,'{clientID}',a.d);c=rL(c,'{durableName}',b)}return c}
function yN(a,b){var c;b.length<a.c&&(b=Td(b,a.c));for(c=0;c<a.c;++c){Xd(b,c,a.b[c])}b.length>a.c&&Xd(b,a.c,null);return b}
function PN(a,b,c,d){var e,f,g;for(e=b+1;e<c;++e){for(f=e;f>b&&d.fe(a[f-1],a[f])>0;--f){g=a[f];Xd(a,f,a[f-1]);Xd(a,f-1,g)}}}
function QN(a,b,c,d,e,f,g,i){var j;j=c;while(f<g){j>=d||b<c&&i.fe(a[b],a[j])<=0?Xd(e,f++,a[b++]):Xd(e,f++,a[j++])}}
function mu(a){var b,c,d,e;b=lH(a.f);JI&&dH('New Epoch Id: '+b);su(a);c=Io(a.p);for(e=cN(c);e.b.re();){d=de(iN(e),35);d.c.Nd()}}
function Et(a){var b,c,d,e;e=0;d=a.length;for(c=0;c<d;++c){b=a.charCodeAt(c);b>0&&b<=127?++e:b<=2047?(e+=2):(e+=3)}return yj(e)}
function Fo(a,b){var c,d,e;for(d=a._c().he();d.re();){c=de(d.se(),78);e=c.ue();if(b==null?e==null:wc(b,e)){return c}}return null}
function oD(a,b){if(!a.b){throw new mK('Close called without calling connect')}if(!a.e){a.e=true;a.d=new cH(b);pD(a)}return a.d}
function ck(a,b){if(b<0){throw new jK('must be non-negative')}a.d?dk(a.e):ek(a.e);wN(_j,a);a.d=false;a.e=fk(a,b);qN(_j,a)}
function NG(a,b,c){if(!a){throw new QK('Null property name')}if(!b){throw new QK('Null property type')}this.b=a;this.c=b;this.d=c}
function Bu(){this.p=new np;this.n=new np;this.b=new AN;this.c=new Qr;this.f=new nH(0);this.i=new Nu(this);this.k=this.c}
function Ky(a,b){var c;if(a.y){c=new mK('Cannot subscribe in transacted session');Xc(c);tD(a.i,!c?new Gl(VS):new Rq(c))}yH(a.j,b)}
function KG(a,b){var c;if(b==null){return false}if(mh!=xc(b)){return false}c=de(b,50);return wH(a.b,c.b)&&a.c==c.c&&wH(a.d,c.d)}
function kj(a,b){if(a.h==524288&&a.m==0&&a.l==0){b&&(fj=ij(0,0,0));return hj((Rj(),Pj))}b&&(fj=ij(a.l,a.m,a.h));return ij(0,0,0)}
function yj(a){var b,c;if(a>-129&&a<128){b=a+128;tj==null&&(tj=Vd(Pi,cQ,5,256,0));c=tj[b];!c&&(c=tj[b]=gj(a));return c}return gj(a)}
function Gc(){var a;if(Bc!=0){a=(new Date).getTime();if(a-Dc>2000){Dc=a;Ec=Mc()}}if(Bc++==0){Qc((Pc(),Oc));return true}return false}
function Cm(b,c,d){var e,f;for(f=0;f<d;++f){try{e=Ft(b);c[f]=e}catch(a){a=ej(a);if(fe(a,12)){return f==0?-1:f}else throw a}}return d}
function Ry(b,c){var d;try{Ty(b,c)}catch(a){a=ej(a);if(fe(a,64)){d=a;tD(b.i,!d?new Gl(VS):fe(d,10)?de(d,10):new Rq(d))}else throw a}}
function uE(b,c){try{return b.ce(c)}catch(a){a=ej(a);if(fe(a,59)){throw new jK('Invalidate Map Object type: '+xc(c))}else throw a}}
function Qo(i,a){var b=i.e;for(var c in b){var d=parseInt(c,10);if(c==d){var e=b[d];for(var f=0,g=e.length;f<g;++f){a.ge(e[f])}}}}
function Yo(i,a,b){var c=i.e[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.ue();if(i.gd(a,g)){return true}}}return false}
function Wo(i,a,b){var c=i.e[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.ue();if(i.gd(a,g)){return f.ve()}}}return null}
function Ym(a,b){JI&&dH('MessageListener.onMessage');Zm(a.b,fe(b,16)?Um(de(b,16)):fe(b,9)?Nm(de(b,9)):fe(b,11)?Qm(de(b,11)):Pm(b))}
function Xw(a){if(yx(a.e,2,3)){Jy(a.i,a)}else{throw new mK('Message Consumer not closing')}try{ck(new Kv(a.d),1)}finally{a.d=null}}
function ZB(a,b,c,d){var e;if(!b||!c){throw new jK('Invalid Property: Must have both name and type')}e=new NG(b,c,d);qN(a.c,e);return e}
function rC(a,b){var c;switch(b.e.c){case 44:case 46:c=a.b.b.b==2;break;case 2:case 13:case 14:c=false;break;default:c=true;}return c}
function wL(c){if(c.length==0||c[0]>rS&&c[c.length-1]>rS){return c}var a=c.replace(/^(\s*)/,IQ);var b=a.replace(/\s*$/,IQ);return b}
function fK(a){var b;b=gJ(a);if(b>3.4028234663852886E38){return Infinity}else if(b<-3.4028234663852886E38){return -Infinity}return b}
function Wc(a){var b,c,d,e;d=$c(ge(a.c)?ee(a.c):null);e=Vd(aj,$P,72,d.length,0);for(b=0,c=e.length;b<c;++b){e[b]=new jL(d[b])}gc(a,e)}
function ax(a,b,c,d,e){this.e=new Bx;this.f=a;this.o=b!=null&&!nL(IQ,b)?b:null;this.c=c;this.i=d;this.n=new Xx;this.q=new Xx;this.p=e}
function Yc(b){var c=IQ;try{for(var d in b){if(d!='name'&&d!=LQ&&d!='toString'){try{c+='\n '+d+GQ+b[d]}catch(a){}}}}catch(a){}return c}
function HF(){HF=VP;BF=new IF((TF(),OF));DF=new IF(PF);EF=new IF(QF);FF=new IF(RF);GF=new IF(SF);CF=Wd(Ui,cQ,46,[BF,DF,EF,FF,null,GF])}
function Kj(a){if(wj(a,(Rj(),Oj))){return -9223372036854775808}if(!Aj(a,Qj)){return -rj(Ej(a))}return a.l+a.m*4194304+a.h*17592186044416}
function Sy(a,b,c){var d,e;if(a.y){if(!a.z){e='txn'+yy.b++;a.z=new SB(e)}RB(a.z,c);Kx(b)}else{d=YS+wy.b++;c.ld(d);a.q.bd(d,b);qA(a.p,c)}}
function JO(a,b,c){var d,e,f;e=de(a.d.ad(b),75);if(!e){d=new dP(a,b,c);a.d.bd(b,d);aP(d);return null}else{f=e.f;XO(e,c);KO(a,e);return f}}
function VD(a){var b,c,d;c=new DC(a.d);d=new wn;b=new XC(c,a.b.c,d);b.k=c;CC(c,a.c);VC(b,a.c);!a.b.b&&(a.b.b=new ZD(a));UC(b,a.b.b);return b}
function ow(a,b){var c,d;c=lw(a,b);if(fe(c,68)){d=(new FK(iJ(zc(c)))).b;tE();if(!(Aj(d,mQ)&&Cj(d,nQ))){throw new Gl(zS+Mj(d)+BS)}}return c}
function wD(a){JI&&dH('JmsConnection onClose');!!a.g&&rD(a,new Yq('WebSocket connection failed'));if(a.d){try{_q(a.d)}finally{a.d=null}}}
function UN(a){var b,c;if(a==null){return JQ}b=new RL;for(c=0;c<a.length;++c){c!=0&&(b.b.b+=lR,b);cd(b.b,IQ+a[c])}b.b.b+=QR;return b.b.b}
function hG(b,c){var d;try{Cn(b,c);return b}catch(a){a=ej(a);if(fe(a,64)){d=a;throw !d?new Gl(VS):fe(d,10)?de(d,10):new Rq(d)}else throw a}}
function jI(b,c){var d,e;d=b.je(c);try{e=qP(d)}catch(a){a=ej(a);if(fe(a,79)){throw new pK("Can't remove element "+c)}else throw a}rP(d);return e}
function yl(b,a){typeof Kaazing.Gateway!==RQ&&typeof Kaazing.Gateway.WebSocketFactory===SQ?b.send(a):b.send(a.getArrayBuffer(a.remaining()))}
function xl(b,a){typeof Kaazing.Gateway!==RQ&&typeof Kaazing.Gateway.WebSocketFactory===SQ||a!=TQ?(b.binaryType=a):(b.binaryType='arraybuffer')}
function bG(a,b){var c,d,e,f;e=Go(a.n);d=SM(e);while(d.b.re()){c=de(YM(d),67);f=de(a.n.ad(c),19);b==de(!f.g?null:f.g.ad(HR),67).b&&d.b.te()}}
function Hy(b){var c,d,e;c=new JP(b.n);for(e=new IM(c.b);e.c<e.e.cd();){d=de(GM(e),30);try{gH(d.b)||Xy(d.g,d)}catch(a){a=ej(a);if(!fe(a,10))throw a}}}
function gs(a,b){var c,d,e;if(b==null||!a.r){return null}for(e=new IM(a.r.c);e.c<e.e.cd();){d=de(GM(e),50);c=sH(d.b);if(nL(c,b)){return d}}return null}
function cG(a,b,c){var d,e;if(!a.f.me((HF(),FF))){return}e=new xo((yq(),Jp));d=b.b.Ld();oo(e,IR,d);c!=null&&oo(e,TR,II(c));qy(a.s,new BG(a,e))}
function dG(a,b,c){var d,e;if(!a.f.me((HF(),FF))){return}e=new xo((yq(),Kp));d=b.b.Ld();oo(e,IR,d);c!=null&&oo(e,TR,II(c));qy(a.s,new BG(a,e))}
function mG(a,b,c){var d,e,f,g;if(!c){return}d=sH(b.b);e=b.c;if(e==(tE(),oE)||!c.hasRemaining()){rw(a,d,null)}else{g=Gk(c);f=e.de(g);rw(a,d,f)}}
function oG(a,b,c){var d,e,f,g;if(!c){return}d=sH(b.b);e=b.c;if(e==(tE(),oE)||!c.hasRemaining()&&e!=qE){ps(a,d,null)}else{g=Gk(c);f=e.de(g);ps(a,d,f)}}
function TG(a,b){var c;a.f.b=null;a.f.d=null;a.f.e=null;a.f.c=null;if(b.b.wasClean.b){OC(a.c)}else{c=new Hl(b.b.reason,IQ+b.b.code);PC(a.c,c)}}
function rL(a,b,c){var d,e;d=sL(b,'([/\\\\\\.\\*\\+\\?\\|\\(\\)\\[\\]\\{\\}$^])','\\\\$1');e=sL(sL(c,'\\\\','\\\\\\\\'),'\\$','\\\\$');return sL(a,d,e)}
function yL(a){var b;b=0;while(0<=(b=a.indexOf('\\',b))){a.charCodeAt(b+1)==36?(a=a.substr(0,b-0)+'$'+uL(a,++b)):(a=a.substr(0,b-0)+uL(a,++b))}return a}
function nj(a,b){var c,d,e;if(b<=22){c=a.l&(1<<b)-1;d=e=0}else if(b<=44){c=a.l;d=a.m&(1<<b-22)-1;e=0}else{c=a.l;d=a.m;e=a.h&(1<<b-44)-1}return ij(c,d,e)}
function rI(a,b){var c,d;(b<0||b>a.c)&&eI(b,a.c);if(b>=a.c>>1){d=a.b;for(c=a.c;c>b;--c){d=d.c}}else{d=a.b.b;for(c=0;c<b;++c){d=d.b}}return new tP(a,b,d)}
function tA(a,b){var c,d;if(a.f.b.b==2){nu(a.c,b)}else{d=b.kd();c=d.indexOf($S)==0||d.indexOf(_S)==0||d.indexOf(aT)==0||d.indexOf('rtq/')==0;c&&oI(a.d,b)}}
function Yy(a){var b,c,d;if(!a.g){return}d=new JP(a.w);for(c=new IM(d.b);c.c<c.e.cd();){b=de(GM(c),36);fe(b,38)?xu(a.g,de(b,38)):fe(b,37)&&vu(a.g,de(b,37))}}
function AJ(a){if(a<0||a>1114111){throw new iK}return a>=65536?Wd(Mi,pQ,-1,[55296+(a-65536>>10&1023)&65535,56320+(a-65536&1023)&65535]):Wd(Mi,pQ,-1,[a&65535])}
function sD(a,b,c){var d;if(!b&&a.n){throw new aM('Only one non-transacted session can be active at a time')}d=new cz(b,c);d.s=a;By(d);d.i=a;DD(d.s,d);return d}
function tC(a,b){if(a.b.b.b==1||a.b.b.b==2){if(b.e==(yq(),Hp)||b.e==Lp){WC(a.e,b)}else if(rC(a,b)){JI&&JI&&dH('Adding pending frame');HP(a.f,b)}return}WC(a.e,b)}
function II(a){HI();var b,c;if(a==null){return null}b=new Kaazing.ByteBuffer;$k(GI,a,b);b.flip();c=Vd(Li,fQ,-1,b.remaining(),1);Fk(b,c,0,b.remaining());return c}
function HC(b){var c;if(b.o.c==-1||b.p-->0){try{b.c=null;LC(b)}catch(a){a=ej(a);if(fe(a,64)){c=a;tD(b.g,!c?new Gl(VS):fe(c,10)?de(c,10):new Rq(c))}else throw a}}}
function MI(a){var b,c;if((a&128)==0){return 1}for(b=0;b<7;++b){if(OI(a,b)){continue}else{if(b<=6){return b}c=kT+yK(a);throw new mK(c)}}c=kT+yK(a);throw new mK(c)}
function NJ(a,b){var c;b.d=a;if(a==2){c=String.prototype}else{if(a>0){var d=LJ(b);if(d){c=d.prototype}else{d=Vj[a]=function(){};d.cZ=b;return}}else{return}}c.cZ=b}
function $v(a,b){var c,d;b&&a.b.le(a.c);for(d=SM(Go(a.c.b));d.b.re();){c=de(YM(d),1);vr(a,new Gl('Message acknowledgement did not receive receipt: '+c))}a.c.b.dd()}
function fc(a){var b,c,d;d=new QL;c=a;while(c){b=c.C();c!=a&&(d.b.b+='Caused by: ',d);PL(d,c.cZ.e);d.b.b+=GQ;cd(d.b,b==null?'(No exception detail)':b);d.b.b+=HQ;c=c.f}}
function nv(a,b){if(a.indexOf(HS)==0){return new Zx(a)}else if(a.indexOf(IS)==0){return new qB(a,b)}else if(a.indexOf(JS)==0){return new gy(a)}else{throw new $J(KS+a)}}
function ov(a,b){if(a.indexOf(LS)==0){return new jy(a)}else if(a.indexOf(MS)==0){return new vB(a,b)}else if(a.indexOf(NS)==0){return new my(a)}else{throw new $J(KS+a)}}
function bC(a){var b,c,d;if(a.c.c==0){return '{}'}d=new XL;for(c=new IM(a.c);c.c<c.e.cd();){b=de(GM(c),50);d.b.b.length>1&&(d.b.b+=lR,d);VL(d,MG(b))}return pS+d.b.b+vS}
function $B(a,b,c){var d,e;if(b==null){throw new jK('Invalid Property: Must have a name')}e=xE(c);d=uE(e,c);return a.$d(rH(b),e,c==null?null:Kaazing.ByteBuffer.wrap(d))}
function SK(){SK=VP;RK=Wd(Mi,pQ,-1,[48,49,50,51,52,53,54,55,56,57,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122])}
function sj(a,b){var c,d,e;e=a.h-b.h;if(e<0){return false}c=a.l-b.l;d=a.m-b.m+(c>>22);e+=d>>22;if(e<0){return false}a.l=c&4194303;a.m=d&4194303;a.h=e&1048575;return true}
function Ay(b){var c,d;try{while(b.f.c!=0){c=de(jI(b.f,0),27);iu(b.c,c)}}catch(a){a=ej(a);if(fe(a,64)){d=a;tD(b.i,!d?new Gl(VS):fe(d,10)?de(d,10):new Rq(d))}else throw a}}
function gJ(a){var b;if(!(b=fJ,!b&&(b=fJ=/^\s*[+-]?(NaN|Infinity|((\d+\.?\d*)|(\.\d+))([eE][+-]?\d+)?[dDfF]?)\s*$/),b.test(a))){throw new ZK(lT+a+SR)}return parseFloat(a)}
function yK(a){var b,c,d;b=Vd(Mi,pQ,-1,8,1);c=(SK(),RK);d=7;if(a>=0){while(a>15){b[d--]=c[a&15];a>>=4}}else{while(d>0){b[d--]=c[a&15];a>>=4}}b[d]=c[a&15];return zL(b,d,8)}
function rG(a,b){var c,d,e;d=b.g;c=de(a.r.ad(d),48);if(!c){throw new mK('Subscription entry not found during unsubscribe')}e=new ry;c.d=e;!c.b&&fH(e.c);oy(e,new yG(a,c,d))}
function al(d){if(d.data.byteLength){var a=new Uint8Array(d.data);var b=[];for(var c=0;c<a.byteLength;c++){b.push(a[c])}return new Kaazing.ByteBuffer(b)}else{return d.data}}
function zn(a){var b,c,d,e;d=new XL;for(c=SM(Go(a));c.b.re();){b=de(YM(c),1);cd(d.b,b);e=de(a.ad(b),1);if(e!=null){d.b.b+=RR;cd(d.b,e)}d.b.b+=SR}return WL(d,d.b.b.length-2)}
function Zw(a){var b;if(a.j){throw new mK('Cannot deliver messages via receive when consumer has message listener')}Vw(a);b=a.q.c.c==0?Wx(a.n):Wx(a.q);!!b&&Ry(a.i,b);return b}
function tG(a,b,c){YF();this.s=new ry;this.n=new np;this.d=(mv(),lv);this.q=new np;this.r=new np;this.f=(XN(),XN(),WN);this.k=a;this.p=b==null?null:II(b);this.b=c;this.c=true}
function Ty(a,b){var c,d;if(SH(a.o,b)||SH(a.B,b)){if(b.Qb()){c=rI(a.f,0);while(c.c!=c.e.b){d=de(qP(c),27);if(nL(b.Ob(),d.Ob())){rP(c);break}}}oI(a.f,b)}(a.b==1||a.b==3)&&Ay(a)}
function UH(a){var b,c,d,e;d=new QL;b=null;d.b.b+=qS;c=a.he();while(c.re()){b!=null?(cd(d.b,b),d):(b=lR);e=c.se();cd(d.b,e===a?'(this Collection)':IQ+e)}d.b.b+=QR;return d.b.b}
function Ud(a,b){var c=new Array(b);if(a==3){for(var d=0;d<b;++d){var e=new Object;e.l=e.m=e.h=0;c[d]=e}}else if(a>0){var e=[null,0,false][a];for(var d=0;d<b;++d){c[d]=e}}return c}
function jG(a,b){var c,d;d=!b&&a.c||b&&!a.g;if(d){a.i=false;c=new xo((yq(),Hp));a.b!=null&&oo(c,WR,a.b);oo(c,XR,a.k);oo(c,YR,a.p);wO(c.d,(HF(),BF));qy(a.s,new BG(a,c))}Lr(a.o.c.k)}
function To(k,a){var b=k.e;for(var c in b){var d=parseInt(c,10);if(c==d){var e=b[d];for(var f=0,g=e.length;f<g;++f){var i=e[f];var j=i.ve();if(k.gd(a,j)){return true}}}}return false}
function bp(i,a,b){var c=i.e[b];if(c){for(var d=0,e=c.length;d<e;++d){var f=c[d];var g=f.ue();if(i.gd(a,g)){c.length==1?delete i.e[b]:c.splice(d,1);--i.i;return f.ve()}}}return null}
function pD(b){var c,d,e;if(b.o.b.cd()==0){!!b.b&&KC(b.b)}else{c=new zO;c.le(b.o);for(e=SM(Go(c.b));e.b.re();){d=de(YM(e),32);try{Fy(d,null)}catch(a){a=ej(a);if(!fe(a,10))throw a}}}}
function Bd(a,b,c){if(!b){throw new QK('Cannot add a handler with a null type')}if(!c){throw new QK('Cannot add a null handler')}a.c>0?Ad(a,new Ek(a,b,c)):Cd(a,b,null,c);return new Ck}
function bs(){bs=VP;var a,b,c,d;as=Wd(bj,dQ,1,['AND','BETWEEN','ESCAPE','FALSE','IN','IS','LIKE','NOT','NULL','OR','TRUE']);_r=new zO;for(b=as,c=0,d=b.length;c<d;++c){a=b[c];wO(_r,a)}}
function zj(a,b){var c,d;c=a.h>>19;d=b.h>>19;return c==0?d!=0||a.h>b.h||a.h==b.h&&a.m>b.m||a.h==b.h&&a.m==b.m&&a.l>b.l:!(d==0||a.h<b.h||a.h==b.h&&a.m<b.m||a.h==b.h&&a.m==b.m&&a.l<=b.l)}
function Aj(a,b){var c,d;c=a.h>>19;d=b.h>>19;return c==0?d!=0||a.h>b.h||a.h==b.h&&a.m>b.m||a.h==b.h&&a.m==b.m&&a.l>=b.l:!(d==0||a.h<b.h||a.h==b.h&&a.m<b.m||a.h==b.h&&a.m==b.m&&a.l<b.l)}
function Yj(a){return $stats({moduleName:$moduleName,sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date).getTime(),type:'onModuleLoadStart',className:a})}
function _q(b){var c;if(b.d){throw new Dl}b.d=true;if(b.b){try{!b.c?b.b.Zc(b.e):b.b.Yc(b.c)}catch(a){a=ej(a);if(fe(a,64)){c=a;KI('Uncaught Application Exception: '+hc(c))}else throw a}}}
function wd(b,c){var d,e;!c.b||(c.b=false,c.c=null);e=c.c;id(c,b.c);try{Dd(b.b,c)}catch(a){a=ej(a);if(fe(a,8)){d=a;throw new Qd(d.b)}else throw a}finally{e==null?(c.b=true,c.c=null):(c.c=e)}}
function En(a,b){var c,d,e,f,g;c=new cC;yn(a,c,true);for(e=new IM(c.c);e.c<e.e.cd();){d=de(GM(e),50);if(d.c==(tE(),sE)){f=aC(b,d.b);wN(b.c,f)}else{g=aC(b,d.b);!g?b.$d(d.b,d.c,d.d):LG(g,d.d)}}}
function DL(a){var b,c;if(a>=65536){b=55296+(a-65536>>10&1023)&65535;c=56320+(a-65536&1023)&65535;return String.fromCharCode(b)+String.fromCharCode(c)}else{return String.fromCharCode(a&65535)}}
function Vy(a){var b,c,d,e,f;Ey(a);for(c=de(Go(a.q).ne(Vd(bj,dQ,1,0,0)),73),d=0,e=c.length;d<e;++d){b=c[d];f=de(a.q.id(b),30);Lx(f,'Message sent from client may not have been delivered')}Qy(a);Zy(a)}
function LC(b){var c;if(!yx(b.e,4,1)){throw new Jl('Cannot connect: connection not closed')}try{b.c=YD(b.d,b);SG(b.c)}catch(a){a=ej(a);if(fe(a,64)){c=a;zx(b.e,4);b.c=null;throw new Xq(c)}else throw a}}
function KL(a){var b,c,d,e;b=0;d=a.length;e=d-4;c=0;while(c<e){b=a.charCodeAt(c+3)+31*(a.charCodeAt(c+2)+31*(a.charCodeAt(c+1)+31*(a.charCodeAt(c)+31*b)))|0;c+=4}while(c<d){b=b*31+mL(a,c++)}return b|0}
function Xd(a,b,c){if(c!=null){if(a.qI>0&&!ce(c,a.qI)){throw new UI}else if(a.qI==-1&&(c.tM==VP||be(c,1))){throw new UI}else if(a.qI<-1&&!(c.tM!=VP&&!be(c,1))&&!ce(c,-a.qI)){throw new UI}}return a[b]=c}
function Uc(b,c){var d,e,f;for(d=0,e=b.length;d<e;++d){f=b[d];try{f[1]?f[0].ze()&&(c=Tc(c,f)):($wnd.__gwt_initWindowCloseHandler(FQ(qk),FQ(pk)),undefined)}catch(a){a=ej(a);if(!fe(a,74))throw a}}return c}
function $o(k,a,b,c){var d=k.e[c];if(d){for(var e=0,f=d.length;e<f;++e){var g=d[e];var i=g.ue();if(k.gd(a,i)){var j=g.ve();g.we(b);return j}}}else{d=k.e[c]=[]}var g=new YO(a,b);d.push(g);++k.i;return null}
function YA(a,b,c,d){if(!fe(a,17)&&b!=null){throw new jK('Only topics can have durable subscriptions')}this.c=a;this.d=b;this.e=c;this.f=d;this.b=d;this.i=$A(a.Ld(),b,c);(c==null||b!=null)&&(this.g=this.i)}
function Hj(a,b){var c,d,e;b&=63;if(b<22){c=a.l<<b;d=a.m<<b|a.l>>22-b;e=a.h<<b|a.m>>22-b}else if(b<44){c=0;d=a.l<<b-22;e=a.m<<b-22|a.l>>44-b}else{c=0;d=0;e=a.l<<b-44}return ij(c&4194303,d&4194303,e&1048575)}
function iu(a,b){var c;c=de(a.p.ad(b.kd()),35);if(!c){throw new mK('Message consumed without subscription')}if(b.Ad()!=a.f.b){KI('Ignoring ACK. Message: '+b.Ob()+' belongs to older Epoch.');return}c.e.md(b)}
function TF(){TF=VP;OF=new UF('DURABLE',0);PF=new UF('MAP_MESSAGE',1);QF=new UF('SELECTORS',2);RF=new UF('TEMPDEST',3);NF=new UF('APNS',4);SF=new UF('TYPED_PROPERTIES',5);MF=Wd(Ti,jQ,47,[OF,PF,QF,RF,NF,SF])}
function SN(a,b,c,d,e,f){var g,i,j,k;g=d-c;if(g<7){PN(b,c,d,f);return}j=c+e;i=d+e;k=j+(i-j>>1);SN(b,a,j,k,-e,f);SN(b,a,k,i,-e,f);if(f.fe(a[k-1],a[k])<=0){while(c<d){Xd(b,c++,a[j++])}return}QN(a,j,k,i,b,c,d,f)}
function gA(b){var c,d;d=b.b.j;if(d){SH(b.d.B,b.c);oI(b.d.o,b.c);try{Ym(d,b.c)}catch(a){a=ej(a);if(fe(a,64)){c=a;KI('Unhandled exception thrown from message listener: '+hc(c))}else throw a}finally{Ry(b.d,b.c)}}}
function eB(a){this.d=a;if(fe(a.c,13)){this.e=new by(a);this.c=new aw(a)}else if(a.d!=null){this.e=new Hv(a);this.c=new aw(a)}else{this.e=new Ev(a);this.c=new LB(a)}this.e.e=this;this.c.e=this;Rv(this.c,this.e)}
function PC(b,c){var d,e;if(b.f){OC(b)}else{if(b.c){try{RG(b.c);b.c=null}catch(a){a=ej(a);if(fe(a,64)){d=a;fc(d)}else throw a}}if(c){e=new Gl(c.c!=null?c.c:c.b?c.b.C():c.g);tD(b.g,!e?new Gl(VS):e?e:new Rq(null))}}}
function uH(a,b,c,d,e,f,g,i){qH();return Gj(Gj(Gj(Gj(Gj(Gj(Gj(Hj(yj(a),56),Hj(uj(yj(b),vQ),48)),Hj(uj(yj(c),vQ),40)),Hj(uj(yj(d),vQ),32)),Hj(uj(yj(e),vQ),24)),Hj(uj(yj(f),vQ),16)),Hj(uj(yj(g),vQ),8)),uj(yj(i),vQ))}
function Wj(a,b,c){var d=Vj[a];if(d&&!d.cZ){_=d.prototype}else{!d&&(d=Vj[a]=function(){});_=d.prototype=b<0?{}:Xj(b);_.cM=c}for(var e=3;e<arguments.length;++e){arguments[e].prototype=_}if(d.cZ){_.cZ=d.cZ;d.cZ=null}}
function _c(a){var b,c,d,e,f;f=a&&a.message?a.message.split(HQ):[];for(b=0,c=0,e=f.length;c<e;++b,c+=2){d=f[c].lastIndexOf('function ');d==-1?(f[b]=IQ,undefined):(f[b]=wL(uL(f[c],d+9)),undefined)}f.length=b;return f}
function tE(){tE=VP;_k();gE=new BE;hE=new KE;iE=new GE;jE=new PE;kE=new UE;lE=new YE;mE=new bF;nE=new hF;oE=new mF(9,JQ);pE=new sF;qE=new xF;sE=new mF(12,RQ);rE=Wd(Si,cQ,45,[null,gE,hE,iE,jE,kE,lE,mE,nE,oE,pE,qE,sE])}
function ON(a,b){var c,d,e;if(ie(a)===ie(b)){return true}if(a==null||b==null){return false}if(a.length!=b.length){return false}for(c=0;c<a.length;++c){d=a[c];e=b[c];if(!(d==e||!!d&&KG(d,e))){return false}}return true}
function Pd(a){var b,c,d,e,f;c=a.cd();if(c==0){return null}b=new YL(c==1?'Exception caught: ':c+' exceptions caught: ');d=true;for(f=a.he();f.re();){e=de(f.se(),74);d?(d=false):(b.b.b+='; ',b);VL(b,e.C())}return b.b.b}
function cz(a,b){zy();this.j=new CH;this.n=new CH;this.x=new np;this.w=new CH;this.B=new uI;this.o=new uI;this.f=new uI;this.A=new np;this.q=new np;this.t=new ry;this.u=new kA;this.y=a;this.b=b;this.s=null;zx(this.u,1)}
function fs(a,b){var c,d,e,f;if(b==null||nL(IQ,b)){throw new jK('Property names cannot be empty or null')}if(!a.r){return null}f=gs(a,b);if(!f){return null}d=f.c;e=f.d;if(d!=(tE(),oE)){c=Gk(e);return d.de(c)}return null}
function _B(a,b){var c,d,e;if(b==null){return false}if(a.cZ!=xc(b)){return false}c=de(b,49);if(a.c.c!=c.c.c){return false}e=de(yN(a.c,Wd(Vi,tQ,50,[])),51);TN(e,XB);d=de(yN(c.c,Wd(Vi,tQ,50,[])),51);TN(d,XB);return ON(e,d)}
function eu(b,c){var d,e,f,g,i;d=c.f;try{e=hu(b,c.Vd());g=ZA(d,e,c.o);i=de(b.p.ad(g),35);if(!i){throw new mK('Consumer unsubscribed without subscription')}i.e.Md(c)}catch(a){a=ej(a);if(fe(a,10)){f=a;tD(b.g,f)}else throw a}}
function ou(a,b){var c,d;if(fe(b,22)||fe(b,34)||fe(b,43)){c=b.kd();d=de(a.p.ad(c),35);if(!d&&fe(b,34)){d=de(a.n.id(b.jd()),35);!!d&&a.p.bd(c,d)}d?bB(d,b):fe(b,22)||JI&&dH(ES+c+' while processing receipt '+b)}else{Mr(a.k,b)}}
function wH(a,b){qH();var c,d;if(a==b){return true}if(!a||!b){return false}if(a.remaining()!=b.remaining()){return false}for(c=a.limit-1,d=b.limit-1;c>=a.position;--c,--d){if(a.getAt(c)!=b.getAt(d)){return false}}return true}
function es(a){var b,c;b=(c=a.xd(),c.A=a.A,c.B=a.B,c);b.r=a.r?a.r.ae():null;b.e=a.e;b.u=a.u;b.j=a.j;b.t=a.t;b.o=a.o;b.k=a.k;b.y=a.y;b.z=a.z;b.d=a.d;b.f=a.f;b.i=a.i;b.p=a.p;b.q=a.q;b.s=a.s;b.v=a.v;b.w=a.w;b.x=a.x;b.n=a.n;return b}
function vH(a,b){qH();Lk(a,Lj(Ij(b,56))<<24>>24);Lk(a,Lj(Ij(b,48))<<24>>24);Lk(a,Lj(Ij(b,40))<<24>>24);Lk(a,Lj(Ij(b,32))<<24>>24);Lk(a,Lj(Ij(b,24))<<24>>24);Lk(a,Lj(Ij(b,16))<<24>>24);Lk(a,Lj(Ij(b,8))<<24>>24);Lk(a,Lj(b)<<24>>24)}
function wK(a){var b,c,d;if(a<0){return 0}else if(a==0){return 32}else{d=-(a>>16);b=d>>16&16;c=16-b;a=a>>b;d=a-256;b=d>>16&8;c+=b;a<<=b;d=a-4096;b=d>>16&4;c+=b;a<<=b;d=a-16384;b=d>>16&2;c+=b;a<<=b;d=a>>14;b=d&~(d>>1);return c+2-b}}
function ps(a,b,c){if(c==null||fe(c,1)||fe(c,54)||fe(c,55)||fe(c,71)||fe(c,67)||fe(c,68)||fe(c,65)||fe(c,62)){qs(a,b,c)}else{throw new Rl('Object value must be one of Boolean, Byte, Short, Integer, Long, Float, Double, or String')}}
function bz(b,c){var d,e,f;for(e=new IM(b.j.b);e.c<e.e.cd();){d=de(GM(e),28);if(d.Ud()==c){try{d.rc(null)}catch(a){a=ej(a);if(fe(a,64)){f=a;tD(b.i,!f?new Gl(VS):fe(f,10)?de(f,10):new Rq(f))}else throw a}}}!!b.g&&yu(b.g,c);BH(b.w,c)}
function az(b,c){var d,e,f;for(e=new IM(b.j.b);e.c<e.e.cd();){d=de(GM(e),28);if(nL(d.Ud().Ld(),c.d)){try{d.rc(null)}catch(a){a=ej(a);if(fe(a,64)){f=a;tD(b.i,!f?new Gl(VS):fe(f,10)?de(f,10):new Rq(f))}else throw a}}}!!b.g&&wu(b.g,c);BH(b.w,c)}
function Uy(b,c,d){var e,f;By(b);if(!c){throw new jK('Invalid message type')}f=b.u.b.b;if(f!=2&&f!=3){try{c.Gd(b);Wy(b,new iA(b,d,c))}catch(a){a=ej(a);if(fe(a,64)){e=a;tD(b.i,!e?new Gl(VS):fe(e,10)?de(e,10):new Rq(e))}else throw a}}}
function tH(a){qH();var b,c,d,e;if(!a){return IQ}if(a.remaining()==0){return IQ}c=new XL;d=a.slice();while(d.hasRemaining()){c.b.b.length>0&&(c.b.b+=rS,c);b=d.get();b<0&&(b+=256);e=yK(b);e.length==1&&(c.b.b+=NQ,c);cd(c.b,e)}return c.b.b}
function WC(b,c){var d,e;JI&&JI&&dH('OUT: '+c);if(b.e.b.b==2||b.e.b.b==1&&c.e==(yq(),Hp)||b.e.b.b==3&&c.e==(yq(),Lp)){try{d=un(c);XG(b.c,d)}catch(a){a=ej(a);if(fe(a,64)){e=a;tD(b.g,!e?new Gl(VS):fe(e,10)?de(e,10):new Rq(e))}else throw a}}}
function Ny(a,b,c){var d,e;By(a);if(c!=null&&!a.r){throw new aM('Message selectors are not available with this Gateway/Broker configuration')}Dy(a);Cy(b);d=new ax(de(b,24),c,a.b,a,a.t);e=new Fz(a,d);d.k=e;_w(d,a.i);Ky(d.i,d);Ly(d.i,d);return d}
function mm(a,b,c,d,e){var f,g,i,j,k;JI&&dH('createConnection()');JI&&dH('user: '+b);return f=new FD(d),g=new tG(b,c,d),i=new AA,j=new Bu,j.j=i,i.c=j,g.o=i,yA(g.o,g),f.q=i,i.e=f,f.f=j,j.g=f,g.e=f,ED(f,new WD(a,g,f)),k=new dr(e),qD(f,new aE(k,f)),k}
function KC(b){var c,d,e;e=b.e.b.b;if(e==1&&b.q){b.q=false;if(b.c){try{RG(b.c)}catch(a){a=ej(a);if(fe(a,64)){c=a;tD(b.g,!c?new Gl(VS):fe(c,10)?de(c,10):new Rq(c))}else throw a}}}else if(e!=3&&e!=4){zx(b.e,3);d=e==2&&!b.r;JC(b,d)}else b.q&&(b.q=false)}
function $A(a,b,c){var d,e,f;if(b!=null){return $S+b}if(a.indexOf(LS)==0){e=LS;d=bT}else if(a.indexOf(MS)==0){e=MS;d=cT}else if(a.indexOf(HS)==0){e=HS;d=_S}else if(a.indexOf(IS)==0){e=IS;d=aT}else{throw new Gl(OS+a)}f=rL(a,e,d);c!=null&&(f=f+c);return f}
function Eo(a,b){var c,d,e,f,g;if(b===a){return true}if(!fe(b,77)){return false}f=de(b,77);if(a.cd()!=f.cd()){return false}for(d=f._c().he();d.re();){c=de(d.se(),78);e=c.ue();g=c.ve();if(!a.$c(e)){return false}if(!FP(g,a.ad(e))){return false}}return true}
function Wy(b,c){var d,e,f;f=c.c;d=c.b;try{f.Gd(b);if(b.k){oI(b.o,f);Ym(b.k,f);Ty(b,f)}else{oI(b.B,f);d.e.b.b==1&&(d.j?qy(d.p,new ux(d,f,false)):Vx(d.n,f))}}catch(a){a=ej(a);if(fe(a,64)){e=a;tD(b.i,!e?new Gl(VS):fe(e,10)?de(e,10):new Rq(e))}else throw a}}
function Bn(a,b){var c,d,e,f,g;d=tL(a,RR,2);c=d[0];if(d.length>1){e=d[1];if(e.charCodeAt(0)==34){g=qL(e,DL(34),1);if(g==-1){throw new jK(a)}f=e.substr(1,g-1)}else{g=pL(e,DL(59));g=g==-1?e.length:g;f=e.substr(0,g-0)}b.bd(c,f);g<e.length-1&&Bn(uL(e,g+1),b)}}
function tD(b,c){var d;if(b.i){try{b.i.jb(!c?new Gl(VS):c?c:new Rq(null))}catch(a){a=ej(a);if(fe(a,64)){d=a;KI('Unhandled exception thrown from exception listener:  '+hc(d))}else throw a}}else !!b.g&&!b.g.d?br(b.g,c):!c.b?JI&&KI(dT+hc(c)):JI&&KI(dT+hc(c.b))}
function qj(a){var b,c,d;c=a.l;if((c&c-1)!=0){return -1}d=a.m;if((d&d-1)!=0){return -1}b=a.h;if((b&b-1)!=0){return -1}if(b==0&&d==0&&c==0){return -1}if(b==0&&d==0&&c!=0){return xK(c)}if(b==0&&d!=0&&c==0){return xK(d)+22}if(b!=0&&d==0&&c==0){return xK(b)+44}return -1}
function OC(a){var b,c;b=a.e.b.b;zx(a.e,4);!!a.c&&(a.c=null);if(a.r){AD(a.k.c);!!a.k&&wD(a.k.c);Ir(a.i.d.o.c.k)}else if(b==2&&a.f){xC(a.k);a.q=true;a.p=a.o.c;a.j=false;HC(a)}else if(a.q){tD(a.k.c,new $G);c=new $C(a);ck(c,a.o.d)}else{!!a.k&&wD(a.k.c);Ir(a.i.d.o.c.k)}}
function Mq(){Mq=VP;Eq=new Nq('BYTE',0);Fq=new Nq('BYTEARRAY',1);Dq=new Nq('BOOLEAN',2);Iq=new Nq('INT',3);Jq=new Nq('LONG',4);Kq=new Nq('STRING',5);Gq=new Nq('DICTIONARY',6);Hq=new Nq('INDICATOR',7);Lq=new Nq('UTF8_INT',8);Cq=Wd(Ri,jQ,21,[Eq,Fq,Dq,Iq,Jq,Kq,Gq,Hq,Lq])}
function rw(a,b,c){if(c==null||fe(c,1)||fe(c,54)||fe(c,55)||fe(c,71)||fe(c,67)||fe(c,68)||fe(c,65)||fe(c,62)||fe(c,58)||fe(c,2)){pw(a,b,c)}else{throw new Gl('Object value must be one of Boolean, Byte, Short, Integer, Long, Float, Double, Character, String or byte[]')}}
function Ij(a,b){var c,d,e,f,g;b&=63;c=a.h;d=(c&524288)!=0;d&&(c|=-1048576);if(b<22){g=c>>b;f=a.m>>b|c<<22-b;e=a.l>>b|a.m<<22-b}else if(b<44){g=d?1048575:0;f=c>>b-22;e=a.m>>b-22|c<<44-b}else{g=d?1048575:0;f=d?4194303:0;e=c>>b-44}return ij(e&4194303,f&4194303,g&1048575)}
function hJ(a,b,c){var d,e,f,g;if(a==null){throw new ZK(JQ)}e=a.length;f=e>0&&a.charCodeAt(0)==45?1:0;for(d=f;d<e;++d){if(xJ(a.charCodeAt(d))==-1){throw new ZK(lT+a+SR)}}g=parseInt(a,10);if(isNaN(g)){throw new ZK(lT+a+SR)}else if(g<b||g>c){throw new ZK(lT+a+SR)}return g}
function pv(a,b){var c;c=de(a.b.ad(b),24);if(c){return c}else if(b.indexOf(LS)==0||b.indexOf(MS)==0||b.indexOf(NS)==0){return ov(b,null)}else if(b.indexOf(HS)==0||b.indexOf(IS)==0||b.indexOf(JS)==0){return nv(b,null)}else{throw new Gl(OS+b+'.  Example: /topic/destination')}}
function TC(b){var c;try{if(yx(b.e,1,2)){if(b.q){b.q=false;AC(b.i,true)}else{NC(b)}}else{if(b.c){RG(b.c);b.c=null}if(b.e.b.b==2){throw new mK('Open fired during CONNECTED state')}}}catch(a){a=ej(a);if(fe(a,64)){c=a;tD(b.g,!c?new Gl(VS):fe(c,10)?de(c,10):new Rq(c))}else throw a}}
function wA(a){var b,c,d,e;if(yx(a.f,2,3)){qu(a.c);e=new BN(Io(a.g));for(c=new IM(e);c.c<c.e.cd();){b=de(GM(c),33);d=b.b;rG(a.b,d)}if(yx(a.f,3,4)){_q(a.e.r)}else{throw new mK('State changed illegally while stopping')}}else if(a.f.b.b==1){throw new mK('Start must complete before stopping')}}
function zl(b,c,d){var e;try{d===null||d===undefined?(e=new $wnd.WebSocket(c)):(e=new $wnd.WebSocket(c,d))}catch(a){throw new function(a){return new vl(a)}(a.message)}e.onopen=function(a){b.K()};e.onmessage=function(a){b.J(a)};e.onclose=function(a){b.H(a)};e.onerror=function(a){b.I()};return e}
function Bl(b,c,d,e){var f;try{e===null||e===undefined?(f=c.createWebSocket(d)):(f=c.createWebSocket(d,e))}catch(a){throw new function(a){return new vl(a)}(a.message)}f.onopen=function(a){b.K()};f.onmessage=function(a){b.J(a)};f.onclose=function(a){b.H(a)};f.onerror=function(a){b.I()};return f}
function fG(a,b){var c,d,e,f,g;f=b.kd();c=de(a.r.ad(f),48);!c&&tD(a.e,new Gl('Subscription ID missing on message '+b.Ob()));d=new xo((yq(),Dp));oo(d,VR,b.Ob());Fj(b.Ed(),lQ)&&oo(d,'index',KK(b.Ed()));oo(d,HR,c.b);e=b.jd();e!=null&&oo(d,TR,II(e));g=b.Fd();g!=null&&oo(d,UR,g);qy(a.s,new BG(a,d))}
function xE(a){tE();var b;if(a==null){return oE}b=xc(a);if(b==Dh){return gE}else if(b==Eh){return hE}else if(b==Fh){return jE}else if(b==Ih){return kE}else if(b==Mh){return lE}else if(b==Qh){return mE}else if(b==Rh){return nE}else if(b==Xh){return pE}else if(b==_h){return qE}else if(fe(a,2)){return iE}throw new iK}
function Fy(b,c){var d,e,f,g,i;g=new cH(c);if(yx(b.u,0,2)||yx(b.u,1,2)){b.d=g;Hy(b);if(b.j.b.c==0){Gy(b)}else{i=new JP(b.j);for(e=new IM(i.b);e.c<e.e.cd();){d=de(GM(e),28);try{d.rc(null)}catch(a){a=ej(a);if(fe(a,64)){f=a;tD(b.i,!f?new Gl(VS):fe(f,10)?de(f,10):new Rq(f))}else throw a}}}}else{ck(new Kv(g),1)}return g}
function Dd(b,c){var d,e,f,g,i;if(!c){throw new QK('Cannot fire null event')}try{++b.c;g=Fd(b,c.E());d=null;i=b.d?g.je(g.cd()):g.ie();while(b.d?i.xe():i.re()){f=b.d?i.ye():i.se();try{c.D(de(f,4))}catch(a){a=ej(a);if(fe(a,74)){e=a;!d&&(d=new zO);wO(d,e)}else throw a}}if(d){throw new Nd(d)}}finally{--b.c;b.c==0&&Hd(b)}}
function xj(a){var b,c,d,e,f;if(isNaN(a)){return Rj(),Qj}if(a<-9223372036854775808){return Rj(),Oj}if(a>=9223372036854775807){return Rj(),Nj}e=false;if(a<0){e=true;a=-a}d=0;if(a>=17592186044416){d=je(a/17592186044416);a-=d*17592186044416}c=0;if(a>=4194304){c=je(a/4194304);a-=c*4194304}b=je(a);f=ij(b,c,d);e&&oj(f);return f}
function Mj(a){var b,c,d,e,f;if(a.l==0&&a.m==0&&a.h==0){return NQ}if(a.h==524288&&a.m==0&&a.l==0){return '-9223372036854775808'}if(a.h>>19!=0){return OQ+Mj(Ej(a))}c=a;d=IQ;while(!(c.l==0&&c.m==0&&c.h==0)){e=yj(1000000000);c=jj(c,e,true);b=IQ+Lj(fj);if(!(c.l==0&&c.m==0&&c.h==0)){f=9-b.length;for(;f>0;--f){b=NQ+b}}d=b+d}return d}
function du(b,c){var d,e,f,g,i,j,k;d=c.f;try{e=hu(b,c.Vd());j=ZA(d,e,c.o);k=de(b.p.ad(j),35);if(!k){g=c.o;i=new YA(d,e,g,c.c);k=new eB(i);cB(k,b.j);dB(k,b.i);k.b=b;b.p.bd(j,k);i.g==null&&b.n.bd(i.g!=null?DS+i.g:DS+(i.j==0&&(i.j=VA++),i.j),k);b.b=new BN(Io(b.p))}yv(k.e,c)}catch(a){a=ej(a);if(fe(a,10)){f=a;tD(b.g,f)}else throw a}}
function zk(){var d=$wnd.onbeforeunload;var e=$wnd.onunload;$wnd.onbeforeunload=function(a){var b,c;try{b=FQ(qk)()}finally{c=d&&d(a)}if(b!=null){return b}if(c!=null){return c}};$wnd.onunload=FQ(function(a){try{kk&&md((!lk&&(lk=new yk),lk))}finally{e&&e(a);$wnd.onresize=null;$wnd.onscroll=null;$wnd.onbeforeunload=null;$wnd.onunload=null}})}
function vA(a){var b,c,d,e;if(yx(a.f,4,1)){e=new BN(Io(a.g));for(c=new IM(e);c.c<c.e.cd();){b=de(GM(c),33);pG(a.b,b.b)}pu(a.c);if(yx(a.f,1,2)){BD(a.e);while(a.f.b.b==2){d=de(sI(a.d),27);if(!d){break}nu(a.c,d)}}else{throw new mK('State changed illegally while starting')}}else if(a.f.b.b==3){throw new mK('Stop must complete before starting')}}
function qs(a,b,c){var d,e,f,g;if(!a.z){throw new Vl('Properties not writable')}if(!(b!=null&&!nL(IQ,b)&&(new RegExp('^(^[A-Za-z_$][A-Za-z0-9_$]*)$')).test(b)&&!xO(_r,b.toUpperCase()))){throw new jK("Invalid property name: '"+b+"'")}!a.r&&(a.r=new cC);g=gs(a,b);!!g&&wN(a.r.c,g);d=rH(b);e=xE(c);f=null;e!=(tE(),oE)&&(f=Vk(uE(e,c)));a.r.$d(d,e,f)}
function eG(a){var b,c,d,e;c=a.indexOf('/');e=a.substr(0,c+1-0);if(a.indexOf($S)==0){d=LS}else if(a.indexOf(bT)==0){d=LS}else if(a.indexOf(cT)==0){d=MS}else if(a.indexOf('rt/')==0){d=NS}else if(a.indexOf(_S)==0){d=HS}else if(a.indexOf(aT)==0){d=IS}else if(a.indexOf('rq/')==0){d=JS}else{throw new Gn('Unknown subscription ID: '+a)}b=rL(a,e,d);return b}
function Oy(a,b,c,d){var e,f,g,i;By(a);if(fe(b,15)){throw new aM('Durable Subscribers are not supported for temporary topics')}Dy(a);e=de(a.x.ad(c),18);if(e){g="Duplicate durable subscriber '"+c+"', must close the original TopicSubscriber first";throw new Gl(g)}i=new NB(de(b,40),c,d,a.b,a,a.t);f=new Pz(a,i);i.k=f;_w(i,a.i);Ky(i.i,i);Ly(i.i,i);return i}
function pG(a,b){var c,d,e,f,g,i,j;j=b.g;j==null&&(j=uL(b.g!=null?DS+b.g:DS+WA(b),4));e=de(a.r.ad(j),48);if(!e){e=new EG(j);a.r.bd(j,e)}else{if(e.d){e.d=null;return}}f=new xo((yq(),uq));c=b.c.Ld();oo(f,IR,c);d=b.d;d!=null&&oo(f,$R,d);oo(f,iS,qJ(b.b<<24>>24));g=b.e;g!=null&&oo(f,kS,g);i=b.g!=null?DS+b.g:DS+WA(b);i!=null&&oo(f,TR,II(i));qy(a.s,new BG(a,f))}
function XK(){XK=VP;var a;TK=Wd(Ni,pQ,-1,[-1,-1,30,19,15,13,11,11,10,9,9,8,8,8,8,7,7,7,7,7,7,7,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5]);UK=Vd(Ni,pQ,-1,37,1);VK=Wd(Ni,pQ,-1,[-1,-1,63,40,32,28,25,23,21,20,19,19,18,18,17,17,16,16,16,15,15,15,15,14,14,14,14,14,14,13,13,13,13,13,13,13,13]);WK=Vd(Oi,pQ,-1,37,3);for(a=2;a<=36;++a){UK[a]=je(NK(a,TK[a]));WK[a]=vj(AQ,yj(UK[a]))}}
function mj(a,b,c,d,e,f){var g,i,j,k,n,o,p;k=pj(b)-pj(a);g=Hj(b,k);j=ij(0,0,0);while(k>=0){i=sj(a,g);if(i){k<22?(j.l|=1<<k,undefined):k<44?(j.m|=1<<k-22,undefined):(j.h|=1<<k-44,undefined);if(a.l==0&&a.m==0&&a.h==0){break}}n=g.m;o=g.h;p=g.l;g.h=o>>>1;g.m=n>>>1|(o&1)<<21;g.l=p>>>1|(n&1)<<21;--k}c&&oj(j);if(f){if(d){fj=Ej(a);e&&(fj=Jj(fj,(Rj(),Pj)))}else{fj=ij(a.l,a.m,a.h)}}return j}
function RC(a,b){var c,d,e,f;JI&&JI&&dH('IN:  '+b);switch(b.e.c){case 12:e=!a.f&&!a.j;c=a.j;a.f=true;a.j=false;zC(a.i,b);e?zD(a.k.c):c?vC(a.k):yC(a.k);break;case 19:f=de(!b.g?null:b.g.ad(_R),54);if(!!f&&f.b){a.j=true;uC(a.k)}else{a.e.b.b!=3&&(a.r=true)}zC(a.i,b);break;case 23:if(a.f){zC(a.i,b)}else{d=de(!b.g?null:b.g.ad(LQ),1);nL(UQ,d)?uD(a.k.c):wC(a.k,d)}break;default:zC(a.i,b);}}
function yn(a,b,c){var d,e,f,g,i,j,k,n;j=NI(a);if(j==0){return}k=Vd(Si,cQ,45,j,0);for(e=0;e<~~((j+1)/2);++e){d=a.get();Xd(k,e*2,(tE(),rE)[(d&240)>>4<<24>>24]);e*2<j-1&&Xd(k,e*2+1,rE[(d&15)<<24>>24])}f=0;for(e=0;e<j;++e){fe(b,44)&&(f=NI(a));g=NI(a);i=Vk(a.getBytes(g));n=null;if(c){if(k[e]!=(tE(),oE)){g=k[e].ee();g==-1&&(g=NI(a));n=Vk(a.getBytes(g))}}fe(b,44)?iC(de(b,44),f<<24>>24,i,k[e],n):b.$d(i,k[e],n)}}
function mw(a,b){var c,d;c=lw(a,b);if(c==null){return (new FK(iJ(null))).b}else if(fe(c,68)){d=de(c,68).b;tE();if(!(Aj(d,mQ)&&Cj(d,nQ))){throw new Gl(zS+Mj(d)+AS)}return d}else if(fe(c,67)){return yj(de(c,67).b)}else if(fe(c,71)){return yj(de(c,71).b)}else if(fe(c,55)){return yj(de(c,55).b)}else if(fe(c,1)){d=iJ(de(c,1));tE();if(!(Aj(d,mQ)&&Cj(d,nQ))){throw new Gl(zS+Mj(d)+AS)}return d}else throw new Rl(RS)}
function wo(a){var b,c,d,e,f,g,i,j;g=IQ;i=IQ;d=IQ;for(f=SM(Go(a.g));f.b.re();){e=de(YM(f),1);j=a.g.ad(e);nL(YR,e)&&j!=null?(g+=e+':********'):(g+=e+nS+(fe(j,2)?UN(de(j,2)):IQ+j));g+=oS}if(a.d.b.cd()!=0){d='Extensions = ';for(c=SM(Go(a.d.b));c.b.re();){b=de(YM(c),46);d+=pS+b.d+'} '}}!!a.o&&a.o.c.c!=0&&(i='Named-Properties = '+bC(a.o)+oS);return qS+a.e+rS+g+i+'body='+(!a.b||!a.b.hasRemaining()?'<empty>':tH(a.b))+d+QR}
function Jx(a,b,c,d,e,f,g){var i;Hx(a);if(a.i){throw new Jl('Message send already in progress')}if(!b){if(!a.d){throw new aM('A destination must be specified')}b=a.d}else if(!!a.d&&b!=a.d){throw new aM('Destination cannot be specified when producer destination is already set')}Ix(b);c.fc(b);d!=2&&c.ec(d);e!=4&&c.ic(e);c.gc(f);i=xj((new Date).getTime());c.lc(i);de(c,27).Kd(false);a.i=new cH(g);Sy(a.g,a,de(c,27));return a.i}
function sp(){So(this);Zo(this,iS,(Mq(),Eq));Zo(this,WR,Kq);Zo(this,aS,Iq);Zo(this,dS,Fq);Zo(this,IR,Kq);Zo(this,$R,Kq);Zo(this,cS,Jq);Zo(this,lS,Lq);Zo(this,MR,Gq);Zo(this,_R,Dq);Zo(this,XR,Kq);Zo(this,LQ,Kq);Zo(this,VR,Kq);Zo(this,jS,Dq);Zo(this,YR,Fq);Zo(this,JR,Eq);Zo(this,NR,Gq);Zo(this,TR,Fq);Zo(this,gS,Kq);Zo(this,hS,Iq);Zo(this,eS,Kq);Zo(this,kS,Kq);Zo(this,ZR,Kq);Zo(this,HR,Lq);Zo(this,bS,Jq);Zo(this,UR,Kq);Zo(this,fS,Kq)}
function dj(){var a;!!$stats&&Yj('com.google.gwt.useragent.client.UserAgentAsserter');a=Ak();nL(MQ,a)||($wnd.alert('ERROR: Possible problem with your *.gwt.xml module file.\nThe compile time user.agent value (opera) does not match the runtime user.agent value ('+a+'). Expect more errors.\n'),undefined);!!$stats&&Yj('com.google.gwt.user.client.DocumentModeAsserter');Zj();!!$stats&&Yj('com.kaazing.gateway.jms.client.entry.Entry');ym()}
function vn(a,b){var c,d,e,f,g,i,j,k,n,o,p,q,r,s,t,u;o=b.c;p=o.c;if(p==0){return}q=LI(p);a.putBytes(q);g=a.position;i=~~((p+1)/2);a.skip(i);j=Vd(Li,fQ,-1,i,1);f=0;for(n=new IM(o);n.c<n.e.cd();){k=de(GM(n),50);c=k.b;d=c.remaining();e=LI(d);a.putBytes(e);a.putBuffer(c);r=k.c.b;f%2==0?(j[~~(f/2)]=r<<4<<24>>24):(j[~~(f/2)]=j[~~(f/2)]|r);++f;if(k.c!=(tE(),oE)){s=k.d;if(k.c.ee()==-1){t=s.remaining();u=LI(t);a.putBytes(u)}a.putBuffer(s)}}a.putBytesAt(g,j)}
function Gy(b){var c,d,e,f,g,i,j;zx(b.u,3);for(i=cN(Io(b.q));i.b.re();){g=de(iN(i),30);Lx(g,'Send aborted')}if(b.y){for(f=cN(Io(b.A));f.b.re();){e=de(iN(f),42);c=new aH(WS+e.c);tD(b.i,!c?new Gl(VS):c?c:new Rq(null))}if(b.z){j=new aH(WS+b.z.c);if(b.e){try{br(b.e,j)}catch(a){a=ej(a);if(fe(a,64)){d=a;tD(b.i,!d?new Gl(VS):fe(d,10)?de(d,10):new Rq(d))}else throw a}}tD(b.i,!j?new Gl(VS):j?j:new Rq(null))}}CD(b.s,b);try{ck(new Kv(b.d),1)}finally{b.d=null}}
function tL(o,a,b){var c=new RegExp(a,mT);var d=[];var e=0;var f=o;var g=null;while(true){var i=c.exec(f);if(i==null||f==IQ||e==b-1&&b>0){d[e]=f;break}else{d[e]=f.substring(0,i.index);f=f.substring(i.index+i[0].length,f.length);c.lastIndex=0;if(g==f){d[e]=f.substring(0,1);f=f.substring(1)}g=f;e++}}if(b==0&&o.length>0){var j=d.length;while(j>0&&d[j-1]==IQ){--j}j<d.length&&d.splice(j,d.length-j)}var k=xL(d.length);for(var n=0;n<d.length;++n){k[n]=d[n]}return k}
function Iy(b,c){var d,e,f,g,i,j,k,n;By(b);if(!b.y){throw new mK('Attempted to commit transaction in non-transacted session')}if(!b.z){throw new Gl(XS)}if(b.e){throw new mK('CommitFuture already defined')}n=b.z.c;e=new cH(new _z(b,n,c));b.e=e;try{mA(b.p,n);for(g=rI(b.z.b,0);g.c!=g.e.b;){f=de(qP(g),27);i=YS+wy.b++;f.ld(i);f.Jd(n);qA(b.p,f)}i=ZS+n;b.A.bd(n,b.z);nA(b.p,n,i)}catch(a){a=ej(a);if(fe(a,64)){d=a;try{j='RBK:'+n;xA(b.p,n,j)}finally{k=new Xl(d.C());Xc(k);k.b=d;e.c=k;_q(e)}}else throw a}return e}
function xn(a,b){var c,d,e,f,g,i,j,k,n;d=new np;e=0;if(Go(b.b).c.cd()>7){c=15;g=a.getUnsignedShort();(g&1)>0&&(e=a.getUnsignedShort())}else{c=7;g=a.get();(g&1)!=0&&(e=a.get())}for(f=0;f<c;++f){if((g&1<<c-f)!=0&&(e&1<<c-f)!=0){d.bd(qJ(f),null)}else if((g&1<<c-f)!=0&&(e&1<<c-f)==0){i=de(b.b.ad(qJ(f)),50);if(!i){throw new Gn(PR+f+QR)}j=i.c;if(j!=(tE(),oE)){n=j.ee()==-1?NI(a):j.ee();if(n>0){k=a.getBytes(n);d.bd(qJ(f),Kaazing.ByteBuffer.wrap(k))}else{d.bd(qJ(f),new Kaazing.ByteBuffer)}}else{d.bd(qJ(f),null)}}}return d}
function Dn(a,b,c){var d,e,f,g,i,j,k,n;e=0;if(Go(c.b).c.cd()>7){d=15;g=a.getUnsignedShort();(g&1)>0&&(e=a.getUnsignedShort())}else{d=7;g=a.get();(g&1)!=0&&(e=a.get())}for(f=0;f<d;++f){if((g&1<<d-f)!=0&&(e&1<<d-f)!=0){b.bd(qJ(f),null)}else if((g&1<<d-f)==0&&(e&1<<d-f)!=0){b.id(qJ(f))}else if((g&1<<d-f)!=0&&(e&1<<d-f)==0){i=de(c.b.ad(qJ(f)),50);j=i.c;if(j!=(tE(),oE)){n=j.ee()==-1?NI(a):j.ee();if(n>0){k=a.getBytes(n);b.bd(qJ(f),Kaazing.ByteBuffer.wrap(k))}else{b.bd(qJ(f),new Kaazing.ByteBuffer)}}else{b.bd(qJ(f),null)}}}}
function An(a,b){var c,d,e;d=IQ;switch(de(Vo((lo(),ko),a),21).c){case 0:d=qJ(b.get());break;case 3:d=AK(b.getInt());break;case 4:d=KK((qH(),uH(b.get(),b.get(),b.get(),b.get(),b.get(),b.get(),b.get(),b.get())));break;case 1:c=NI(b);c>0?(d=(qH(),e=Vd(Li,fQ,-1,c,1),Fk(b,e,b.position,c),Kk(b,b.position+c),e)):(d=Vd(Li,fQ,-1,0,1));break;case 5:c=NI(b);c>0&&(d=Zk(b.getBytes(c)));break;case 8:d=AK(NI(b));break;case 2:d=(YI(),b.get()!=48?XI:WI);break;default:throw new Gn('Error retrieve header value for '+a+' wrong type '+Vo(ko,a));}return d}
function NI(a){var b,c,d,e,f,g,i,j,k,n,o,p,q,r;b=a.get();i=MI(b);r=0;switch(i){case 1:{r=b;break}case 2:{c=a.get();k=b&31;j=c&63;r=k<<6|j;break}case 3:{c=a.get();d=a.get();n=b&15;k=c&63;j=d&63;r=n<<12|k<<6|j;break}case 4:{c=a.get();d=a.get();e=a.get();o=b&7;n=c&63;k=d&63;j=e&63;r=o<<18|n<<12|k<<6|j;break}case 5:{c=a.get();d=a.get();e=a.get();f=a.get();p=b&3;o=c&63;n=d&63;k=e&63;j=f&63;r=p<<24|o<<18|n<<12|k<<6|j;break}case 6:{c=a.get();d=a.get();e=a.get();f=a.get();g=a.get();q=b&1;p=c&63;o=d&63;n=e&63;k=f&63;j=g&63;r=q<<30|p<<24|o<<18|n<<12|k<<6|j;break}}return r}
function Ak(){var b=navigator.userAgent.toLowerCase();var c=function(a){return parseInt(a[1])*1000+parseInt(a[2])};if(function(){return b.indexOf(MQ)!=-1}())return MQ;if(function(){return b.indexOf('webkit')!=-1}())return 'safari';if(function(){return b.indexOf(QQ)!=-1&&$doc.documentMode>=9}())return 'ie9';if(function(){return b.indexOf(QQ)!=-1&&$doc.documentMode>=8}())return 'ie8';if(function(){var a=/msie ([0-9]+)\.([0-9]+)/.exec(b);if(a&&a.length==3)return c(a)>=6000}())return 'ie6';if(function(){return b.indexOf('gecko')!=-1}())return 'gecko1_8';return 'unknown'}
function jj(a,b,c){var d,e,f,g,i,j;if(b.l==0&&b.m==0&&b.h==0){throw new SI}if(a.l==0&&a.m==0&&a.h==0){c&&(fj=ij(0,0,0));return ij(0,0,0)}if(b.h==524288&&b.m==0&&b.l==0){return kj(a,c)}j=false;if(b.h>>19!=0){b=Ej(b);j=true}g=qj(b);f=false;e=false;d=false;if(a.h==524288&&a.m==0&&a.l==0){e=true;f=true;if(g==-1){a=hj((Rj(),Nj));d=true;j=!j}else{i=Ij(a,g);j&&oj(i);c&&(fj=ij(0,0,0));return i}}else if(a.h>>19!=0){f=true;a=Ej(a);d=true;j=!j}if(g!=-1){return lj(a,g,j,f,c)}if(!Aj(a,b)){c&&(f?(fj=Ej(a)):(fj=ij(a.l,a.m,a.h)));return ij(0,0,0)}return mj(d?a:ij(a.l,a.m,a.h),b,j,f,e,c)}
function Dj(a,b){var c,d,e,f,g,i,j,k,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F;c=a.l&8191;d=a.l>>13|(a.m&15)<<9;e=a.m>>4&8191;f=a.m>>17|(a.h&255)<<5;g=(a.h&1048320)>>8;i=b.l&8191;j=b.l>>13|(b.m&15)<<9;k=b.m>>4&8191;n=b.m>>17|(b.h&255)<<5;o=(b.h&1048320)>>8;B=c*i;C=d*i;D=e*i;E=f*i;F=g*i;if(j!=0){C+=c*j;D+=d*j;E+=e*j;F+=f*j}if(k!=0){D+=c*k;E+=d*k;F+=e*k}if(n!=0){E+=c*n;F+=d*n}o!=0&&(F+=c*o);q=B&4194303;r=(C&511)<<13;p=q+r;t=B>>22;u=C>>9;v=(D&262143)<<4;w=(E&31)<<17;s=t+u+v+w;y=D>>18;z=E>>5;A=(F&4095)<<8;x=y+z+A;s+=p>>22;p&=4194303;x+=s>>22;s&=4194303;x&=1048575;return ij(p,s,x)}
function oo(a,b,c){var d,e,f,g,i,j;if(nL(HR,b)&&fe(c,67)){a.g.bd(b,c);return}if(nL(IR,b)&&fe(c,1)){a.g.bd(b,c);return}d=false;j=false;if(nL(b,KR)||nL(b,LR)){if(fe(c,54)){a.g.bd(b,c);return}else{throw new jK(mS+b+'], header type does not match (Boolean)')}}for(f=Un[a.e.c],g=0,i=f.length;g<i;++g){e=f[g];if(nL(e,b)){d=true;switch(de(Vo(ko,b),21).c){case 2:j=fe(c,54);break;case 0:j=fe(c,55);break;case 1:j=c==null||fe(c,2);break;case 3:case 8:j=fe(c,67);break;case 4:j=fe(c,68);break;case 5:j=c==null||fe(c,1);}break}}if(d){if(j){a.g.bd(b,c)}else{throw new jK(mS+b+'], header type does not match')}}else{throw new jK(mS+b+'], header name not supported')}}
function iJ(a){var b,c,d,e,f,g,i,j,k,n,o;if(a==null){throw new ZK(JQ)}k=a;f=a.length;j=f>0&&a.charCodeAt(0)==45;if(j){a=uL(a,1);--f}if(f==0){throw new ZK(lT+k+SR)}while(a.length>0&&a.charCodeAt(0)==48){a=uL(a,1);--f}if(f>(XK(),VK)[10]){throw new ZK(lT+k+SR)}for(e=0;e<f;++e){b=a.charCodeAt(e);if(b>=48&&b<58){continue}if(b>=97&&b<97){continue}if(b>=65&&b<65){continue}throw new ZK(lT+k+SR)}o=lQ;g=TK[10];n=yj(UK[10]);i=Ej(WK[10]);c=true;d=f%g;if(d>0){o=yj(-jJ(a.substr(0,d-0),10));a=uL(a,d);f-=d;c=false}while(f>=g){d=jJ(a.substr(0,g-0),10);a=uL(a,g);f-=g;if(c){c=false}else{if(!Aj(o,i)){throw new ZK(a)}o=Dj(o,n)}o=Jj(o,yj(d))}if(zj(o,lQ)){throw new ZK(lT+k+SR)}if(!j){o=Ej(o);if(Bj(o,lQ)){throw new ZK(lT+k+SR)}}return o}
function gG(b,c){var d,e,f,g,i,j,k,n,o,p,q,r,s,t,u,v,w;try{if(fe(c,39)){n=new xo((yq(),rq));mo(n,Vk(c.zd()))}else if(fe(c,25)){n=new xo((yq(),lq));p=de(c,25);e=new cC;q=nw(p);while(q.b.b.re()){o=de(YM(q.b),1);w=ow(p,o);e._d(o,w)}n.n=e}else{n=new xo((yq(),jq));d=c.zd();d!=null&&mo(n,Kaazing.ByteBuffer.wrap(d))}i=c.Bd();oo(n,IR,i.Ld());u=c.Fd();u!=null&&oo(n,UR,u);s=c.jd();s!=null&&oo(n,TR,II(s));g=c.Lb();r=c.Pb();if(g!=2||r!=4){oo(n,KR,g==2?(YI(),XI):(YI(),WI));oo(n,JR,new lJ(r<<24>>24))}f=c.Kb();f!=null&&oo(n,dS,II(f));v=c.Tb();v!=null&&oo(n,fS,v);t=c.Cd();!!t&&oo(n,eS,t.Ld());k=c.Nb();Fj(k,lQ)&&oo(n,cS,KK(k));to(n,c.Dd());qy(b.s,new BG(b,n))}catch(a){a=ej(a);if(fe(a,64)){j=a;tD(b.e,!j?new Gl(VS):fe(j,10)?de(j,10):new Rq(j))}else throw a}}
function aG(a,b){var c,d,e,f,g,i,j,k,n,o,p,q;i=de(!b.g?null:b.g.ad(gS),1);o=de(!b.g?null:b.g.ad(HR),67);if(i==null){throw new Gn('Missing receipt-id header')}f=i.substr(0,4-0);if(nL(QS,f)){d=i.indexOf(oS,4);if(d<0){throw new Gn('Acknowledgement receipt received with invalid format')}c=new sr;c.A=i;lr(c,i.substr(4,d-4));rr(c,uL(i,d+1));e=de(!b.g?null:b.g.ad('max-pending-acks'),1);e!=null&&(hJ(e,-2147483648,2147483647),undefined);return c}else if(nL(DS,f)){k=uL(i,4);j=de(a.r.ad(k),48);if(!j){throw new mK('Subscription entry not found for key: '+k)}j.b=o;a.q.bd(o,j);n=new RA;n.A=i;n.B=k;!!j.d&&j.d.c.b&&py(j.d);return n}else if(nL(PS,f)){p=AK(hJ(uL(i,4),-2147483648,2147483647));j=de(a.q.id(p),48);if(!j){throw new Gl('Subscription not found to receipt '+i)}bG(a,p.b);q=new UB;q.A=i;lr(q,j.c);return q}else{g=new pr;g.A=i;return g}}
function LI(a){var b,c;if((a&-128)==0){b=Vd(Li,fQ,-1,1,1);b[0]=a<<24>>24}else if((a&-2048)==0){b=Vd(Li,fQ,-1,2,1);b[0]=(192|a>>6)<<24>>24;b[1]=(128|a&63)<<24>>24}else if((a&-65536)==0){b=Vd(Li,fQ,-1,3,1);b[0]=(224|a>>12)<<24>>24;b[1]=(128|a>>6&63)<<24>>24;b[2]=(128|a&63)<<24>>24}else if((a&-14680064)==0){b=Vd(Li,fQ,-1,4,1);b[0]=(240|a>>18)<<24>>24;b[1]=(128|a>>12&63)<<24>>24;b[2]=(128|a>>6&63)<<24>>24;b[3]=(128|a&63)<<24>>24}else if((a&-201326592)==0){b=Vd(Li,fQ,-1,5,1);b[0]=(248|a>>24)<<24>>24;b[1]=(128|a>>18&63)<<24>>24;b[2]=(128|a>>12&63)<<24>>24;b[3]=(128|a>>6&63)<<24>>24;b[4]=(128|a&63)<<24>>24}else if((a&-2147483648)==0){b=Vd(Li,fQ,-1,6,1);b[0]=(252|a>>30)<<24>>24;b[1]=(128|a>>24&63)<<24>>24;b[2]=(128|a>>18&63)<<24>>24;b[3]=(128|a>>12&63)<<24>>24;b[4]=(128|a>>6&63)<<24>>24;b[5]=(128|a&63)<<24>>24}else{c='Value cannot be encoded as UTF-8 sequence: '+yK(a);throw new mK(c)}return b}
function Zj(){var a,b,c;b=$doc.compatMode;a=Wd(bj,dQ,1,[PQ]);for(c=0;c<a.length;++c){if(nL(a[c],b)){return}}a.length==1&&nL(PQ,a[0])&&nL('BackCompat',b)?"GWT no longer supports Quirks Mode (document.compatMode=' BackCompat').<br>Make sure your application's host HTML page has a Standards Mode (document.compatMode=' CSS1Compat') doctype,<br>e.g. by using &lt;!doctype html&gt; at the start of your application's HTML page.<br><br>To continue using this unsupported rendering mode and risk layout problems, suppress this message by adding<br>the following line to your*.gwt.xml module file:<br>&nbsp;&nbsp;&lt;extend-configuration-property name=\"document.compatMode\" value=\""+b+'"/&gt;':"Your *.gwt.xml module configuration prohibits the use of the current doucment rendering mode (document.compatMode=' "+b+"').<br>Modify your application's host HTML page doctype, or update your custom 'document.compatMode' configuration property settings."}
function Cn(a,b){rn();var c,d,e,f,g,i,j,k,n,o,p,q,r,s,t;e=b.b;g=b.c;c=(lo(),Un)[b.e.c];if(g!=0){for(j=0;j<c.length;++j){(g&1<<15-j)!=0&&a.g.id(c[j])}}if(b.g.cd()!=0){i=a.g;for(r=SM(Go(b.g));r.b.re();){q=de(YM(r),1);if(nL(JR,q)){d=e.get();if((d&63)>0){i.bd(JR,AK(d&15));i.bd(KR,(YI(),(d&16)>0?XI:WI));i.bd(LR,(d&32)>0?XI:WI)}}else{i.bd(q,!b.g?null:b.g.ad(q))}}}if(!!b.p&&Go(b.p.b).c.cd()!=0){if(!a.p){uo(a,b.p)}else{o=Go(b.p.b);for(n=SM(o);n.b.re();){k=de(YM(n),55).b;RM(Go(a.p.b),o)&&lC(a.p,k);t=kC(b.p,k);jC(a.p,k,t)}}}if(!!b.k&&Go(b.k.b).c.cd()!=0){if(!a.k){ro(a,b.k)}else{o=Go(b.k.b);for(n=SM(o);n.b.re();){k=de(YM(n),55).b;RM(Go(a.k.b),o)&&lC(a.k,k);t=kC(b.k,k);jC(a.k,k,t)}}}if((b.f&8)>0){!a.j&&qo(a,new np);s=a.j;f=a.p;Dn(e,s,f)}if((b.f&4)>0){!a.o&&to(a,new cC);s=a.o;En(e,s)}if((b.f&2)>0){!a.i&&po(a,new np);s=a.i;f=a.k;Dn(e,s,f)}if((b.f&1)>0){if(b.e.b.indexOf(OR)!=-1){!a.n&&so(a,new cC);s=a.n;En(e,s)}else{p=NI(e);p>0?mo(a,Vk(e.getBytes(p))):(a.b=null)}}}
function iG(b,c){var d,e,f,g,i,j,k,n,o,p,q,r;switch(c.e.c){case 12:d=new Xu;b.b=de(!c.g?null:c.g.ad(ZR),1);d.b=b.b;b.g&&(b.g=false);b.f=c.d;d.e=b.f.me((HF(),EF));if(b.f.me(BF)){for(j=b.f.he();j.re();){i=de(j.se(),46);i.b==(TF(),OF)&&(d.c=!i.c?null:de(i.c.ad('format'),1))}}if(b.i){d.d=b.i;b.i=false}rA(b.o,d);break;case 19:e=new uv;k=de(!c.g?null:c.g.ad(_R),54);if(!!k&&k.b){b.i=true;e.b=true}sA(b.o,e);break;case 8:case 9:case 10:case 16:case 17:case 18:case 32:case 33:case 34:try{(c.e==(yq(),Rp)||c.e==Vp||c.e==eq)&&(q=c.q,b.n.bd(AK(q),c),undefined);if(c.e==Qp||c.e==Up||c.e==dq){p=(r=c.q,de(b.n.ad(AK(r)),19));if(!p){throw new Gn('error processing delta message: snapshot frame does not exist for subscription ['+(!c.g?null:c.g.ad(HR))+QR)}c=hG(p,c)}n=_F(b,c);tA(b.o,n)}catch(a){a=ej(a);if(fe(a,64)){f=a;tD(b.e,!f?new Gl(VS):fe(f,10)?de(f,10):new Rq(f))}else throw a}break;case 35:try{o=aG(b,c);uA(b.o,o)}catch(a){a=ej(a);if(fe(a,64)){f=a;tD(b.e,!f?new Gl(VS):fe(f,10)?de(f,10):new Rq(f))}else throw a}break;case 23:{n=de(!c.g?null:c.g.ad(LQ),1);g=new Hn('Gateway Reported Error: '+n,IQ+(!c.g?null:c.g.ad(aS)));Xc(g);tD(b.e,g)}}}
function lo(){lo=VP;Jn=Wd(bj,dQ,1,[TR,UR]);Ln=Wd(bj,dQ,1,[VR,TR,HR,UR]);Kn=Wd(bj,dQ,1,[IR,TR]);Mn=Wd(bj,dQ,1,[TR,UR]);Nn=Wd(bj,dQ,1,[TR,UR]);Pn=Wd(bj,dQ,1,[WR,XR,YR]);On=Wd(bj,dQ,1,[ZR]);Qn=Wd(bj,dQ,1,[IR,TR]);Rn=Wd(bj,dQ,1,[IR,$R,TR]);Sn=Wd(bj,dQ,1,[_R]);Tn=Wd(bj,dQ,1,[aS,LQ,TR]);Wn=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR]);Vn=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR]);Xn=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR]);Zn=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR,MR]);Yn=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR,MR]);$n=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR,MR]);ao=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR]);_n=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR]);bo=Wd(bj,dQ,1,[bS,cS,JR,dS,VR,eS,fS,NR]);co=Wd(bj,dQ,1,[gS,HR]);eo=Wd(bj,dQ,1,[IR,hS]);fo=Wd(bj,dQ,1,[JR,dS,IR,cS,TR,eS,UR,fS]);go=Wd(bj,dQ,1,[JR,dS,IR,cS,TR,eS,UR,fS]);ho=Wd(bj,dQ,1,[JR,dS,IR,cS,TR,eS,UR,fS]);io=Wd(bj,dQ,1,[iS,IR,$R,jS,TR,kS]);jo=Wd(bj,dQ,1,[lS,TR]);Un=Wd(cj,cQ,73,[Wd(bj,dQ,1,[]),Jn,Ln,Mn,Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Nn,Wn,Vn,Xn,Pn,On,Qn,Rn,Wd(bj,dQ,1,[]),Zn,Yn,$n,Sn,Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Tn,Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),fo,Wd(bj,dQ,1,[]),ao,_n,bo,co,go,Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),Wd(bj,dQ,1,[]),ho,Wd(bj,dQ,1,[]),io,Wd(bj,dQ,1,[]),jo,Wd(bj,dQ,1,[]),Kn,eo]);ko=new sp}
function un(a){var b,c,d,e,f,g,i,j,k,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N;r=0;o=a.e;x=o==(yq(),Hp);t=1;s=7;switch(o.c){case 30:case 42:case 36:++t;s=15;}g=7+(x?1:0)+t;f=new Kaazing.ByteBuffer.allocate(g);f.skip(g);v=a.g;F=0;v.$c(JR)&&(F=de(!a.g?null:a.g.ad(JR),55).b);if(v.$c(KR)){K=de(!a.g?null:a.g.ad(KR),54);K.b&&(F=(F|16)<<24>>24)}if(v.$c(JR)||v.$c(KR)){r=0|1<<s;f.put(F)}if(!!a.g&&a.g.cd()!=0){for(z=(lo(),Un)[o.c],A=0,B=z.length;A<B;++A){y=z[A];if(v.$c(y)&&!nL(JR,y)){u=!a.g?null:a.g.ad(y);if(u!=null){r=r|1<<s;switch(de(Vo(ko,y),21).c){case 0:Lk(f,de(u,55).b);break;case 3:Ok(f,de(u,67).b);break;case 4:vH(f,de(u,68).b);break;case 1:C=de(u,2).length;D=LI(C);f.putBytes(D);C>0&&Nk(f,de(u,2));break;case 5:L=II(zc(u));M=L.length;N=LI(M);f.putBytes(N);M>0&&f.putBytes(L);break;case 2:Lk(f,de(u,54).b?49:48);break;case 8:w=LI(de(u,67).b);f.putBytes(w);break;default:throw new jK('unsupported header value type');}}}--s}}if(!!a.o&&a.o.c.c!=0){r=r|4;vn(f,a.o)}if(!!a.n&&a.n.c.c!=0){r=r|1;vn(f,a.n)}if(a.b){r=r|1;c=a.b;d=c.remaining();e=LI(d);f.putBytes(e);f.putBuffer(c)}if(!!a.d&&a.d.b.cd()!=0){k=a.d.b.cd();n=LI(k);f.putBytes(n);for(j=SM(Go(a.d.b));j.b.re();){i=de(YM(j),46);Lk(f,i.b.c<<24>>24);if(!!i.c&&i.c.cd()!=0){J=zn(i.c);G=II(J);H=G.length;I=LI(H);f.putBytes(I);f.putBytes(G)}else{f.put(0)}}}p=(x?1:0)+t+(f.position-g);q=LI(p);b=1+q.length+(x?1:0)+t;E=g-b;f.position=E;Lk(f,o.c<<24>>24);f.putBytes(q);x&&f.put(1);t==2?f.putShort(r<<16>>16):f.put(r<<24>>24);f.position=E;f=f.compact();JI&&KI('Encode Result: '+f.getHexDump());return f}
function yq(){yq=VP;hq=new zq('RESERVED',0);Cp=new zq('ABORT',1);Dp=new zq('ACK',2);Fp=new zq('BEGIN',3);Op=new zq('MESSAGE',4);Sp=new zq('MESSAGE_DELTA',5);$p=new zq('MESSAGE_SNAPSHOT',6);Gp=new zq('COMMIT',7);Pp=new zq(tS,8);Qp=new zq('MESSAGE_BINARY_DELTA',9);Rp=new zq('MESSAGE_BINARY_SNAPSHOT',10);Hp=new zq('CONNECT',11);Ip=new zq('CONNECTED',12);Jp=new zq('CREATE',13);Kp=new zq('DELETE',14);Lp=new zq('DISCONNECT',15);Tp=new zq(uS,16);Up=new zq('MESSAGE_MAP_DELTA',17);Vp=new zq('MESSAGE_MAP_SNAPSHOT',18);Mp=new zq('DISCONNECTED',19);Wp=new zq('MESSAGE_OBJECT',20);Xp=new zq('MESSAGE_OBJECT_DELTA',21);Yp=new zq('MESSAGE_OBJECT_SNAPSHOT',22);Np=new zq('ERROR',23);_p=new zq('MESSAGE_STREAM',24);aq=new zq('MESSAGE_STREAM_DELTA',25);bq=new zq('MESSAGE_STREAM_SNAPSHOT',26);Zp=new zq('MESSAGE_OPAQUE',27);iq=new zq('SEND',28);tq=new zq('SEND_TRANSACTIONAL',29);jq=new zq('SEND_BINARY',30);kq=new zq('SEND_BINARY_TRANSACTIONAL',31);cq=new zq(sS,32);dq=new zq('MESSAGE_TEXT_DELTA',33);eq=new zq('MESSAGE_TEXT_SNAPSHOT',34);fq=new zq('RECEIPT',35);lq=new zq('SEND_MAP',36);mq=new zq('SEND_MAP_TRANSACTIONAL',37);nq=new zq('SEND_OBJECT',38);oq=new zq('SEND_OBJECT_TRANSACTIONAL',39);pq=new zq('SEND_STREAM',40);qq=new zq('SEND_STREAM_TRANSACTIONAL',41);rq=new zq('SEND_TEXT',42);sq=new zq('SEND_TEXT_TRANSACTIONAL',43);uq=new zq('SUBSCRIBE',44);vq=new zq('SUBSCRIBE_DURABLE',45);wq=new zq('UNSUBSCRIBE',46);xq=new zq('UNSUBSCRIBE_DURABLE',47);Ep=new zq('ACQUIRE',48);gq=new zq('RELEASE',49);Bp=Wd(Qi,jQ,20,[hq,Cp,Dp,Fp,Op,Sp,$p,Gp,Pp,Qp,Rp,Hp,Ip,Jp,Kp,Lp,Tp,Up,Vp,Mp,Wp,Xp,Yp,Np,_p,aq,bq,Zp,iq,tq,jq,kq,cq,dq,eq,fq,lq,mq,nq,oq,pq,qq,rq,sq,uq,vq,wq,xq,Ep,gq])}
function tn(a){var b,c,d,e,f,g,i,j,k,n,o,p,q,r,s,t,u,v,w,x,y,z,A;c=a.get();k=(yq(),yq(),Bp)[c&127];j=NI(a);if(j<0||j>a.remaining()){throw new Gn("frame size doesn't match buffer")}e=a.position+j;i=new xo(k);i.c=c&128;switch(k.c){case 8:case 32:case 16:oo(i,HR,AK(NI(a)));oo(i,IR,An(IR,a));n=a.getUnsignedShort();o=15;break;case 9:case 33:case 17:vo(i,NI(a));n=a.getUnsignedShort();o=15;break;case 10:case 34:case 18:vo(i,NI(a));oo(i,HR,AK(NI(a)));oo(i,IR,An(IR,a));n=a.getUnsignedShort();o=15;break;case 30:case 42:case 36:n=a.getUnsignedShort();o=15;break;case 12:A=a.get();if(A!=1){throw new Gn('Protocol error: the version - '+A+' is not supported')}default:n=a.get();o=7;}i.c!=0&&no(i,a.getUnsignedShort());if(n!=0){i.f=n;p=i.g;b=(lo(),Un)[k.c];for(q=0;q<b.length;++q){if((n&1<<o-q)>0){s=b[q];if(nL(JR,s)){c=a.get();p.bd(JR,qJ((c&15)<<24>>24));p.bd(KR,(YI(),(c&16)>0?XI:WI));p.bd(LR,(c&32)>0?XI:WI)}else if(nL(MR,s)){z=new mC;yn(a,z,false);i.k=z}else if(nL(NR,s)){z=new mC;yn(a,z,false);i.p=z}else{p.bd(s,An(s,a))}}}}if(k==Qp||k==Up||k==dq){y=Hk(a,e-a.position);mo(i,Kaazing.ByteBuffer.wrap(y));return i}o==15&&(n&8)>0&&qo(i,xn(a,i.p));if(o==15&&(n&4)>0){d=new cC;yn(a,d,true);i.o=d}o==15&&(n&2)>0&&po(i,xn(a,i.k));if(o==15&&(n&1)>0){if(k.b.indexOf(OR)!=-1){x=new cC;yn(a,x,true);i.n=x}else{r=NI(a);mo(i,Vk(a.getBytes(r)))}}if(k==Np&&(n&1)>0){r=NI(a);mo(i,Vk(a.getBytes(r)))}if(a.position<e){r=NI(a);g=i.d;for(q=0;q<r;++q){f=(HF(),CF)[a.get()];t=NI(a);if(t>0){w=new np;v=a.getBytes(t);u=Zk(v);Bn(u,w);f.c=w}wO(g,f)}}if(a.position!=e){throw new Gn('BumpCodec.decode() Error: data size not match. buffer.position() = '+a.position+', but it should be '+e)}return i}
function _F(b,c){var d,e,f,g,i,j,k,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C;try{d=c.b;if(c.e==(yq(),cq)||c.e==eq){C=Yk(XF,d);s=new CB(C,null)}else if(c.e==Tp||c.e==Vp){r=new sw(null);if(!!c.n&&c.n.c.c!=0){for(v=new IM(c.n.c);v.c<v.e.cd();){u=de(GM(v),50);lG(r,u)}}if(c.i){p=Go(c.i);for(o=SM(p);o.b.re();){n=de(YM(o),55).b;e=ee(c.i.ad(qJ(n)));if(e){x=kC(c.k,n);if(!x){throw new Gl(PR+n+QR)}mG(r,x,e)}}}r.y=false;s=r}else{s=new Gt(d.slice())}s.z=true;i=null;if((!c.g?null:c.g.ad(dS))!=null){f=de(!c.g?null:c.g.ad(dS),2);hs(s,Zk(f))}(!c.g?null:c.g.ad(IR))!=null&&(i=zc(!c.g?null:c.g.ad(IR)));(!c.g?null:c.g.ad(cS))!=null&&js(s,de(!c.g?null:c.g.ad(cS),68).b);(!c.g?null:c.g.ad(VR))!=null&&ks(s,de(!c.g?null:c.g.ad(VR),1));if((!c.g?null:c.g.ad(JR))!=null){B=de(!c.g?null:c.g.ad(JR),55).b;t=15&B;if(t<0||t>9){throw new Gl(wS+t)}ls(s,t)}(!c.g?null:c.g.ad(KR))!=null&&is(s,de(!c.g?null:c.g.ad(KR),54).b?2:1);(!c.g?null:c.g.ad(LR))!=null&&ms(s,de(!c.g?null:c.g.ad(LR),54).b);if((!c.g?null:c.g.ad(eS))!=null){y=pv(b.d,de(!c.g?null:c.g.ad(eS),1));s.t=y}if((!c.g?null:c.g.ad(HR))!=null){z=de(b.q.ad(de(!c.g?null:c.g.ad(HR),67)),48);if(z){lr(s,z.c)}else{throw new Gl('Subscription ID not found - '+(!c.g?null:c.g.ad(HR)))}}(!c.g?null:c.g.ad(fS))!=null&&os(s,de(!c.g?null:c.g.ad(fS),1));(!c.g?null:c.g.ad(bS))!=null&&ns(s,de(!c.g?null:c.g.ad(bS),68).b);(!c.g?null:c.g.ad(UR))!=null&&rs(s,de(!c.g?null:c.g.ad(UR),1));w=c.o;if(!!c.o&&c.o.c.c!=0){for(v=new IM(w.c);v.c<v.e.cd();){u=de(GM(v),50);nG(s,u)}}if(c.j){q=Go(c.p.b);for(o=SM(q);o.b.re();){n=de(YM(o),55).b;e=ee(c.j.ad(qJ(n)));x=kC(c.p,n);if(!x){throw new Gn(PR+n+QR)}oG(s,x,e)}}A=s.B;if(A==null){throw new Gn('Subscription ID missing or invalid subscription Id on message '+s.p)}j=i;i==null&&(j=eG(A));g=pv(b.d,j);s.j=g;s.z=false;return s}catch(a){a=ej(a);if(fe(a,64)){k=a;throw !k?new Gl(VS):fe(k,10)?de(k,10):new Rq(k)}else throw a}}
function ym(){INTERNAL_PROTOTYPE=function(){return 'INTERNAL_PROTOTYPE'};INTERNAL_PEER=function(){return 'INTERNAL_PEER'};var w=Kaazing.JMS;var x=-1;var y=3000;var z=5000;var A=5000;peer=function(a){a.isPeer=INTERNAL_PEER;return a};function B(){throw new Ab('Not implemented','UnsupportOperationException')}
function C(a){return a===INTERNAL_PROTOTYPE||a!==null&&'isPeer' in a&&a.isPeer===INTERNAL_PEER}
function D(a){return a!==null&&(typeof a==XQ||a instanceof String)}
function E(a){return a===null||D(a)}
function F(a){return typeof a==YQ||a instanceof Boolean}
function G(a){return (typeof a==ZQ||a instanceof Number)&&Math.floor(a)===a}
function H(a){return G(a)}
function I(a){return G(a)}
function J(a){return G(a)}
function K(a){return typeof a==ZQ||a instanceof Number}
function L(a){return D(a)&&a.length<=1}
function M(a){return typeof a==SQ}
function N(a){return a===null||typeof a==SQ}
function O(a){return a!==null&&typeof a==$Q}
function P(a){return a===null||O(a)}
function Q(a){return a!==null&&typeof a==$Q&&typeof a.length==ZQ}
function R(a){return a===null||a===undefined}
function S(a){return a instanceof Error}
var T={check:D,type:KQ};var U={check:E,type:'String or null'};var V={check:F,type:_Q};var W={check:G,type:'Number (int)'};var X={check:H,type:'Number (byte)'};var Y={check:I,type:'Number (short)'};var Z={check:J,type:'Number (long)'};var $={check:K,type:aR};var ab=$;var bb=$;var cb={check:L,type:'Char (string of length 1)'};var db={check:M,type:'Function'};var eb={check:N,type:'Function or null'};var fb={check:O,type:bR};var gb={check:P,type:'Object or null'};var hb={check:Q,type:'Array'};var ib={check:S,type:cR};function jb(b,c){return {check:function(a){return G(a)&&b<=a&&a<=c},type:'Number (int in the range '+b+OQ+c+VQ}}
;var kb={check:function(a){return a===null||M(a)||a instanceof w.ExceptionListener},type:'Function or instance of ExceptionListener or null'};var lb={check:function(a){return a===null||M(a)||a instanceof w.MessageListener},type:'Function or instance of MessageListener or null'};var mb={check:function(a){return a!==null&&a instanceof w.Message},type:dR};var nb={check:function(a){return a!==null&&a instanceof w.Destination},type:eR};var ob={check:function(a){return a===null||a instanceof w.Destination},type:eR};var pb={check:function(a){return a!==null||a instanceof w.Topic},type:fR};var qb={check:function(a){return a===w.DeliveryMode.NON_PERSISTENT||a===w.DeliveryMode.PERSISTENT},type:'DeliveryMode.PERSISTENT or DeliveryMode.NON_PERSISTENT'};var rb={check:jb(0,3).check,type:'Session.AUTO_ACKNOWLEDGE, Session.CLIENT_ACKNOWLEDGE, Session.DUPS_OK_ACKNOWLEDGE, or Session.SESSION_TRANSACTED'};var sb=jb(0,9);function tb(a){throw new w.JMSException(a,gR)}
function ub(a,b){tb(hR+a)}
function vb(a,b){var c=Array.prototype.slice.call(arguments,2);c.length!==b.length&&tb(hR+a);for(var d=0;d<b.length;d++){var e=c[d];var f=b[d];!e.check(f)&&tb('Wrong type of argument to '+a+' in parameter '+d+': should be '+e.type)}}
function wb(a,b){var c=b?': Use '+b+' instead':IQ;throw new Error('Client applications should not call constructor for '+a+' directly'+c)}
function xb(a){!D(a)&&tb('Log requires a string parameter');KI(a)}
function yb(a){if(a instanceof Error){return a}else{return Om(a,wm(a),a.C())}}
function zb(b){try{return new cl(b)}catch(a){throw yb(a)}}
function Ab(a,b,c,d){this.message=a;this.type=b||iR;this.errorCode=c;this.linkedException=d}
Ab.prototype=new Error('Unknown JMSException');w.JMSException=Ab;Ab.prototype.getMessage=function(){vb('JMSException.getMessage()',arguments);return this.message};Ab.prototype.getType=function(){vb('JMSException.getType()',arguments);return this.type};Ab.prototype.toString=function(){vb('JMSException.toString()',arguments);return this.type+GQ+this.message};Ab.prototype.getErrorCode=function(){vb('JMSException.getErrorCode()',arguments);return this.errorCode};Ab.prototype.getLinkedException=function(){vb('JMSException.getLinkedException()',arguments);return this.linkedException};Ab.prototype.setLinkedException=function(a){vb('JMSException.setLinkedException()',arguments,ib);this.linkedException=a};function Bb(a){vb('VoidFuture constructor',arguments,eb);this.callback=a}
Bb.prototype.checkError=function(){vb('VoidFuture.checkError()',arguments);if(this.exception!==undefined){throw this.exception}else if(this.value!==null){throw new w.JMSException(jR,kR)}};function Cb(a){vb('ConnectionFuture constructor',arguments,eb);this.callback=a}
Cb.prototype.getValue=function(){vb('ConnectionFuture.getValue()',arguments);if(this.value!==undefined){return this.value}else if(this.exception!==undefined){throw this.exception}else{throw new w.JMSException(jR,kR)}};w.JmsConnectionFactory.init=function(b,c,d,e){var p;vb('JmsConnectionFactory init',arguments,fb,T,gb,fb);if(!b.initialized){try{b.initialized=true;b.location=c;var f=zb(c);b.peer=new RD(f);var g=[];var i=e.connectionTimeout;var j=e.shutdownDelay;var k=e.reconnectDelay;var n=e.reconnectAttemptsMax;R(i)?(i=A):!G(i)&&g.push('connectionTimeout must be an integer');R(j)?(j=z):!G(j)&&g.push('shutdownDelay must be an integer');R(k)?(k=y):!G(k)&&g.push('reconnectDelay must be an integer');R(n)?(n=x):!G(n)&&g.push('reconnectAttemptsMax must be an integer');if(g.length>0){throw new Error(g.join(lR))}var o=(p=new eE,p.b=i,p.e=j,p.d=k,p.c=n,p);b.peer=new SD(f,o);b.peer.be(d)}catch(a){throw yb(a)}}};w.JmsConnectionFactory.createConnection=function(){var k=arguments.length;if(k==4){vb(mR,arguments,fb,U,U,eb);var n=arguments[0];var o=arguments[1];var p=arguments[2];var q=arguments[3];return s(n,o,p,null,q)}else if(k==5){vb(mR,arguments,fb,U,U,U,eb);var n=arguments[0];var o=arguments[1];var p=arguments[2];var r=arguments[3];var q=arguments[4];return s(n,o,p,r,q)}else{ub(nR,arguments)}function s(b,c,d,e,f){try{var g=new Cb(f);var i=new _l(g);var j=mm(b.peer,c,d,e,i);return g}catch(a){throw yb(a)}}};function Db(a){!C(a)&&wb('Connection',nR);this.peer=a}
w.Connection=Db;function Eb(a){!C(a)&&wb('ConnectionMetaData',oR);this.peer=a}
w.ConnectionMetaData=Eb;function Fb(a){!C(a)&&wb('Enumeration');this.peer=a}
Fb.prototype.hasMoreElements=function(){vb('Enumeration.hasMoreElements()',arguments);try{return this.peer.Rd()}catch(a){throw yb(a)}};Fb.prototype.nextElement=function(){vb('Enumeration.nextElement()',arguments);try{return this.peer.Sd()}catch(a){throw yb(a)}};function Gb(a){vb('ExceptionListener constructor',arguments,eb);this.onException=a}
w.ExceptionListener=Gb;Db.prototype.getClientID=function(){vb('Connection.getClientID()',arguments);try{return this.peer.$()}catch(a){throw yb(a)}};Db.prototype.setClientID=function(b){vb('Connection.setClientID()',arguments,T);try{this.peer.ab(b)}catch(a){throw yb(a)}};Db.prototype.getMetaData=function(){vb(oR,arguments);try{var b=this.peer._();return new w.ConnectionMetaData(peer(b))}catch(a){throw yb(a)}};Db.prototype.createConnectionConsumer=B;Db.prototype.createDurableConnectionConsumer=B;Db.prototype.getExceptionListener=function(){vb('Connection.getExceptionListener()',arguments);try{return hm(this.peer)}catch(a){throw yb(a)}};Db.prototype.setExceptionListener=function(b){vb('Connection.setExceptionListener()',arguments,kb);try{var c=M(b)?new w.ExceptionListener(b):b;var d=new em(c);im(this.peer,d)}catch(a){throw yb(a)}};Db.prototype.start=function(b){vb('Connection.start()',arguments,eb);try{var c=new Bb(b);var d=new en(c);var e=jm(this.peer,d);return c}catch(a){throw yb(a)}};Db.prototype.stop=function(b){vb('Connection.stop()',arguments,eb);try{var c=new Bb(b);var d=new en(c);var e=km(this.peer,d);return c}catch(a){throw yb(a)}};Db.prototype.close=function(b){vb('Connection.close()',arguments,eb);try{var c=new Bb(b);var d=new en(c);var e=gm(this.peer,d);return c}catch(a){throw yb(a)}};Db.prototype.createSession=function(b,c){vb(pR,arguments,V,rb);try{var d=nm(this.peer,b,c);return new w.Session(peer(d))}catch(a){throw yb(a)}};Eb.prototype.getJMSVersion=function(){vb('ConnectionMetaData.getJMSVersion()',arguments);try{return this.peer.eb()}catch(a){throw yb(a)}};Eb.prototype.getJMSMajorVersion=function(){vb('ConnectionMetaData.getJMSMajorVersion()',arguments);try{return this.peer.bb()}catch(a){throw yb(a)}};Eb.prototype.getJMSMinorVersion=function(){vb('ConnectionMetaData.getJMSMinorVersion()',arguments);try{return this.peer.cb()}catch(a){throw yb(a)}};Eb.prototype.getJMSProviderName=function(){vb('ConnectionMetaData.getJMSProviderName()',arguments);try{return this.peer.db()}catch(a){throw yb(a)}};Eb.prototype.getProviderVersion=function(){vb('ConnectionMetaData.getProviderVersion()',arguments);try{return this.peer.ib()}catch(a){throw yb(a)}};Eb.prototype.getProviderMajorVersion=function(){vb('ConnectionMetaData.getProviderMajorVersion()',arguments);try{return this.peer.gb()}catch(a){throw yb(a)}};Eb.prototype.getProviderMinorVersion=function(){vb('ConnectionMetaData.getProviderMinorVersion()',arguments);try{return this.peer.hb()}catch(a){throw yb(a)}};Eb.prototype.getJMSXPropertyNames=function(){vb('ConnectionMetaData.getJMSXPropertyNames()',arguments);try{var b=this.peer.fb();return new Fb(peer(b))}catch(a){throw yb(a)}};function Hb(a){if(a===null){return null}else{return fe(a,15)?Tm(de(a,15)):fe(a,14)?Sm(de(a,14)):fe(a,17)?Vm(de(a,17)):fe(a,13)?Rm(de(a,13)):null}}
function Ib(a){!C(a)&&wb('Destination','Session.createTopic(), createQueue(), createTemporaryTopic(), or createTemporaryQueue()');this.peer=a}
w.Destination=Ib;function Jb(a){!C(a)&&wb(fR,qR);this.peer=a}
Jb.prototype=new Ib(INTERNAL_PROTOTYPE);w.Topic=Jb;Jb.prototype.getTopicName=function(){vb('Topic.getTopicName()',arguments);try{return this.peer.Xc()}catch(a){throw yb(a)}};Jb.prototype.toString=function(){vb('Topic.toString()',arguments);return 'Topic '+this.getTopicName()};function Kb(a){!C(a)&&wb('TemporaryTopic','Session.createTemporaryTopic()');this.peer=a}
Kb.prototype=new Jb(INTERNAL_PROTOTYPE);w.TemporaryTopic=Kb;Kb.prototype.deleteTopic=function(){vb('TemporaryTopic.deleteTopic()',arguments);try{this.peer.Uc()}catch(a){throw yb(a)}};function Lb(a){!C(a)&&wb('Queue',rR);this.peer=a}
Lb.prototype=new Ib(INTERNAL_PROTOTYPE);w.Queue=Lb;Lb.prototype.getQueueName=function(){vb('Queue.getQueueName()',arguments);try{return this.peer.Cc()}catch(a){throw yb(a)}};Lb.prototype.toString=function(){vb('Queue.toString()',arguments);return 'Queue '+this.getQueueName()};function Mb(a){!C(a)&&wb('TemporaryQueue','Session.createTemporaryQueue()');this.peer=a}
Mb.prototype=new Lb(INTERNAL_PROTOTYPE);w.TemporaryQueue=Mb;Mb.prototype.deleteQueue=function(){vb('TemporaryQueue.deleteQueue()',arguments);try{this.peer.Uc()}catch(a){throw yb(a)}};w.DeliveryMode={NON_PERSISTENT:1,PERSISTENT:2};function Nb(a){!C(a)&&wb(dR,sR);this.peer=a}
w.Message=Nb;w.Message.DEFAULT_DELIVERY_MODE=w.DeliveryMode.PERSISTENT;w.Message.DEFAULT_PRIORITY=4;w.Message.DEFAULT_TIME_TO_LIVE=Number(0);Nb.prototype.getJMSMessageID=function(){vb('Message.getJMSMessageID()',arguments);try{return this.peer.Ob()}catch(a){throw yb(a)}};Nb.prototype.setJMSMessageID=function(b){vb('Message.setJMSMessageID()',argumnets,U);try{this.peer.hc(b)}catch(a){throw yb(a)}};Nb.prototype.getJMSTimestamp=function(){vb('Message.getJMSTimestamp()',arguments);try{return rm(this.peer)}catch(a){throw yb(a)}};Nb.prototype.setJMSTimestamp=function(b){vb('Message.setJMSTimestamp()',arguments,Z);try{Jm(this.peer,b)}catch(a){throw yb(a)}};Nb.prototype.getJMSCorrelationID=function(){vb('Message.getJMSCorrelationID()',arguments);try{return this.peer.Kb()}catch(a){throw yb(a)}};Nb.prototype.setJMSCorrelationID=function(b){vb('Message.setJMSCorrelationID()',arguments,U);try{this.peer.dc(b)}catch(a){throw yb(a)}};Nb.prototype.getJMSReplyTo=function(){vb('Message.getJMSReplyTo()',arguments);try{var b=this.peer.Rb();return Hb(b)}catch(a){throw yb(a)}};Nb.prototype.setJMSReplyTo=function(b){vb('Message.setJMSReplyTo()',arguments,ob);try{this.peer.kc(b!==null?b.peer:null)}catch(a){throw yb(a)}};Nb.prototype.getJMSDestination=function(){vb('Message.getJMSDestination()',arguments);try{var b=this.peer.Mb();return Hb(b)}catch(a){throw yb(a)}};Nb.prototype.setJMSDestination=function(b){vb('Message.setJMSDestination()',arguments,ob);try{this.peer.fc(b.peer)}catch(a){throw yb(a)}};Nb.prototype.getJMSDeliveryMode=function(){vb('Message.getJMSDeliveryMode()',arguments);try{return this.peer.Lb()}catch(a){throw yb(a)}};Nb.prototype.setJMSDeliveryMode=function(b){vb('Message.setJMSDeliveryMode()',arguments,qb);try{this.peer.ec(b)}catch(a){throw yb(a)}};Nb.prototype.getJMSRedelivered=function(){vb('Message.getJMSRedelivered()',arguments);try{return this.peer.Qb()}catch(a){throw yb(a)}};Nb.prototype.setJMSRedelivered=function(b){vb('Message.setJMSRedelivered()',arguments,V);try{this.peer.jc(b)}catch(a){throw yb(a)}};Nb.prototype.getJMSType=function(){vb('Message.getJMSType()',arguments);try{return this.peer.Tb()}catch(a){throw yb(a)}};Nb.prototype.setJMSType=function(b){vb('Message.setJMSType()',arguments,U);try{this.peer.mc(b)}catch(a){throw yb(a)}};Nb.prototype.getJMSExpiration=function(){vb('Message.getJMSExpiration()',arguments);try{return qm(this.peer)}catch(a){throw yb(a)}};Nb.prototype.setJMSExpiration=function(b){vb('Message.setJMSExpiration()',arguments,Z);try{Im(this.peer,b)}catch(a){throw yb(a)}};Nb.prototype.getJMSPriority=function(){vb('Message.getJMSPriority()',arguments);try{return this.peer.Pb()}catch(a){throw yb(a)}};Nb.prototype.setJMSPriority=function(b){vb('Message.setJMSPriority()',arguments,sb);try{this.peer.ic(b)}catch(a){throw yb(a)}};Nb.prototype.clearProperties=function(){vb('Message.clearProperties()',arguments);try{this.peer.Eb()}catch(a){throw yb(a)}};Nb.prototype.propertyExists=function(b){vb('Message.propertyExists()',arguments,T);try{return this.peer.Zb(b)}catch(a){throw yb(a)}};Nb.prototype.getStringProperty=function(b){vb('Message.getStringProperty()',arguments,T);try{return this.peer.Yb(b)}catch(a){throw yb(a)}};Nb.prototype.setStringProperty=function(b,c){vb('Message.setStringProperty()',arguments,T,U);try{this.peer.qc(b,c)}catch(a){throw yb(a)}};Nb.prototype.getPropertyNames=function(){vb('Message.getPropertyNames()',arguments);try{var b=this.peer.Wb();return new Fb(peer(b))}catch(a){throw yb(a)}};Nb.prototype.acknowledge=function(){vb('Message.acknowledge()',arguments);try{this.peer.Cb()}catch(a){throw yb(a)}};Nb.prototype.clearBody=function(){vb('Message.clearBody()',arguments);try{this.peer.Db()}catch(a){throw yb(a)}};Nb.prototype.getBooleanProperty=function(b){vb('Message.getBooleanProperty()',arguments,T);try{return this.peer.Fb(b)}catch(a){throw yb(a)}};Nb.prototype.getByteProperty=function(b){vb('Message.getByteProperty()',arguments,T);try{return this.peer.Gb(b)}catch(a){throw yb(a)}};Nb.prototype.getShortProperty=function(b){vb('Message.getShortProperty()',arguments,T);try{return this.peer.Xb(b)}catch(a){throw yb(a)}};Nb.prototype.getIntProperty=function(b){vb('Message.getIntProperty()',arguments,T);try{return this.peer.Jb(b)}catch(a){throw yb(a)}};Nb.prototype.getLongProperty=function(b){vb('MapMessage.getLongProperty()',arguments,T);try{return tm(this.peer,b)}catch(a){throw yb(a)}};Nb.prototype.getFloatProperty=function(b){vb('Message.getFloatProperty()',arguments,T);try{return this.peer.Ib(b)}catch(a){throw yb(a)}};Nb.prototype.getDoubleProperty=function(b){vb('Message.getDoubleProperty()',arguments,T);try{return this.peer.Hb(b)}catch(a){throw yb(a)}};Nb.prototype.getObjectProperty=function(b){vb('Message.getObjectProperty()',arguments,T);try{var c=this.peer.Vb(b);if(c==null){return null}else if(zm(c)){if(c){return new Boolean(true)}return new Boolean}else if(Am(c)){return new Number(c)}else if(typeof c==XQ){return new String(c)}else{return c}}catch(a){throw yb(a)}};Nb.prototype.setBooleanProperty=function(b,c){vb('Message.setBooleanProperty()',arguments,T,V);try{this.peer.$b(b,c)}catch(a){throw yb(a)}};Nb.prototype.setByteProperty=function(b,c){vb('Message.setByteProperty()',arguments,T,X);try{this.peer._b(b,c)}catch(a){throw yb(a)}};Nb.prototype.setShortProperty=function(b,c){vb('Message.setShortProperty()',arguments,T,Y);try{this.peer.pc(b,c)}catch(a){throw yb(a)}};Nb.prototype.setIntProperty=function(b,c){vb('Message.setIntProperty()',arguments,T,W);try{this.peer.cc(b,c)}catch(a){throw yb(a)}};Nb.prototype.setLongProperty=function(b,c){vb('Message.setLongProperty()',arguments,T,Z);try{Lm(this.peer,b,c)}catch(a){throw yb(a)}};Nb.prototype.setFloatProperty=function(b,c){vb('Message.setFloatProperty()',arguments,T,ab);try{this.peer.bc(b,c)}catch(a){throw yb(a)}};Nb.prototype.setDoubleProperty=function(b,c){vb('Message.setDoubleProperty()',arguments,T,bb);try{this.peer.ac(b,c)}catch(a){throw yb(a)}};Nb.prototype.setObjectProperty=function(b,c){try{if(!D(b)){tb(tR);return}c===null?this.peer.oc(b,c):F(c)?this.peer.$b(b,c.valueOf()):D(c)?this.peer.qc(b,c):K(c)?this.peer.ac(b,c.valueOf()):tb('value should be either Boolean, Number, String')}catch(a){throw yb(a)}};function Ob(a){!C(a)&&wb('TextMessage',uR);this.peer=a}
Ob.prototype=new Nb(INTERNAL_PROTOTYPE);w.TextMessage=Ob;Ob.prototype.setText=function(b){vb('TextMessage.setText()',arguments,U);try{this.peer.Wc(b)}catch(a){throw yb(a)}};Ob.prototype.getText=function(){vb('TextMessage.getText()',arguments);try{return this.peer.Vc()}catch(a){throw yb(a)}};function Pb(a){!C(a)&&wb('BytesMessage',vR);this.peer=a}
Pb.prototype=new Nb(INTERNAL_PROTOTYPE);w.BytesMessage=Pb;Pb.prototype.getBodyLength=function(){vb('BytesMessage.getBodyLength()',arguments);try{return om(this.peer)}catch(a){throw yb(a)}};Pb.prototype.readBoolean=function(){vb('BytesMessage.readBoolean()',arguments);try{return this.peer.L()}catch(a){throw yb(a)}};Pb.prototype.readByte=function(){vb('BytesMessage.readByte()',arguments);try{return this.peer.M()}catch(a){throw yb(a)}};Pb.prototype.readUnsignedByte=function(){vb('BytesMessage.readUnsignedByte()',arguments);try{return this.peer.R()}catch(a){throw yb(a)}};Pb.prototype.readShort=function(){vb('BytesMessage.readShort()',arguments);try{return this.peer.P()}catch(a){throw yb(a)}};Pb.prototype.readUnsignedShort=function(){vb('BytesMessage.readUnsignedShort()',arguments);try{return this.peer.S()}catch(a){throw yb(a)}};Pb.prototype.readChar=function(){vb('BytesMessage.readChar()',arguments);try{var b=this.peer.N();return String.fromCharCode(b)}catch(a){throw yb(a)}};Pb.prototype.readInt=function(){vb('BytesMessage.readInt()',arguments);try{return this.peer.O()}catch(a){throw yb(a)}};Pb.prototype.readLong=B;Pb.prototype.readFloat=B;Pb.prototype.readDouble=B;Pb.prototype.readUTF=function(){vb('BytesMessage.readUTF()',arguments);try{return this.peer.Q()}catch(a){throw yb(a)}};Pb.prototype.readBytes=function(e,f){var g=arguments.length;if(g==1){vb(wR,arguments,hb);return i(this,e,this.getBodyLength())}else if(g==2){vb(wR,arguments,hb,W);return i(this,e,f)}else{ub(wR,arguments)}function i(b,c,d){try{return Cm(b.peer,c,d)}catch(a){throw yb(a)}}};Pb.prototype.writeBoolean=function(b){vb('BytesMessage.writeBoolean()',arguments,V);try{this.peer.U(b)}catch(a){throw yb(a)}};Pb.prototype.writeByte=function(b){vb('BytesMessage.writeByte()',arguments,X);try{this.peer.V(b)}catch(a){throw yb(a)}};Pb.prototype.writeShort=function(b){vb('BytesMessage.writeShort()',arguments,Y);try{this.peer.Y(b)}catch(a){throw yb(a)}};Pb.prototype.writeChar=function(b){vb('BytesMessage.writeChar()',arguments,cb);try{var c=b.charCodeAt(0);this.peer.W(c)}catch(a){throw yb(a)}};Pb.prototype.writeInt=function(b){vb('BytesMessage.writeInt()',arguments,W);try{this.peer.X(b)}catch(a){throw yb(a)}};Pb.prototype.writeLong=B;Pb.prototype.writeFloat=B;Pb.prototype.writeDouble=B;Pb.prototype.writeUTF=function(b){vb('BytesMessage.writeUTF()',arguments,T);try{this.peer.Z(b)}catch(a){throw yb(a)}};Pb.prototype.writeBytes=function(f,g,i){var j=arguments.length;if(j==1){vb(xR,arguments,hb);return k(this,f,0,f.length)}else if(j==3){vb(xR,arguments,hb,W,W);return k(this,f,g,i)}else{ub(xR,arguments)}function k(b,c,d,e){try{Wm(b.peer,c,d,e)}catch(a){throw yb(a)}}};Pb.prototype.writeObject=B;Pb.prototype.reset=function(){vb('BytesMessage.reset()',arguments);try{this.peer.T()}catch(a){throw yb(a)}};function Qb(a){!C(a)&&wb('MapMessage',yR);this.peer=a}
Qb.prototype=new Nb(INTERNAL_PROTOTYPE);w.MapMessage=Qb;Qb.prototype.getBoolean=function(b){vb('MapMessage.getBoolean()',arguments,T);try{return this.peer.kb(b)}catch(a){throw yb(a)}};Qb.prototype.getByte=function(b){vb('MapMessage.getByte()',arguments,T);try{return this.peer.lb(b)}catch(a){throw yb(a)}};Qb.prototype.getShort=function(b){vb('MapMessage.getShort()',arguments,T);try{return this.peer.qb(b)}catch(a){throw yb(a)}};Qb.prototype.getChar=function(b){vb('MapMessage.getChar()',arguments,T);try{var c=this.peer.mb(b);return String.fromCharCode(c)}catch(a){throw yb(a)}};Qb.prototype.getInt=function(b){vb('MapMessage.getInt()',arguments,T);try{return this.peer.pb(b)}catch(a){throw yb(a)}};Qb.prototype.getLong=function(b){vb('MapMessage.getLong()',arguments,T);try{return sm(this.peer,b)}catch(a){throw yb(a)}};Qb.prototype.getFloat=function(b){vb('MapMessage.getFloat()',arguments,T);try{return this.peer.ob(b)}catch(a){throw yb(a)}};Qb.prototype.getDouble=function(b){vb('MapMessage.getDouble()',arguments,T);try{return this.peer.nb(b)}catch(a){throw yb(a)}};Qb.prototype.getString=function(b){vb('MapMessage.getString()',arguments,T);try{return this.peer.rb(b)}catch(a){throw yb(a)}};Qb.prototype.getBytes=function(b){vb('MapMessage.getBytes()',arguments,T);try{return pm(this.peer,b)}catch(a){throw yb(a)}};Qb.prototype.getObject=function(b){vb('MapMessage.getObject()',arguments,T);try{var c=vm(this.peer,b);if(c==null){return null}else if(zm(c)){if(c){return new Boolean}return new Boolean}else if(Am(c)){return new Number(c)}else if(typeof c==XQ){return new String(c)}else{return c}}catch(a){throw yb(a)}};Qb.prototype.getMapNames=function(){vb('MapMessage.getMapNames()',arguments);try{var b=um(this.peer);var c=new Array;for(var d in b){c.push(String(b[d]))}return c}catch(a){throw yb(a)}};Qb.prototype.setBoolean=function(b,c){vb('MapMessage.setBoolean()',arguments,T,V);try{this.peer.tb(b,c)}catch(a){throw yb(a)}};Qb.prototype.setByte=function(b,c){vb('MapMessage.setByte()',arguments,T,X);try{this.peer.ub(b,c)}catch(a){throw yb(a)}};Qb.prototype.setShort=function(b,c){vb('MapMessage.setShort()',arguments,T,Y);try{this.peer.Ab(b,c)}catch(a){throw yb(a)}};Qb.prototype.setChar=function(b,c){vb('MapMessage.setChar()',arguments,T,cb);try{var d=c.charCodeAt(0);this.peer.vb(b,d)}catch(a){throw yb(a)}};Qb.prototype.setInt=function(b,c){vb('MapMessage.setInt()',arguments,T,W);try{this.peer.yb(b,c)}catch(a){throw yb(a)}};Qb.prototype.setLong=function(b,c){vb('MapMessage.setLong()',arguments,T,Z);try{Km(this.peer,b,c)}catch(a){throw yb(a)}};Qb.prototype.setFloat=function(b,c){vb('MapMessage.setFloat()',arguments,T,ab);try{this.peer.xb(b,c)}catch(a){throw yb(a)}};Qb.prototype.setDouble=function(b,c){vb('MapMessage.setDouble()',arguments,T,bb);try{this.peer.wb(b,c)}catch(a){throw yb(a)}};Qb.prototype.setString=function(b,c){vb('MapMessage.setString()',arguments,T,U);try{this.peer.Bb(b,c)}catch(a){throw yb(a)}};Qb.prototype.setBytes=function(g,i,j,k){var n=arguments.length;if(n==2){vb(zR,arguments,T,hb);o(this,g,i,0,i.length)}else if(n==4){vb(zR,arguments,T,hb,W,W);o(this,g,i,j,k)}else{ub(zR,arguments)}function o(b,c,d,e,f){try{Hm(b.peer,c,d,e,f)}catch(a){throw yb(a)}}};Qb.prototype.setObject=function(b,c){try{if(!D(b)){tb(tR);return}c===null?this.peer.zb(b,c):F(c)?this.peer.tb(b,c.valueOf()):D(c)?this.peer.Bb(b,c):K(c)?this.peer.wb(b,c.valueOf()):Q(c)?Hm(this.peer,b,c,0,c.length):tb('value should be either Boolean, Number, String or Array')}catch(a){throw yb(a)}};Qb.prototype.itemExists=function(b){vb('MapMessage.itemExists()',arguments,T);try{return this.peer.sb(b)}catch(a){throw yb(a)}};function Rb(a){!C(a)&&wb('Session',pR);this.peer=a}
w.Session=Rb;w.Session.AUTO_ACKNOWLEDGE=1;w.Session.CLIENT_ACKNOWLEDGE=2;w.Session.DUPS_OK_ACKNOWLEDGE=3;w.Session.SESSION_TRANSACTED=0;Rb.prototype.createMessage=function(){vb(sR,arguments);try{var b=this.peer.Ic();return new w.Message(peer(b))}catch(a){throw yb(a)}};Rb.prototype.createTextMessage=function(e){var f=arguments.length;if(f==0){return g(this,null)}else if(f==1){vb(uR,arguments,T);return g(this,e)}else{ub(uR,arguments)}function g(b,c){try{var d=b.peer.Nc(c);return new w.TextMessage(peer(d))}catch(a){throw yb(a)}}};Rb.prototype.createBytesMessage=function(){vb(vR,arguments);try{var b=this.peer.Dc();return new w.BytesMessage(peer(b))}catch(a){throw yb(a)}};Rb.prototype.getTransacted=function(){vb('Session.getTransacted()',arguments);try{return this.peer.Qc()}catch(a){throw yb(a)}};Rb.prototype.getAcknowledgeMode=function(){vb('Session.getAcknowledgeMode()',arguments);try{return this.peer.Pc()}catch(a){throw yb(a)}};Rb.prototype.close=function(b){vb('Session.close()',arguments,eb);try{var c=new Bb(b);var d=new nn(c);var e=Em(this.peer,d);return c}catch(a){throw yb(a)}};Rb.prototype.commit=function(b){vb('Session.commit()',arguments,eb);try{var c=new Bb(b);var d=new nn(c);var e=Fm(this.peer,d);return c}catch(a){throw yb(a)}};Rb.prototype.rollback=function(b){vb('Session.rollback()',arguments,eb);xb('session.rollback()');try{var c=new Bb(b);this.peer.Sc();setTimeout(function(){c.callback()},0);return c}catch(a){throw yb(a)}};Rb.prototype.recover=function(){vb('Session.recover()',arguments);xb('session.recover()');try{this.peer.Rc()}catch(a){throw yb(a)}};Rb.prototype.getMessageListener=function(){vb('Session.getMessageListener()',arguments);try{var b=this.peer.sc();return b.b}catch(a){throw yb(a)}};Rb.prototype.setMessageListener=function(b){vb(AR,arguments,lb);var c=M(b)?new w.MessageListener(b):b;try{var d=new $m(c);Gm(this.peer,d)}catch(a){throw yb(a)}};Rb.prototype.run=B;Rb.prototype.createProducer=function(){var e=arguments.length;if(e==0){return g(this,null)}else if(e==1){vb(BR,arguments,ob);var f=arguments[0];return g(this,f)}else{ub(BR,arguments)}function g(b,c){xb('session.createProducer()');try{var d=b.peer.Jc(c?c.peer:null);return new w.MessageProducer(peer(d))}catch(a){throw yb(a)}}};Rb.prototype.createConsumer=function(b,c){if(typeof c==RQ){vb(CR,arguments,nb);xb(DR);try{var d=this.peer.Ec(b.peer);return new w.MessageConsumer(peer(d))}catch(a){throw yb(a)}}else if(typeof c==XQ){vb(CR,arguments,nb,T);xb(DR);try{var d=this.peer.Fc(b.peer,c);return new w.MessageConsumer(peer(d))}catch(a){throw yb(a)}}};Rb.prototype.createQueue=function(b){vb(rR,arguments,T);try{var c=this.peer.Kc(b);return new w.Queue(peer(c))}catch(a){throw yb(a)}};Rb.prototype.createTopic=function(b){vb(qR,arguments,T);try{var c=this.peer.Oc(b);return new w.Topic(peer(c))}catch(a){throw yb(a)}};Rb.prototype.createDurableSubscriber=function(i,j,k,n){var o=arguments.length;if(o==2){vb(ER,arguments,pb,T);return p(this,i,j,null,false)}else if(o==4){vb(ER,arguments,pb,T,T,V);return p(this,i,j,k,n)}else{ub('createDurableSubscriber()',arguments)}function p(b,c,d,e,f){try{var g=b.peer.Gc(c.peer,d,e,f);return new w.TopicSubscriber(peer(g))}catch(a){throw yb(a)}}};Rb.prototype.createTemporaryTopic=function(){vb('Session.createTempoaryTopic()',arguments);try{var b=this.peer.Mc();return new w.TemporaryTopic(peer(b))}catch(a){throw yb(a)}};Rb.prototype.createTemporaryQueue=function(){vb('Session.createTempoaryQueue()',arguments);try{var b=this.peer.Lc();return new w.TemporaryQueue(peer(b))}catch(a){throw yb(a)}};Rb.prototype.unsubscribe=function(b){vb('Session.unsubscribe()',arguments,T);try{this.peer.Tc(b)}catch(a){throw yb(a)}};Rb.prototype.createMapMessage=function(){vb(yR,arguments);try{var b=this.peer.Hc();return new w.MapMessage(peer(b))}catch(a){throw yb(a)}};Rb.prototype.createObjectMessage=B;Rb.prototype.createStreamMessage=B;Rb.prototype.createBrowser=B;function Sb(a){!C(a)&&wb('MessageConsumer',CR);this.peer=a}
w.MessageConsumer=Sb;function Tb(a){!C(a)&&wb('TopicSubscriber',ER);this.peer=a}
w.TopicSubscriber=Tb;Tb.prototype=new Sb(INTERNAL_PROTOTYPE);function Ub(a){vb('MessageListener constructor',arguments,eb);this.onMessage=a}
w.MessageListener=Ub;Sb.prototype.getMessageSelector=function(){vb('MessageConsumer.getMessageSelector()',arguments);try{return this.peer.tc()}catch(a){throw yb(a)}};Sb.prototype.getMessageListener=function(){vb('MessageConsumer.getMessageListener()',arguments);try{var b=this.peer.sc();return b.b}catch(a){throw yb(a)}};Sb.prototype.setMessageListener=function(b){vb(AR,arguments,lb);var c=M(b)?new w.MessageListener(b):b;try{var d=new $m(c);lm(this.peer,d)}catch(a){throw yb(a)}};Sb.prototype.receiveNoWait=function(){vb('MessageConsumer.receiveNoWait()',arguments);try{var b=this.peer.uc();if(b===null){return null}return fe(b,16)?Um(de(b,16)):fe(b,9)?Nm(de(b,9)):fe(b,11)?Qm(de(b,11)):Pm(b)}catch(a){throw yb(a)}};Sb.prototype.receive=B;Sb.prototype.close=function(b){vb('MessageConsumer.close()',arguments,eb);xb(FR);try{var c=new Bb(b);var d=new nn(c);var e=Bm(this.peer,d);return c}catch(a){throw yb(a)}};function Vb(a){!C(a)&&wb('MessageProducer',BR);this.peer=a}
w.MessageProducer=Vb;Vb.prototype.setDeliveryMode=function(b){vb('MessageProducer.setDeliveryMode()',arguments,qb);try{this.peer.Ac(b)}catch(a){throw yb(a)}};Vb.prototype.getDeliveryMode=function(){vb('MessageProducer.getDeliveryMode()',arguments);try{this.peer.xc()}catch(a){throw yb(a)}};Vb.prototype.setPriority=function(b){vb('MessageProducer.setPriority()',arguments,sb);try{this.peer.Bc(b)}catch(a){throw yb(a)}};Vb.prototype.getPriority=function(){vb('MessageProducer.getPriority()',arguments);try{this.peer.zc()}catch(a){throw yb(a)}};Vb.prototype.setTimeToLive=function(b){vb('MessageProducer.setTimeToLive()',arguments,Z);try{Mm(this.peer,b)}catch(a){throw yb(a)}};Vb.prototype.getTimeToLive=function(){vb('MessageProducer.getTimeToLive()',arguments);try{return xm(this.peer)}catch(a){throw yb(a)}};Vb.prototype.getDestination=function(){vb('MessageProducer.getDestination()',arguments);try{this.peer.yc()}catch(a){throw yb(a)}};Vb.prototype.send=function(){var o=arguments.length;if(o==2){vb(GR,arguments,mb,eb);var p=arguments[0];var q=arguments[1];var r=this.peer.xc();var s=this.peer.zc();var t=xm(this.peer);return v(this,null,p,r,s,t,q)}else if(o==3){vb(GR,arguments,ob,mb,eb);var u=arguments[0];var p=arguments[1];var q=arguments[2];var r=this.peer.xc();var s=this.peer.zc();var t=xm(this.peer);return v(this,u,p,r,s,t,q)}else if(o==5){vb(GR,arguments,mb,qb,sb,Z,eb);var p=arguments[0];var r=arguments[1];var s=arguments[2];var t=arguments[3];var q=arguments[4];return v(this,null,p,r,s,t,q)}else if(o==6){vb(GR,arguments,ob,mb,qb,sb,Z,eb);var u=arguments[0];var p=arguments[1];var r=arguments[2];var s=arguments[3];var t=arguments[4];var q=arguments[5];return v(this,u,p,r,s,t,q)}else{ub(GR,arguments)}function v(b,c,d,e,f,g,i){try{var j=new Bb(i);var k=new nn(j);var n=Dm(b.peer,c?c.peer:null,d.peer,e,f,g,k);return j}catch(a){throw yb(a)}}};Vb.prototype.close=function(){vb('MessageProducer.close()',arguments);xb('producer.close()');try{this.peer.wc()}catch(a){throw yb(a)}};Vb.prototype.setDisableMessageID=B;Vb.prototype.getDisableMessageID=function(){vb('MessageProducer.getDisableMessageID()',arguments);return false};Vb.prototype.setDisableMessageTimestamp=B;Vb.prototype.getDisableMessageTimestamp=function(){vb('MessageProducer.getDisableMessageTimestamp()',arguments);return false};function Wb(){}
w.Tracer=Wb;Wb.setTrace=function(a){JI=a}}
var IQ='',HQ='\n',rS=' ',US=' is invalid. It must have been created before the connection got dropped/interrupted. Please re-create the temporary destination.',AS=' received is out of range. The maximum integral value supported in javascript ranges from -9,007,199,254,740,992 (-2^53) to 9,007,199,254,740,992 (2^53).',BS=' which is received as long type is out of range. The maximum integral value supported in javascript ranges from -9,007,199,254,740,992 (-2^53) to 9,007,199,254,740,992 (2^53).',SR='"',jT='", "',VQ=')',lR=', ',OQ='-',WQ='.',HS='/queue/',JS='/remote-temp-queue/',NS='/remote-temp-topic/',IS='/temp-queue/',MS='/temp-topic/',LS='/topic/',NQ='0',nS=':',GQ=': ',oS=';',RR='=',QS='ACK:',UQ='Authentication failed',_Q='Boolean',wR='BytesMessage.readBytes()',xR='BytesMessage.writeBytes()',FS='CRE:',PQ='CSS1Compat',eT='Connection failed without connect future',pR='Connection.createSession()',oR='Connection.getMetaData()',GS='DEL:',eR='Destination or null',cR='Exception',dT='Exception:  ',lT='For input string: "',kT='Illegal leading byte: ',gR='IllegalArgumentException',yT='IllegalStateException',RS='Invalid map entry type',wS='Invalid priority: ',yS='Invalid property type: ',KS='InvalidDestinationException: Unknown destination: ',iR='JMSException',mR='JmsConnectionFactory constructor',nR='JmsConnectionFactory.createConnection()',OR='MAP',tS='MESSAGE_BINARY',uS='MESSAGE_MAP',sS='MESSAGE_TEXT',SS='Map item names cannot be empty or null',zR='MapMessage.setBytes()',dR='Message',GR='MessageProducer.send()',XS='No transactions are in progress',aR='Number',bR='Object',YS='SND:',DS='SUB:',vR='Session.createBytesMessage()',CR='Session.createConsumer()',ER='Session.createDurableSubscriber()',yR='Session.createMapMessage()',sR='Session.createMessage()',BR='Session.createProducer()',rR='Session.createQueue()',uR='Session.createTextMessage()',qR='Session.createTopic()',AR='Session.setMessageListener()',KQ='String',rT='String;',ES='Subscription not found for ID: ',ZS='TXN:',TS='Temporary Destination - ',fR='Topic',WS='Transaction Not Committed: ',PS='UNS:',ET='UmbrellaException',jR='Unfulfilled Future',kR='UnfulfilledFutureException',OS='Unknown destination: ',VS='Unknown exception',zS='Value ',CS='Value is out of range. The maximum integral value supported in javascript ranges from -9,007,199,254,740,992 (-2^53) to 9,007,199,254,740,992 (2^53).',hR='Wrong number of arguments to ',qS='[',AT='[Lcom.kaazing.gateway.jms.client.bump.',pT='[Ljava.lang.',QR=']',iS='ack',YQ='boolean',fT='byte',TQ='bytebuffer',mS='cannot set header [',gT='char',WR='client-id',aS='code',oT='com.google.gwt.core.client.',sT='com.google.gwt.core.client.impl.',DT='com.google.gwt.event.shared.',qT='com.google.gwt.lang.',xT='com.google.gwt.user.client.',CT='com.google.web.bindery.event.shared.',uT='com.kaazing.gateway.client.',wT='com.kaazing.gateway.jms.client.',tT='com.kaazing.gateway.jms.client.bindings.',vT='com.kaazing.gateway.jms.client.bump.',BT='com.kaazing.gateway.jms.client.util.',FR='consumer.close()',dS='correlation-id',IR='destination',$S='dts/',$R='durable-subscriber-name',cS='expires',SQ='function',mT='g',lS='id',PR='indexed item not found for index [',hT='int',MR='items-dictionary',nT='java.lang.',zT='java.util.',_R='keep-alive',XR='login',iT='long',LQ='message',VR='message-id',QQ='msie',tR='name should not be empty or null',jS='no-local',JQ='null',ZQ='number',$Q='object',MQ='opera',YR='passcode',KR='persistent',JR='priority',NR='properties-dictionary',_S='q/',TR='receipt',gS='receipt-id',LR='redelivered',hS='references',eS='reply-to',kS='selector',ZR='session',DR='session.createConsumer() - NOTE: connection must be started to receive messages',XQ='string',HR='subscription',bT='t/',bS='timestamp',aT='tq/',UR='transaction',xS='true',cT='tt/',fS='type',RQ='undefined',pS='{',vS='}';var _,mQ={l:0,m:0,h:1048064},yQ={l:4194175,m:4194303,h:1048575},lQ={l:0,m:0,h:0},zQ={l:128,m:0,h:0},vQ={l:255,m:0,h:0},oQ={l:65535,m:0,h:0},nQ={l:0,m:0,h:512},AQ={l:4194303,m:4194303,h:524287},Vj={},BQ={56:1},uQ={45:1},hQ={77:1},ZP={},pQ={52:1},_P={52:1,74:1},aQ={52:1,64:1,74:1},DQ={78:1},rQ={13:1,24:1,52:1},sQ={17:1,24:1,40:1,52:1},gQ={10:1,52:1,64:1,74:1},qQ={31:1},CQ={80:1},cQ={52:1,70:1},kQ={29:1},tQ={51:1,52:1,70:1},EQ={52:1,80:1},fQ={2:1,52:1},dQ={52:1,53:1,57:1,61:1,70:1,73:1},eQ={6:1},xQ={52:1,76:1},iQ={52:1,77:1},wQ={76:1},$P={52:1,53:1,70:1},jQ={52:1,53:1,61:1,70:1},bQ={8:1,52:1,64:1,74:1};Wj(1,-1,ZP);_.eQ=function Yb(a){return this===a};_.gC=function Zb(){return this.cZ};_.hC=function $b(){return Kc(this)};_.tS=function _b(){return this.cZ.e+'@'+yK(this.hC())};_.toString=function(){return this.tS()};_.tM=VP;Wj(8,1,_P);_.C=function jc(){return this.g};_.tS=function kc(){return hc(this)};_.f=null;_.g=null;_.i=null;Wj(7,8,aQ);Wj(6,7,aQ);Wj(5,6,aQ,oc);_.C=function uc(){this.d==null&&(this.e=rc(this.c),this.b=this.b+GQ+pc(this.c),this.d='('+this.e+') '+tc(this.c)+this.b,undefined);return this.d};_.b=IQ;_.c=null;_.d=null;_.e=null;Wj(14,1,{});var Bc=0,Cc=0,Dc=0,Ec=-1;Wj(16,14,{},Sc);_.b=null;_.c=null;var Oc;Wj(22,1,{});Wj(23,22,{},dd);_.b=IQ;Wj(29,1,{});_.tS=function hd(){return 'An event type'};_.c=null;Wj(28,29,{});_.b=false;Wj(27,28,{},kd);_.D=function ld(a){de(a,3);ik()};_.E=function nd(){return jd};var jd=null;Wj(31,1,{});_.hC=function rd(){return this.b};_.tS=function sd(){return 'Event type'};_.b=0;var qd=0;Wj(30,31,{},td);Wj(32,1,{});_.b=null;_.c=null;Wj(35,1,{});Wj(34,35,{});_.b=null;_.c=0;_.d=false;Wj(33,34,{},Id);Wj(36,1,{},Kd);Wj(38,6,bQ,Nd);_.b=null;Wj(37,38,bQ,Qd);Wj(39,1,{},Rd);_.qI=0;var Yd,Zd;var fj=null;var tj=null;var Nj,Oj,Pj,Qj;Wj(48,1,{5:1},Tj);Wj(53,1,eQ);_.F=function gk(){this.d||wN(_j,this);this.G()};_.d=false;_.e=0;var _j;Wj(54,1,{3:1,4:1},jk);var kk=false,lk=null;Wj(56,28,{},uk);_.D=function vk(a){ke(a);null.ze()};_.E=function wk(){return sk};var sk;Wj(57,32,{},yk);Wj(62,1,{},Ck);Wj(63,1,{7:1},Ek);_.b=null;_.c=null;_.d=null;_.e=null;var Wk;Wj(68,1,{},cl);_.tS=function dl(){return this.b};_.b=null;Wj(69,1,{},kl,ll);_.H=function ml(a){!!this.b&&TG(this.b,new rl(a))};_.I=function nl(){!!this.c&&UG(this.c)};_.J=function ol(a){!!this.d&&VG(this.d,new tl(a))};_.K=function pl(){!!this.e&&WG(this.e)};_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;Wj(70,1,{},rl);_.b=null;Wj(71,1,{},tl);_.b=null;Wj(72,7,aQ,vl);Wj(75,6,aQ,Dl);Wj(77,7,gQ,Gl,Hl);_.C=function Il(){return this.c!=null?this.c:this.b?this.b.C():this.g};_.b=null;_.c=null;Wj(76,77,gQ,Jl);Wj(78,77,gQ,Ll);Wj(79,77,gQ,Nl);Wj(80,77,{10:1,12:1,52:1,64:1,74:1},Pl);Wj(81,77,gQ,Rl);Wj(82,77,gQ,Tl);Wj(83,77,gQ,Vl);Wj(84,77,gQ,Xl);Wj(85,1,{},_l);_.Yc=function am(a){$l(this.b,Om(a,wm(a),a.c!=null?a.c:a.b?a.b.C():a.g))};_.Zc=function bm(a){Zl(this.b,new Kaazing.JMS.Connection(peer(a)))};_.b=null;Wj(86,1,{},em);_.jb=function fm(a){JI&&dH('ExceptionListener.onException');dm(this.b,Om(a,wm(a),a.c!=null?a.c:a.b?a.b.C():a.g))};_.b=null;Wj(88,1,{},$m);_.b=null;Wj(89,1,{},en);_.Yc=function fn(a){bn(this,ke(a))};_.Zc=function gn(a){cn(this,ke(a))};_.b=null;Wj(90,1,{},nn);_.Yc=function on(a){kn(this,a)};_.Zc=function pn(a){ln(this,ke(a))};_.b=null;Wj(91,1,{},wn);_.b=null;Wj(92,77,gQ,Gn,Hn);Wj(93,1,{19:1},xo);_.eQ=function yo(a){var b;if(a==null){return false}b=de(a,19);if(this.e!=b.e){return false}if(!!this.g&&!Eo(this.g,b.g)){return false}if(!this.g&&!!b.g){return false}if(this.e.b.indexOf(sS)!=-1||this.e.b.indexOf(tS)!=-1||this.e==(yq(),rq)||this.e==(yq(),jq)||this.e==(yq(),Np)){if(!!this.b&&this.b!=b.b){return false}if(!this.b&&!!b.b){return false}}if(!!this.o&&!_B(this.o,b.o)){return false}if(!this.o&&!!b.o){return false}if(this.e.b.indexOf(uS)!=-1||this.e==(yq(),lq)){if(!!this.n&&!_B(this.n,b.n)){return false}if(!this.n&&!!b.n){return false}}return true};_.tS=function zo(){return wo(this)};_.b=null;_.c=0;_.d=null;_.e=null;_.f=0;_.g=null;_.i=null;_.j=null;_.k=null;_.n=null;_.o=null;_.p=null;_.q=0;var Jn,Kn,Ln,Mn,Nn,On,Pn,Qn,Rn,Sn,Tn,Un,Vn,Wn,Xn,Yn,Zn,$n,_n,ao,bo,co,eo,fo,go,ho,io,jo,ko;Wj(97,1,hQ);_.$c=function Jo(a){return !!Fo(this,a)};_.eQ=function Ko(a){return Eo(this,a)};_.ad=function Lo(a){var b;b=Fo(this,a);return !b?null:b.ve()};_.hC=function Mo(){var a,b,c;c=0;for(b=this._c().he();b.re();){a=de(b.se(),78);c+=a.hC();c=~~c}return c};_.bd=function No(a,b){throw new aM('Put not supported on this map')};_.cd=function Oo(){return this._c().cd()};_.tS=function Po(){var a,b,c,d;d=pS;a=false;for(c=this._c().he();c.re();){b=de(c.se(),78);a?(d+=lR):(a=true);d+=IQ+b.ue();d+=RR;d+=IQ+b.ve()}return d+vS};Wj(96,97,hQ);_.dd=function ep(){So(this)};_.$c=function fp(a){return a==null?this.g:fe(a,1)?nS+de(a,1) in this.j:Yo(this,a,this.hd(a))};_.ed=function gp(a){if(this.g&&this.fd(this.f,a)){return true}else if(Uo(this,a)){return true}else if(To(this,a)){return true}return false};_._c=function hp(){return new gM(this)};_.gd=function ip(a,b){return this.fd(a,b)};_.ad=function jp(a){return Vo(this,a)};_.bd=function kp(a,b){return Zo(this,a,b)};_.id=function lp(a){return a==null?cp(this):fe(a,1)?dp(this,de(a,1)):bp(this,a,this.hd(a))};_.cd=function mp(){return this.i};_.e=null;_.f=null;_.g=false;_.i=0;_.j=null;Wj(95,96,iQ,np,op,pp);_.fd=function qp(a,b){return ie(a)===ie(b)||a!=null&&wc(a,b)};_.hd=function rp(a){return ~~yc(a)};Wj(94,95,iQ,sp);Wj(99,1,{52:1,60:1,63:1});_.cT=function xp(a){return vp(this,de(a,63))};_.eQ=function yp(a){return this===a};_.hC=function zp(){return Kc(this)};_.tS=function Ap(){return this.b};_.b=null;_.c=0;Wj(98,99,{20:1,52:1,60:1,63:1},zq);var Bp,Cp,Dp,Ep,Fp,Gp,Hp,Ip,Jp,Kp,Lp,Mp,Np,Op,Pp,Qp,Rp,Sp,Tp,Up,Vp,Wp,Xp,Yp,Zp,$p,_p,aq,bq,cq,dq,eq,fq,gq,hq,iq,jq,kq,lq,mq,nq,oq,pq,qq,rq,sq,tq,uq,vq,wq,xq;Wj(100,99,{21:1,52:1,60:1,63:1},Nq);var Cq,Dq,Eq,Fq,Gq,Hq,Iq,Jq,Kq,Lq;Wj(102,77,gQ,Rq);Wj(101,102,gQ,Tq);Wj(103,102,gQ,Vq);Wj(104,102,gQ,Xq,Yq);Wj(106,1,{});_.b=null;_.c=null;_.d=false;_.e=null;Wj(105,106,{},dr);Wj(107,102,gQ,fr);Wj(108,102,gQ,hr);Wj(111,1,{});_.jd=function mr(){return this.A};_.kd=function nr(){return this.B};_.ld=function or(a){this.A=a};_.A=null;_.B=null;Wj(110,111,{},pr);_.tS=function qr(){return 'RECEIPT: '+this.A};Wj(109,110,{22:1},sr);_.b=null;Wj(113,1,kQ);_.nd=function zr(){this.g.nd()};_.od=function Ar(a){wr(this,a)};_.pd=function Br(a){this.g.pd(a)};_.qd=function Cr(a){this.g.qd(a)};_.rd=function Dr(){this.g.rd()};_.sd=function Er(a){this.g.sd(a)};_.td=function Fr(){this.g.td()};_.ud=function Gr(){this.g.ud()};_.e=null;_.f=null;_.g=null;Wj(112,113,kQ,Qr);_.nd=function Rr(){Ir(this)};_.od=function Sr(a){Jr(this,a)};_.pd=function Tr(a){Kr(this,a)};_.qd=function Ur(a){var b,c;for(c=SM(Go(this.b.b));c.b.re();){b=de(YM(c),29);b.qd(a)}};_.rd=function Vr(){Lr(this)};_.sd=function Wr(a){Mr(this,a)};_.td=function Xr(){Nr(this)};_.ud=function Yr(){Or(this)};Wj(115,111,{27:1},ss,ts);_.Cb=function us(){!!this.d&&this.d.md(this)};_.Db=function vs(){this.y=true};_.Eb=function ws(){!!this.r&&sN(this.r.c);this.z=true};_.vd=function xs(){return this.wd()};_.wd=function ys(){return es(this)};_.xd=function zs(){return new ss};_.yd=function As(){!!this.g&&gA(this.g)};_.zd=function Bs(){return Vd(Li,fQ,-1,0,1)};_.Fb=function Cs(a){var b;b=fs(this,a);if(b==null){return false}else if(fe(b,54)){return de(b,54).b}else if(fe(b,1)){return YI(),oL(xS,de(b,1))}else throw new Rl(yS+a)};_.Gb=function Ds(a){var b;b=fs(this,a);if(b==null){return 0}else if(fe(b,55)){return de(b,55).b}else if(fe(b,1)){return hJ(de(b,1),-128,127)<<24>>24}else throw new Rl(yS+a)};_.Hb=function Es(a){var b;b=fs(this,a);if(b==null){return 0}else if(fe(b,62)){return de(b,62).b}else if(fe(b,65)){return de(b,65).b}else if(fe(b,1)){return gJ(de(b,1))}else throw new Rl(yS+a)};_.Ad=function Fs(){return this.n};_.Ib=function Gs(a){var b;b=fs(this,a);if(b==null){return 0}else if(fe(b,65)){return de(b,65).b}else if(fe(b,1)){return fK(de(b,1))}else throw new Rl(yS+a)};_.Jb=function Hs(a){var b;b=fs(this,a);if(b==null){return 0}else if(fe(b,67)){return de(b,67).b}else if(fe(b,71)){return de(b,71).b}else if(fe(b,55)){return de(b,55).b}else if(fe(b,1)){return hJ(de(b,1),-2147483648,2147483647)}else throw new Rl(yS+a)};_.Kb=function Is(){return this.f!=null?this.f:null};_.Lb=function Js(){return this.i};_.Mb=function Ks(){return this.j};_.Bd=function Ls(){return this.j};_.Nb=function Ms(){return this.o};_.Ob=function Ns(){return this.p};_.Pb=function Os(){return this.q};_.Qb=function Ps(){return this.s};_.Rb=function Qs(){return this.t};_.Cd=function Rs(){return this.t};_.Sb=function Ss(){return this.v};_.Tb=function Ts(){return this.x};_.Ub=function Us(a){var b,c;b=fs(this,a);if(b==null){return lQ}else if(fe(b,68)){c=de(b,68).b;tE();if(!(Aj(c,mQ)&&Cj(c,nQ))){throw new Gl(zS+Mj(c)+AS)}return c}else if(fe(b,67)){return yj(de(b,67).b)}else if(fe(b,71)){return yj(de(b,71).b)}else if(fe(b,55)){return yj(de(b,55).b)}else if(fe(b,1)){c=iJ(de(b,1));tE();if(!(Aj(c,mQ)&&Cj(c,nQ))){throw new Gl(zS+Mj(c)+AS)}return c}else throw new Rl(yS+a)};_.Vb=function Vs(a){var b,c;b=fs(this,a);if(fe(b,68)){c=(new FK(iJ(zc(b)))).b;tE();if(!(Aj(c,mQ)&&Cj(c,nQ))){throw new Gl(zS+Mj(c)+BS)}}return b};_.Dd=function Ws(){return this.r};_.Wb=function Xs(){var a;if(!this.r){return YN((XN(),XN(),VN))}a=new IM(this.r.c);return new Dx(a)};_.Ed=function Ys(){return this.u};_.Xb=function Zs(a){var b;b=fs(this,a);if(b==null){return 0}else if(fe(b,71)){return de(b,71).b}else if(fe(b,55)){return de(b,55).b}else if(fe(b,1)){return hJ(de(b,1),-32768,32767)<<16>>16}else throw new Rl(yS+a)};_.Yb=function $s(a){var b;b=fs(this,a);return b==null?null:fe(b,1)?de(b,1):zc(b)};_.Fd=function _s(){return this.w};_.Zb=function at(a){var b,c,d;if(!this.r||a==null){return false}b=rH(a);for(d=new IM(this.r.c);d.c<d.e.cd();){c=de(GM(d),50);if(wH(c.b,b)){return true}}return false};_.Rc=function bt(){!!this.g&&hA(this.g)};_.Gd=function ct(a){this.d=a};_.$b=function dt(a,b){qs(this,a,new $I(b))};_._b=function et(a,b){qs(this,a,new lJ(b))};_.Hd=function ft(a){this.g=a};_.ac=function gt(a,b){qs(this,a,new TJ(b))};_.Id=function ht(a){this.n=a};_.bc=function it(a,b){qs(this,a,new bK(b))};_.cc=function jt(a,b){qs(this,a,new sK(b))};_.dc=function kt(a){this.f=a};_.ec=function lt(a){this.i=a};_.fc=function mt(a){this.j=de(a,24)};_.gc=function nt(a){this.o=a};_.hc=function ot(a){this.p=a};_.ic=function pt(a){ls(this,a)};_.jc=function qt(a){this.s=a};_.kc=function rt(a){this.t=de(a,24)};_.lc=function st(a){this.v=a};_.mc=function tt(a){this.x=a};_.nc=function ut(a,b){tE();if(!(Aj(b,mQ)&&Cj(b,nQ))){throw new jK(CS)}qs(this,a,new FK(b))};_.oc=function vt(a,b){ps(this,a,b)};_.pc=function wt(a,b){qs(this,a,new aL(b))};_.qc=function xt(a,b){qs(this,a,b)};_.Jd=function yt(a){this.w=a};_.Kd=function zt(a){this.y=a};_.tS=function At(){return '[MESSAGE: ['+Mj(this.u)+'] '+this.p+QR};_.d=null;_.e=lQ;_.f=null;_.g=null;_.i=2;_.j=null;_.k=false;_.n=0;_.o=lQ;_.p=null;_.q=4;_.r=null;_.s=false;_.t=null;_.u=lQ;_.v=lQ;_.w=null;_.x=null;_.y=false;_.z=true;var _r,as;Wj(114,115,{9:1,23:1,27:1},Gt,Ht);_.Db=function It(){this.y=true;this.b=new Kaazing.ByteBuffer};_.vd=function Jt(){return Dt(this)};_.wd=function Kt(){return Dt(this)};_.xd=function Lt(){return new Ht(this.d)};_.zd=function Mt(){var a,b;return a=this.y?this.b.position:this.b.limit,b=Vd(Li,fQ,-1,a,1),Fk(this.b,b,0,a),b};_.L=function Nt(){cs(this);if(this.b.remaining()<1){throw new Pl}return this.b.get()!=0};_.M=function Ot(){return Ft(this)};_.N=function Pt(){var a;cs(this);if(this.b.remaining()<2){throw new Pl}a=this.b.getUnsignedShort();return AJ(a)[0]};_.O=function Qt(){cs(this);if(this.b.remaining()<4){throw new Pl}return this.b.getInt()};_.P=function Rt(){cs(this);if(this.b.remaining()<2){throw new Pl}return this.b.getShort()};_.Q=function St(){var a,b,c;cs(this);b=this.b.limit;a=this.b.getUnsignedShort();if(this.b.remaining()<a){throw new Pl}Jk(this.b,this.b.position+a);c=Ik(this.b,Bt);Jk(this.b,b);return c};_.R=function Tt(){var a;cs(this);if(this.b.remaining()<1){throw new Pl}a=this.b.get();return a>=0?a:a+256};_.S=function Ut(){cs(this);if(this.b.remaining()<2){throw new Pl}return this.b.getUnsignedShort()};_.T=function Vt(){this.b.position=0;this.y=false};_.Kd=function Wt(a){this.y&&!a&&this.b.flip();this.y=a};_.U=function Xt(a){ds(this);Lk(this.b,a?1:0)};_.V=function Yt(a){ds(this);Lk(this.b,a)};_.W=function Zt(a){var b;ds(this);b=a<<16>>16;Qk(this.b,b)};_.X=function $t(a){ds(this);Ok(this.b,a)};_.Y=function _t(a){ds(this);Qk(this.b,a)};_.Z=function au(a){var b,c,d;ds(this);if(a.length>16383){d=Et(a);if(zj(d,oQ))throw new jK('The encoded string is longer than 65535 bytes')}c=this.b.position;Kk(this.b,c+2);Sk(this.b,a,Bt);b=this.b.position-c-2;Kk(this.b,c);Tk(this.b,b<<16>>16);Kk(this.b,this.b.position+b)};_.b=null;_.c=0;var Bt;Wj(116,1,kQ,Bu);_.md=function Cu(a){iu(this,a)};_.jb=function Du(a){ju(this,a)};_.nd=function Eu(){Ir(this.k)};_.od=function Fu(a){ku(this,a)};_.pd=function Gu(a){lu(this,a)};_.qd=function Hu(a){nu(this,a)};_.rd=function Iu(){Lr(this.k)};_.sd=function Ju(a){ou(this,a)};_.td=function Ku(){pu(this)};_.ud=function Lu(){qu(this)};_.d=null;_.e=null;_.g=null;_.j=null;_.k=null;_.o=false;Wj(118,1,kQ,Nu);_.nd=function Ou(){};_.od=function Pu(a){};_.pd=function Qu(a){};_.qd=function Ru(a){};_.rd=function Su(){};_.sd=function Tu(a){var b,c,d,e;if(fe(a,43)){c=de(a,43).B;e=de(this.b.p.ad(c),35);if(e.e.c.b.c<=0){this.b.p.id(c);b=e.d;d=b.i;d!=c&&this.b.p.id(d);Au(this.b)}}else{Mr(this.b.k,a)}};_.td=function Uu(){};_.ud=function Vu(){};_.b=null;Wj(119,1,{},Xu);_.b=null;_.c=null;_.d=false;_.e=false;Wj(120,1,{},Zu);_.bb=function $u(){return 1};_.cb=function _u(){return 1};_.db=function av(){return 'Kaazing JMS JavaScript Client Library'};_.eb=function bv(){return '1.1'};_.fb=function cv(){return AI(this.b)};_.gb=function dv(){return 4};_.hb=function ev(){return 1};_.ib=function fv(){return '4.1'};Wj(121,1,{},hv);_.b=null;Wj(122,1,{},jv);_.b=null;Wj(123,1,pQ,qv);var lv;Wj(124,1,{24:1,52:1});_.tS=function sv(){return this.Ld()};Wj(125,1,{},uv);_.b=false;Wj(128,113,kQ);_.Md=function Bv(a){zv(this,a)};_.od=function Cv(a){if(a.d);else this.c.b.c>0&&this.f.Pd(this.d);this.g.od(a)};_.qd=function Dv(a){var b,c,d,e;for(c=new IM(this.c.b);c.c<c.e.cd();){b=de(GM(c),28);d=b.Wd();e=a.vd();d.qd(e)}};_.d=null;Wj(127,128,kQ,Ev);_.md=function Fv(a){};_.qd=function Gv(a){var b,c,d,e;for(c=new IM(this.c.b);c.c<c.e.cd();){b=de(GM(c),28);e=a.vd();d=b.Wd();d.qd(e)}};Wj(126,127,kQ,Hv);_.md=function Iv(a){this.f.md(a)};Wj(129,53,eQ,Kv);_.G=function Lv(){_q(this.b)};_.b=null;Wj(130,53,eQ,Nv);_.G=function Ov(){br(this.c,this.b)};_.b=null;_.c=null;Wj(132,113,kQ);_.md=function Tv(a){};_.Nd=function Uv(){};_.qd=function Vv(a){this.g.qd(a)};_.sd=function Wv(a){this.g.sd(a)};_.Od=function Xv(a){this.f=a};_.Pd=function Yv(a){this.f.Pd(a)};_.Qd=function Zv(a,b,c){this.f.Qd(a,b,c)};_.d=null;Wj(131,132,kQ,aw);_.md=function bw(a){_v(this,a)};_.nd=function cw(){$v(this,false);this.g.nd()};_.pd=function dw(a){var b;b=a.b&&this.d.f!=3;$v(this,b);this.g.pd(a)};_.Nd=function ew(){var a;a=this.d.f!=3;$v(this,a)};_.qd=function fw(a){if(yO(this.b,a.Ob())){KI('Duplicate Message: '+a.Ob()+'. Implicitly ACKing.');_v(this,a)}else{this.g.qd(a)}};_.sd=function gw(a){var b;if(fe(a,22)){b=de(a,22).b;yO(this.c,b)}else{this.g.sd(a)}};_.Od=function hw(a){this.f=a};Wj(133,115,{11:1,25:1,26:1,27:1},sw);_.Db=function tw(){this.y=true;this.b=new np};_.vd=function uw(){return jw(this)};_.wd=function vw(){return jw(this)};_.xd=function ww(){return new sw(this.d)};_.kb=function xw(a){var b;b=lw(this,a);if(b==null){return (YI(),oL(xS,null)?XI:WI).b}else if(fe(b,54)){return de(b,54).b}else if(fe(b,1)){return YI(),oL(xS,de(b,1))}else throw new Rl(RS)};_.lb=function yw(a){var b;b=lw(this,a);if(b==null){return qJ(hJ(null,-128,127)<<24>>24).b}else if(fe(b,55)){return de(b,55).b}else if(fe(b,1)){return hJ(zc(b),-128,127)<<24>>24}else throw new Rl(RS)};_.mb=function zw(a){var b;b=lw(this,a);if(b==null){throw new PK}else if(fe(b,58)){return de(b,58).b}else throw new Rl(RS)};_.nb=function Aw(a){var b;b=lw(this,a);if(b==null){return (new TJ(gJ(null))).b}else if(fe(b,62)){return de(b,62).b}else if(fe(b,65)){return de(b,65).b}else if(fe(b,1)){return gJ(de(b,1))}else throw new Rl(RS)};_.ob=function Bw(a){var b;b=lw(this,a);if(b==null){return (new bK(fK(null))).b}else if(fe(b,65)){return de(b,65).b}else if(fe(b,1)){return fK(de(b,1))}else throw new Rl(RS)};_.pb=function Cw(a){var b;b=lw(this,a);if(b==null){return AK(hJ(null,-2147483648,2147483647)).b}else if(fe(b,67)){return de(b,67).b}else if(fe(b,71)){return de(b,71).b}else if(fe(b,55)){return de(b,55).b}else if(fe(b,1)){return hJ(zc(b),-2147483648,2147483647)}else throw new Rl(RS)};_.qb=function Dw(a){var b;b=lw(this,a);if(b==null){return fL(hJ(null,-32768,32767)<<16>>16).b}else if(fe(b,71)){return de(b,71).b}else if(fe(b,55)){return de(b,55).b}else if(fe(b,1)){return hJ(zc(b),-32768,32767)<<16>>16}else throw new Rl(RS)};_.rb=function Ew(a){var b;b=lw(this,a);if(b==null){return null}else if(fe(b,2)){throw new Rl(RS)}else{return zc(b)}};_.sb=function Fw(a){return this.b.$c(a)};_.tb=function Gw(a,b){pw(this,a,new $I(b))};_.ub=function Hw(a,b){tE();b>=-128&&b<=127||(b=Mk(new Kaazing.ByteBuffer.allocate(0),0,b).get());pw(this,a,new lJ(b))};_.vb=function Iw(a,b){pw(this,a,new vJ(b))};_.wb=function Jw(a,b){pw(this,a,new TJ(b))};_.xb=function Kw(a,b){pw(this,a,new bK(b))};_.yb=function Lw(a,b){tE();b>=-2147483648&&b<=2147483647||(b=Pk(new Kaazing.ByteBuffer.allocate(4),0,b).getInt());pw(this,a,new sK(b))};_.zb=function Mw(a,b){rw(this,a,b)};_.Ab=function Nw(a,b){tE();b>=-32768&&b<=32767||(b=Rk(new Kaazing.ByteBuffer.allocate(2),0,b).getShort());pw(this,a,new aL(b))};_.Bb=function Ow(a,b){pw(this,a,b)};_.b=null;Wj(134,1,{},Qw);_.Rd=function Rw(){return this.b.b.re()};_.Sd=function Sw(){return YM(this.b)};_.b=null;Wj(135,1,{28:1},ax);_.Td=function bx(){qI(this.n.c);qI(this.q.c)};_.rc=function cx(a){return Ww(this,a)};_.Ud=function dx(){return this.f};_.Vd=function ex(){return null};_.sc=function fx(){return this.j};_.Wd=function gx(){return this.k};_.tc=function hx(){return this.o};_.uc=function ix(){return Zw(this)};_.vc=function jx(a){var b;b=this;oy(this.p,new ox(this,b,a))};_.c=0;_.d=null;_.f=null;_.g=null;_.i=null;_.j=null;_.k=null;_.n=null;_.o=null;_.p=null;_.q=null;Wj(136,1,qQ,lx);_.Xd=function mx(b){var c;try{!gH(this.b.n.b);!gH(this.b.q.b)}catch(a){a=ej(a);if(fe(a,64)){c=a;fc(c)}else throw a}fe(this.c,41)||My(this.b.i,this.c);Xw(this.b)};_.b=null;_.c=null;Wj(137,1,qQ,ox);_.Xd=function px(a){this.c.j=this.d;py(this.b.p);while((this.b.n.c.c!=0||this.b.q.c.c!=0)&&this.b.e.b.b==1&&!!this.d){qy(this.b.p,new rx(this,this.d))}};_.b=null;_.c=null;_.d=null;Wj(138,1,qQ,rx);_.Xd=function sx(b){var c,d;if(this.b.b.e.b.b==1&&!!this.c){try{d=$w(this.b.b);!!d&&d.yd()}catch(a){a=ej(a);if(fe(a,64)){c=a;tD(this.b.b.g,!c?new Gl(VS):fe(c,10)?de(c,10):new Rq(c))}else throw a}}};_.b=null;_.c=null;Wj(139,1,qQ,ux);_.Xd=function vx(a){this.b.j?this.d.yd():Uw(this.b,this.d,this.c)};_.b=null;_.c=false;_.d=null;Wj(141,1,{});Wj(140,141,{},Bx);Wj(142,1,{},Dx);_.Rd=function Ex(){return FM(this.b)};_.Sd=function Fx(){var a;return a=de(GM(this.b),50).b,sH(a)};_.b=null;Wj(143,1,{30:1},Nx);_.wc=function Ox(){gH(this.b)||Xy(this.g,this)};_.xc=function Px(){Hx(this);return this.c};_.yc=function Qx(){return Hx(this),this.d};_.zc=function Rx(){Hx(this);return this.e};_.Ac=function Sx(a){Hx(this);this.c=a};_.Bc=function Tx(a){Hx(this);this.e=a};_.c=2;_.d=null;_.e=4;_.f=lQ;_.g=null;_.i=null;Wj(144,1,{},Xx);Wj(145,124,rQ,Zx);_.Ld=function $x(){return this.d};_.Cc=function _x(){return this.d};_.d=null;Wj(146,128,kQ,by);_.Md=function cy(a){var b;b=AH(this.c,a);b<this.b&&--this.b;zv(this,a)};_.md=function dy(a){this.f.md(a)};_.qd=function ey(a){var b,c;++this.b>=this.c.b.c&&(this.b=0);if(this.c.b.c>0){c=de(zH(this.c,this.b),28);b=c.Wd();b.qd(a)}};_.b=-1;Wj(147,145,rQ,gy);Wj(149,124,sQ,jy);_.Ld=function ky(){return this.d};_.Xc=function ly(){return this.d};_.d=null;Wj(148,149,sQ,my);Wj(150,1,{},ry);Wj(151,1,qQ,ty);_.Xd=function uy(a){try{this.c.Xd(a)}finally{py(this.b)}};_.b=null;_.c=null;Wj(152,1,{29:1,32:1},cz);_.Dc=function dz(){return By(this),new Ht(this)};_.Ec=function ez(a){return Ny(this,a,null)};_.Fc=function fz(a,b){return Ny(this,a,b)};_.Gc=function gz(a,b,c,d){return Oy(this,a,b,c)};_.Hc=function hz(){By(this);return new sw(this)};_.Ic=function iz(){return By(this),new ts(this)};_.Jc=function jz(a){return By(this),Cy(a),new Nx(de(a,24),this)};_.Kc=function kz(a){return By(this),nv(a,null)};_.Lc=function lz(){var a;return By(this),a='/temp-queue/q'+xy.b++,de(nv(a,this),37)};_.Mc=function mz(){var a;return By(this),a='/temp-topic/t'+xy.b++,de(ov(a,this),38)};_.Nc=function nz(a){var b;return By(this),b=new BB(this),ds(b),b.b=a,b};_.Oc=function oz(a){return By(this),ov(a,null)};_.Pc=function pz(){By(this);return this.y?0:this.b};_.sc=function qz(){By(this);Dy(this);return this.k};_.Qc=function rz(){By(this);return this.y};_.md=function sz(a){By(this);if(this.b==2){RH(this.o,a)&&Ry(this,a);Ay(this)}else{JI&&dH('Ignoring client acks')}};_.nd=function tz(){};_.od=function uz(a){Yy(this)};_.pd=function vz(a){};_.qd=function wz(a){};_.rd=function xz(){};_.sd=function yz(a){var b,c,d,e;c=a.jd();if(c.indexOf(ZS)==0){e=uL(c,4);d=de(this.A.ad(e),42);!!d&&ck(new Kv(this.e),1)}else if(c.indexOf(YS)==0){b=de(this.q.id(c),30);!!b&&Kx(b)}};_.td=function zz(){yx(this.u,0,1)};_.ud=function Az(){yx(this.u,1,0)};_.Rc=function Bz(){var a;By(this);if(this.y){throw new mK('Cannot recover within transacted sessions')}zx(this.u,0);a=new BN(this.f);rN(a,this.o);qI(this.f);qI(this.o);qy(this.t,new dA(this,a))};_.Sc=function Cz(){By(this);if(!this.y){throw new mK('Attempted to rollback transaction in non-transacted session')}if(!this.z){throw new Gl(XS)}if(this.e){throw new Gl('Transaction commit already in progress')}this.z=null};_.Tc=function Dz(a){var b;By(this);if(a==null){throw new Gl('Illegal Argument: name cannot be empty or null')}b=de(this.x.ad(a),41);if(b){throw new Gl('Cannot unsubscribe while a TopicSubscriber is open')}zu(this.v,a)};_.b=0;_.c=null;_.d=null;_.e=null;_.g=null;_.i=null;_.k=null;_.p=null;_.r=false;_.s=null;_.v=null;_.y=false;_.z=null;var wy,xy,yy;Wj(154,1,kQ,Fz);_.nd=function Gz(){};_.od=function Hz(a){};_.pd=function Iz(a){};_.qd=function Jz(a){Uy(this.c,a,this.b)};_.rd=function Kz(){};_.sd=function Lz(a){};_.td=function Mz(){};_.ud=function Nz(){};_.b=null;_.c=null;Wj(155,1,kQ,Pz);_.nd=function Qz(){};_.od=function Rz(a){};_.pd=function Sz(a){};_.qd=function Tz(a){Uy(this.b,a,this.c)};_.rd=function Uz(){};_.sd=function Vz(a){};_.td=function Wz(){};_.ud=function Xz(){};_.b=null;_.c=null;Wj(156,1,{},_z);_.Yc=function aA(a){Zz(this);kn(this.c,a)};_.Zc=function bA(a){$z(this,ke(a))};_.b=null;_.c=null;_.d=null;Wj(157,1,qQ,dA);_.Xd=function eA(a){var b,c;try{for(c=new IM(this.c);c.c<c.e.cd();){b=de(GM(c),27);b.jc(true);this.b.k?Py(this.b,b):b.Rc()}}finally{zx(this.b.u,1)}};_.b=null;_.c=null;Wj(158,1,{},iA);_.b=null;_.c=null;_.d=null;Wj(159,141,{},kA);Wj(160,1,kQ,AA);_.md=function BA(a){fG(this.b,a)};_.nd=function CA(){Ir(this.c.k)};_.od=function DA(a){rA(this,a)};_.pd=function EA(a){sA(this,a)};_.qd=function FA(a){tA(this,a)};_.rd=function GA(){Lr(this.c.k)};_.sd=function HA(a){uA(this,a)};_.td=function IA(){vA(this)};_.ud=function JA(){wA(this)};_.Pd=function KA(a){var b;b=new NA;b.b=a;JO(this.g,a.g!=null?DS+a.g:DS+WA(a),b);this.f.b.b==2&&pG(this.b,a)};_.Qd=function LA(a,b,c){this.f.b.b==2&&rG(this.b,a);LO(this.g,a.g!=null?DS+a.g:DS+WA(a))};_.b=null;_.c=null;_.e=null;Wj(161,1,{33:1},NA);_.b=null;Wj(162,141,{},PA);Wj(163,110,{34:1},RA);Wj(164,1,{},TA);_.b=null;Wj(165,1,{},YA);_.b=0;_.c=null;_.d=null;_.e=null;_.f=0;_.g=null;_.i=null;_.j=0;var VA=1;Wj(166,1,{29:1,35:1},eB);_.md=function fB(a){this.e.md(a)};_.jb=function gB(a){aB(this,a)};_.nd=function hB(){this.c.nd()};_.od=function iB(a){wr(this.c,a)};_.pd=function jB(a){this.c.pd(a)};_.qd=function kB(a){this.c.qd(a)};_.rd=function lB(){this.c.g.rd()};_.sd=function mB(a){bB(this,a)};_.td=function nB(){this.c.g.td()};_.ud=function oB(){this.c.g.ud()};_.b=null;_.c=null;_.d=null;_.e=null;Wj(167,145,{13:1,14:1,24:1,36:1,37:1,52:1},qB);_.Uc=function rB(){!!this.b&&az(this.b,this)};_.Yd=function sB(){this.c.b=false};_.Zd=function tB(){return this.c.b};_.b=null;Wj(168,149,{15:1,17:1,24:1,36:1,38:1,40:1,52:1},vB);_.Uc=function wB(){!!this.b&&bz(this.b,this)};_.Yd=function xB(){this.c.b=false};_.Zd=function yB(){return this.c.b};_.b=null;Wj(169,115,{16:1,27:1,39:1},BB,CB);_.Db=function DB(){this.y=true;this.b=null};_.vd=function EB(){return es(this)};_.wd=function FB(){return es(this)};_.xd=function GB(){return new CB(this.b,this.d)};_.zd=function HB(){return II(this.b)};_.Vc=function IB(){return this.b};_.Wc=function JB(a){ds(this);this.b=a};_.b=null;Wj(170,132,kQ,LB);Wj(171,135,{18:1,28:1,41:1},NB);_.rc=function OB(a){My(this.i,this);return Ww(this,a)};_.Vd=function PB(){return this.b};_.b=null;Wj(172,1,{42:1},SB);_.c=null;Wj(173,110,{43:1},UB);Wj(175,1,{49:1},cC);_.$d=function dC(a,b,c){return ZB(this,a,b,c)};_._d=function eC(a,b){return $B(this,a,b)};_.ae=function fC(){var a;a=new cC;a.c=new BN(this.c);return a};_.eQ=function gC(a){return _B(this,a)};_.tS=function hC(){return bC(this)};var XB;Wj(174,175,{44:1,49:1},mC);_.$d=function nC(a,b,c){var d;d=this.c.c;return iC(this,d<<24>>24,a,b,c)};_._d=function oC(a,b){var c,d;d=$B(this,a,b);c=this.c.c;this.b.bd(qJ(c<<24>>24),d);return d};_.ae=function pC(){var a;return a=new mC,a.b=new pp(this.b),a.c=new BN(this.c),a};Wj(176,1,{},DC);_.c=null;_.d=null;_.e=null;Wj(177,141,{},FC);Wj(178,1,{},XC);_.jb=function YC(a){JI&&KI('Exception: '+hc(a));tD(this.g,!a?new Gl(VS):a?a:new Rq(null))};_.b=null;_.c=null;_.d=null;_.f=false;_.g=null;_.i=null;_.j=false;_.k=null;_.o=null;_.p=0;_.q=false;_.r=false;Wj(179,53,eQ,$C);_.G=function _C(){HC(this.b)};_.b=null;Wj(180,1,qQ,bD);_.Xd=function cD(b){var c;try{sn(this.b.b,this.c)}catch(a){a=ej(a);if(fe(a,64)){c=a;MC(this.b,c)}else throw a}};_.b=null;_.c=null;Wj(181,53,eQ,eD);_.G=function fD(){var b;try{!!this.b.c&&RG(this.b.c)}catch(a){a=ej(a);if(fe(a,64)){b=a;MC(this.b,b)}else throw a}};_.b=null;
Wj(182,53,eQ,hD);_.G=function iD(){var b;try{IC(this.b)}catch(a){a=ej(a);if(fe(a,64)){b=a;MC(this.b,b)}else throw a}};_.b=null;Wj(183,141,{},kD);Wj(184,1,{},FD);_.$=function GD(){return this.c};_._=function HD(){return this.k};_.jb=function ID(a){tD(this,a)};_.ab=function JD(a){throw new aM("Setting client ID only supported from JmsConnectionFactory's connect() method")};_.b=null;_.c=null;_.d=null;_.e=false;_.f=null;_.g=null;_.i=null;_.j=null;_.k=null;_.n=false;_.p=null;_.q=null;_.r=null;Wj(185,53,eQ,LD);_.G=function MD(){mD(this.b);vA(this.b.q)};_.b=null;Wj(186,53,eQ,OD);_.G=function PD(){mD(this.b);wA(this.b.q)};_.b=null;Wj(187,1,{},RD,SD);_.be=function TD(a){this.e=a;!!a&&this.c.b>0&&wl(a,this.c.b)};_.b=null;_.c=null;_.d=null;_.e=null;Wj(188,1,{},WD);_.b=null;_.c=null;_.d=null;Wj(189,1,{},ZD);_.b=null;Wj(190,1,{},aE);_.Yc=function bE(a){br(this.c,a)};_.Zc=function cE(a){_D(this,ke(a))};_.b=null;_.c=null;Wj(191,1,{},eE);_.b=5000;_.c=-1;_.d=3000;_.e=5000;Wj(192,1,uQ);_.ee=function wE(){return -1};_.tS=function yE(){return this.c};_.b=0;_.c=null;var gE,hE,iE,jE,kE,lE,mE,nE,oE,pE,qE,rE,sE;Wj(193,192,uQ,BE);_.ce=function CE(a){var b;return b=de(a,54).b?49:48,Wd(Li,fQ,-1,[b])};_.de=function DE(a){return AE(a)};_.ee=function EE(){return 1};Wj(194,192,uQ,GE);_.ce=function HE(a){return de(a,2)};_.de=function IE(a){return a};Wj(195,192,uQ,KE);_.ce=function LE(a){return Wd(Li,fQ,-1,[de(a,55).b])};_.de=function ME(a){return new lJ(a[0])};_.ee=function NE(){return 1};Wj(196,192,uQ,PE);_.ce=function QE(a){var b;return b=de(a,58).b,Wd(Li,fQ,-1,[b>>8<<24>>24,b<<24>>24])};_.de=function RE(a){var b,c;return b=a[0],c=a[1],CJ((b<<8|c)&65535)};_.ee=function SE(){return 2};Wj(197,192,uQ,UE);_.ce=function VE(a){return II(IQ+de(a,62).b)};_.de=function WE(a){return new TJ(gJ(Zk(a)))};Wj(198,192,uQ,YE);_.ce=function ZE(a){return II(IQ+de(a,65).b)};_.de=function $E(a){return new bK(fK(Zk(a)))};Wj(199,192,uQ,bF);_.ce=function cF(a){return aF(de(a,67))};_.de=function dF(a){return AK(Kaazing.ByteBuffer.wrap(a).getInt())};_.ee=function eF(){return 4};Wj(200,192,uQ,hF);_.ce=function iF(a){return gF(de(a,68))};_.de=function jF(a){var b;return b=Kaazing.ByteBuffer.wrap(a),KK((qH(),uH(b.get(),b.get(),b.get(),b.get(),b.get(),b.get(),b.get(),b.get())))};_.ee=function kF(){return 8};Wj(201,192,uQ,mF);_.ce=function nF(a){return null};_.de=function oF(a){return null};_.ee=function pF(){return 0};Wj(202,192,uQ,sF);_.ce=function tF(a){return rF(de(a,71))};_.de=function uF(a){return fL(Kaazing.ByteBuffer.wrap(a).getShort())};_.ee=function vF(){return 2};Wj(203,192,uQ,xF);_.ce=function yF(a){return II(de(a,1))};_.de=function zF(a){return Zk(a)};Wj(204,1,{46:1},IF);_.eQ=function JF(a){var b;if(!fe(a,46)){return false}b=de(a,46);return this.b==b.b};_.hC=function KF(){return Kc(this.b)};_.b=null;_.c=null;_.d=null;var BF,CF,DF,EF,FF,GF;Wj(205,99,{47:1,52:1,60:1,63:1},UF);var MF,NF,OF,PF,QF,RF,SF;Wj(206,1,{},tG);_.md=function uG(a){fG(this,a)};_.Pd=function vG(a){pG(this,a)};_.Qd=function wG(a,b,c){rG(this,a)};_.b=null;_.c=false;_.e=null;_.g=true;_.i=false;_.j=null;_.k=null;_.o=null;_.p=null;var XF;Wj(207,1,qQ,yG);_.Xd=function zG(a){var b;this.c.d=null;this.b.r.id(this.d);b=new xo((yq(),wq));oo(b,lS,this.c.b);oo(b,TR,II(PS+this.c.b));sG(this.b,b)};_.b=null;_.c=null;_.d=null;Wj(208,1,qQ,BG);_.Xd=function CG(a){tC(this.b.j,this.c)};_.b=null;_.c=null;Wj(209,1,{48:1},EG);_.b=null;_.c=null;_.d=null;Wj(210,1,{},HG);_.fe=function IG(a,b){return GG(de(a,50),de(b,50))};Wj(211,1,{50:1},NG);_.eQ=function OG(a){return KG(this,a)};_.tS=function PG(){return MG(this)};_.b=null;_.c=null;_.d=null;Wj(212,1,{4:1},YG);_.b=null;_.c=null;_.d=null;_.e=null;_.f=null;Wj(213,102,gQ,$G);Wj(214,102,gQ,aH);Wj(215,106,{},cH);Wj(217,1,{},hH);_.b=false;Wj(218,1,{},nH);_.tS=function oH(){return IQ+this.b};_.b=0;var pH;Wj(220,1,wQ,CH);_.ge=function DH(a){return yH(this,a)};_.he=function EH(){return new IM(this.b)};_.ie=function FH(){return new NM(this.b,0)};_.je=function GH(a){return new NM(this.b,a)};_.cd=function HH(){return this.b.c};_.ke=function IH(){return xN(this.b)};Wj(221,1,{});Wj(226,1,{});_.ge=function VH(a){throw new aM('Add not supported on this collection')};_.le=function WH(a){return PH(this,a)};_.me=function XH(a){return RH(this,a)};_.ke=function YH(){return TH(this)};_.ne=function ZH(a){var b,c,d;d=this.cd();a.length<d&&(a=Td(a,d));c=this.he();for(b=0;b<d;++b){Xd(a,b,c.se())}a.length>d&&Xd(a,d,null);return a};_.tS=function $H(){return UH(this)};Wj(225,226,wQ);_.oe=function _H(a,b){throw new aM('Add not supported on this list')};_.ge=function aI(a){this.oe(this.cd(),a);return true};_.eQ=function cI(a){var b,c,d,e,f;if(a===this){return true}if(!fe(a,76)){return false}f=de(a,76);if(this.cd()!=f.cd()){return false}d=this.he();e=f.he();while(d.re()){b=d.se();c=e.se();if(!(b==null?c==null:wc(b,c))){return false}}return true};_.hC=function dI(){var a,b,c;b=1;a=this.he();while(a.re()){c=a.se();b=31*b+(c==null?0:yc(c));b=~~b}return b};_.he=function fI(){return new IM(this)};_.ie=function gI(){return this.je(0)};_.je=function hI(a){return new NM(this,a)};_.qe=function iI(a){throw new aM('Remove not supported on this list')};Wj(224,225,wQ);_.oe=function kI(a,b){var c;c=this.je(a);pI(c.e,b,c.c);++c.b;c.d=null};_.pe=function lI(b){var c;c=this.je(b);try{return qP(c)}catch(a){a=ej(a);if(fe(a,79)){throw new pK("Can't get element "+b)}else throw a}};_.he=function mI(){return this.je(0)};_.qe=function nI(a){return jI(this,a)};Wj(223,224,xQ,uI);_.ge=function vI(a){return oI(this,a)};_.je=function wI(a){return rI(this,a)};_.cd=function xI(){return this.c};_.b=null;_.c=0;Wj(222,223,xQ,yI);Wj(227,221,{},BI);Wj(228,1,{},DI);_.Rd=function EI(){return this.b<this.c.length};_.Sd=function FI(){return this.c[this.b++]};_.b=0;_.c=null;var GI;var JI=false;Wj(232,7,aQ,QI);Wj(233,6,aQ,SI);Wj(234,6,aQ,UI);Wj(235,1,{52:1,54:1,60:1},$I);_.cT=function _I(a){return ZI(this,de(a,54))};_.eQ=function aJ(a){return fe(a,54)&&de(a,54).b==this.b};_.hC=function bJ(){return this.b?1231:1237};_.tS=function cJ(){return this.b?xS:'false'};_.b=false;var WI,XI;Wj(237,1,{52:1,69:1});var fJ=null;Wj(236,237,{52:1,55:1,60:1,69:1},lJ);_.cT=function mJ(a){return kJ(this,de(a,55))};_.eQ=function nJ(a){return fe(a,55)&&de(a,55).b==this.b};_.hC=function oJ(){return this.b};_.tS=function pJ(){return IQ+this.b};_.b=0;var rJ;Wj(239,1,{52:1,58:1,60:1},vJ);_.cT=function wJ(a){return uJ(this,de(a,58))};_.eQ=function yJ(a){return fe(a,58)&&de(a,58).b==this.b};_.hC=function zJ(){return this.b};_.tS=function BJ(){return FL(this.b)};_.b=0;var DJ;Wj(241,1,{},GJ);_.tS=function OJ(){return ((this.c&2)!=0?'interface ':(this.c&1)!=0?IQ:'class ')+this.e};_.b=null;_.c=0;_.d=0;_.e=null;Wj(242,6,{52:1,59:1,64:1,74:1},QJ);Wj(243,237,{52:1,60:1,62:1,69:1},TJ);_.cT=function VJ(a){return SJ(this,de(a,62))};_.eQ=function WJ(a){return fe(a,62)&&de(a,62).b==this.b};_.hC=function XJ(){return je(this.b)};_.tS=function YJ(){return IQ+this.b};_.b=0;Wj(244,8,_P,$J);Wj(245,237,{52:1,60:1,65:1,69:1},bK);_.cT=function cK(a){return aK(this,de(a,65))};_.eQ=function dK(a){return fe(a,65)&&de(a,65).b==this.b};_.hC=function eK(){return je(this.b)};_.tS=function gK(){return IQ+this.b};_.b=0;Wj(246,6,aQ,iK,jK);Wj(247,6,{52:1,64:1,66:1,74:1},lK,mK);Wj(248,6,aQ,oK,pK);Wj(249,237,{52:1,60:1,67:1,69:1},sK);_.cT=function tK(a){return rK(this,de(a,67))};_.eQ=function uK(a){return fe(a,67)&&de(a,67).b==this.b};_.hC=function vK(){return this.b};_.tS=function zK(){return IQ+this.b};_.b=0;var BK;Wj(251,237,{52:1,60:1,68:1,69:1},FK);_.cT=function GK(a){return EK(this,de(a,68))};_.eQ=function HK(a){return fe(a,68)&&wj(de(a,68).b,this.b)};_.hC=function IK(){return Lj(this.b)};_.tS=function JK(){return IQ+Mj(this.b)};_.b=lQ;var LK;Wj(254,6,aQ,PK,QK);var RK;var TK,UK,VK,WK;Wj(257,246,aQ,ZK);Wj(258,237,{52:1,60:1,69:1,71:1},aL);_.cT=function bL(a){return _K(this,de(a,71))};_.eQ=function cL(a){return fe(a,71)&&de(a,71).b==this.b};_.hC=function dL(){return this.b};_.tS=function eL(){return IQ+this.b};_.b=0;var gL;Wj(260,1,{52:1,72:1},jL);_.tS=function kL(){return this.b+WQ+this.d+'(Unknown Source'+(this.c>=0?nS+this.c:IQ)+VQ};_.b=null;_.c=0;_.d=null;_=String.prototype;_.cM={1:1,52:1,56:1,60:1};_.cT=function AL(a){return BL(this,de(a,1))};_.eQ=function CL(a){return nL(this,a)};_.hC=function EL(){return LL(this)};_.tS=_.toString;var GL,HL=0,IL;Wj(262,1,BQ,QL,RL);_.tS=function SL(){return this.b.b};Wj(263,1,BQ,XL,YL);_.tS=function ZL(){return this.b.b};Wj(265,6,aQ,_L,aM);Wj(267,226,CQ);_.eQ=function dM(a){var b,c,d;if(a===this){return true}if(!fe(a,80)){return false}c=de(a,80);if(c.cd()!=this.cd()){return false}for(b=c.he();b.re();){d=b.se();if(!this.me(d)){return false}}return true};_.hC=function eM(){var a,b,c;a=0;for(b=this.he();b.re();){c=b.se();if(c!=null){a+=yc(c);a=~~a}}return a};Wj(266,267,CQ,gM);_.me=function hM(a){return fM(this,a)};_.he=function iM(){return new lM(this.b)};_.cd=function jM(){return this.b.cd()};_.b=null;Wj(268,1,{},lM);_.re=function mM(){return FM(this.b)};_.se=function nM(){return this.c=de(GM(this.b),78)};_.te=function oM(){if(!this.c){throw new mK('Must call next() before remove().')}else{HM(this.b);this.d.id(this.c.ue());this.c=null}};_.b=null;_.c=null;_.d=null;Wj(270,1,DQ);_.eQ=function rM(a){var b;if(fe(a,78)){b=de(a,78);if(FP(this.ue(),b.ue())&&FP(this.ve(),b.ve())){return true}}return false};_.hC=function sM(){var a,b;a=0;b=0;this.ue()!=null&&(a=yc(this.ue()));this.ve()!=null&&(b=yc(this.ve()));return a^b};_.tS=function uM(){return this.ue()+RR+this.ve()};Wj(269,270,DQ,vM);_.ue=function wM(){return null};_.ve=function xM(){return this.b.f};_.we=function yM(a){return _o(this.b,a)};_.b=null;Wj(271,270,DQ,AM);_.ue=function BM(){return this.b};_.ve=function CM(){return Xo(this.c,this.b)};_.we=function DM(a){return ap(this.c,this.b,a)};_.b=null;_.c=null;Wj(272,1,{},IM);_.re=function JM(){return FM(this)};_.se=function KM(){return GM(this)};_.te=function LM(){HM(this)};_.c=0;_.d=-1;_.e=null;Wj(273,272,{},NM);_.xe=function OM(){return this.c>0};_.ye=function PM(){if(this.c<=0){throw new EP}return this.b.pe(this.d=--this.c)};_.b=null;Wj(274,267,CQ,TM);_.me=function UM(a){return this.b.$c(a)};_.he=function VM(){return SM(this)};_.cd=function WM(){return this.c.cd()};_.b=null;_.c=null;Wj(275,1,{},ZM);_.re=function $M(){return this.b.re()};_.se=function _M(){return YM(this)};_.te=function aN(){this.b.te()};_.b=null;Wj(276,226,{},dN);_.me=function eN(a){return this.b.ed(a)};_.he=function fN(){return cN(this)};_.cd=function gN(){return this.c.cd()};_.b=null;_.c=null;Wj(277,1,{},jN);_.re=function kN(){return this.b.re()};_.se=function lN(){return iN(this)};_.te=function mN(){this.b.te()};_.b=null;Wj(278,225,xQ,zN,AN,BN);_.oe=function CN(a,b){pN(this,a,b)};_.ge=function DN(a){return qN(this,a)};_.le=function EN(a){return rN(this,a)};_.me=function FN(a){return uN(this,a,0)!=-1};_.pe=function GN(a){return tN(this,a)};_.qe=function HN(a){return vN(this,a)};_.cd=function IN(){return this.c};_.ke=function MN(){return xN(this)};_.ne=function NN(a){return yN(this,a)};_.c=0;var VN,WN;Wj(281,1,{},$N);_.Rd=function _N(){return FM(this.b)};_.Sd=function aO(){return GM(this.b)};_.b=null;Wj(282,225,xQ,cO);_.me=function dO(a){return false};_.pe=function eO(a){throw new oK};_.cd=function fO(){return 0};Wj(283,267,EQ,hO);_.me=function iO(a){return false};_.he=function jO(){return new mO};_.cd=function kO(){return 0};Wj(284,1,{},mO);_.re=function nO(){return false};_.se=function oO(){throw new EP};_.te=function pO(){throw new _L};var qO;Wj(286,1,{},tO);_.fe=function uO(a,b){return de(a,60).cT(b)};Wj(287,267,EQ,zO,AO);_.ge=function BO(a){return wO(this,a)};_.me=function CO(a){return this.b.$c(a)};_.he=function DO(){return SM(Go(this.b))};_.cd=function EO(){return this.b.cd()};_.tS=function FO(){return UH(Go(this.b))};_.b=null;Wj(288,95,iQ,MO);_.dd=function NO(){this.d.dd();this.c.c=this.c;this.c.b=this.c};_.$c=function OO(a){return this.d.$c(a)};_.ed=function PO(a){var b;b=this.c.b;while(b!=this.c){if(FP(b.f,a)){return true}b=b.b}return false};_._c=function QO(){return new fP(this)};_.ad=function RO(a){return IO(this,a)};_.bd=function SO(a,b){return JO(this,a,b)};_.id=function TO(a){return LO(this,a)};_.cd=function UO(){return this.d.cd()};_.b=false;Wj(290,270,DQ,YO);_.ue=function ZO(){return this.e};_.ve=function $O(){return this.f};_.we=function _O(a){return XO(this,a)};_.e=null;_.f=null;Wj(289,290,{75:1,78:1},cP,dP);_.b=null;_.c=null;_.d=null;Wj(291,267,CQ,fP);_.me=function gP(a){var b,c,d;if(!fe(a,78)){return false}b=de(a,78);c=b.ue();if(HO(this.b,c)){d=IO(this.b,c);return FP(b.ve(),d)}return false};_.he=function hP(){return new lP(this)};_.cd=function iP(){return this.b.d.cd()};_.b=null;Wj(292,1,{},lP);_.re=function mP(){return this.c!=this.d.b.c};_.se=function nP(){return kP(this)};_.te=function oP(){if(!this.b){throw new mK('No current entry')}bP(this.b);this.d.b.d.id(this.b.e);this.b=null};_.b=null;_.c=null;_.d=null;Wj(293,1,{},tP);_.re=function uP(){return this.c!=this.e.b};_.xe=function vP(){return this.c.c!=this.e.b};_.se=function wP(){return qP(this)};_.ye=function xP(){if(this.c.c==this.e.b){throw new EP}this.d=this.c=this.c.c;--this.b;return this.d.d};_.te=function yP(){rP(this)};_.b=0;_.c=null;_.d=null;_.e=null;Wj(294,1,{},BP,CP);_.b=null;_.c=null;_.d=null;Wj(295,6,{52:1,64:1,74:1,79:1},EP);Wj(297,225,xQ,IP,JP);_.oe=function KP(a,b){pN(this.b,a,b)};_.ge=function LP(a){return qN(this.b,a)};_.le=function MP(a){return rN(this.b,a)};_.me=function NP(a){return uN(this.b,a,0)!=-1};_.pe=function OP(a){return tN(this.b,a)};_.he=function PP(){return new IM(this.b)};_.qe=function QP(a){return vN(this.b,a)};_.cd=function RP(){return this.b.c};_.ke=function SP(){return xN(this.b)};_.ne=function TP(a){return yN(this.b,a)};_.tS=function UP(){return UH(this.b)};_.b=null;var FQ=Hc;var Vh=IJ(nT,bR,1),qe=IJ(oT,'JavaScriptObject$',9),ne=KJ(hT,' I'),Ni=HJ(IQ,'[I',304,ne),$i=HJ(pT,'Object;',302,Vh),ai=IJ(nT,'Throwable',8),Lh=IJ(nT,cR,7),Wh=IJ(nT,'RuntimeException',6),Yh=IJ(nT,'StackTraceElement',260),aj=HJ(pT,'StackTraceElement;',305,Yh),Ce=IJ(qT,'LongLibBase$LongEmul',48),Pi=HJ('[Lcom.google.gwt.lang.','LongLibBase$LongEmul;',306,Ce),De=IJ(qT,'SeedUtil',49),Jh=IJ(nT,'Enum',99),Kh=IJ(nT,'Error',244),Dh=IJ(nT,_Q,235),le=KJ(fT,' B'),Uh=IJ(nT,aR,237),Eh=IJ(nT,'Byte',236),Wi=HJ(pT,'Byte;',307,Eh),me=KJ(gT,' C'),Mi=HJ(IQ,'[C',308,me),oe=KJ(iT,' J'),Oi=HJ(IQ,'[J',309,oe),Fh=IJ(nT,'Character',239),Xi=HJ(pT,'Character;',310,Fh),Hh=IJ(nT,'Class',241),Ih=IJ(nT,'Double',243),Mh=IJ(nT,'Float',245),Qh=IJ(nT,'Integer',249),Yi=HJ(pT,'Integer;',311,Qh),Rh=IJ(nT,'Long',251),Zi=HJ(pT,'Long;',312,Rh),Xh=IJ(nT,'Short',258),_i=HJ(pT,'Short;',313,Xh),_h=IJ(nT,KQ,2),bj=HJ(pT,rT,303,_h),Li=HJ(IQ,'[B',298,le),Gh=IJ(nT,'ClassCastException',242),$h=IJ(nT,'StringBuilder',263),Ch=IJ(nT,'ArrayStoreException',234),pe=IJ(oT,'JavaScriptException',5),Bh=IJ(nT,'ArithmeticException',233),ue=IJ(sT,'StringBufferImpl',22),ef=IJ(tT,'MessageListener',88),Pe=IJ(uT,'URI',68),Sg=IJ(vT,'JmsConnectionFactory',187),Qg=IJ(vT,'JmsConnectionFactory$1',188),Pg=IJ(vT,'JmsConnectionFactory$1$1',189),Rg=IJ(vT,'JmsConnectionFactory$2',190),Xe=IJ(wT,iR,77),Tg=IJ(vT,'JmsConnectionProperties',191),cf=IJ(tT,'ConnectionFutureCallback',85),Lf=IJ(vT,'GenericFuture',106),rf=IJ(vT,'ConnectionFuture',105),Fe=IJ(xT,'Timer',53),Jf=IJ(vT,'GenericFuture$1',129),Kf=IJ(vT,'GenericFuture$3',130),Ee=IJ(xT,'Timer$1',54),df=IJ(tT,'ExceptionListener',86),ff=IJ(tT,'VoidFutureCallback',89),sh=IJ(vT,'VoidFuture',215),gf=IJ(tT,'VoidThrowsJMSExceptionFutureCallback',90),te=IJ(sT,'StringBufferImplAppend',23),re=IJ(oT,'Scheduler',14),se=IJ(sT,'SchedulerImpl',16),Ze=IJ(wT,'MessageEOFException',80),Ah=IJ('java.io.','IOException',232),Sh=IJ(nT,'NullPointerException',254),Nh=IJ(nT,gR,246),Ug=IJ(vT,'JmsConnection',184),Ng=IJ(vT,'JmsConnection$1',185),Og=IJ(vT,'JmsConnection$2',186),kh=IJ(vT,'JmsHandlerImpl',206),jh=IJ(vT,'JmsHandlerImpl$SubscriptionEntry',209),hh=IJ(vT,'JmsHandlerImpl$2',207),ih=IJ(vT,'JmsHandlerImpl$3',208),pg=IJ(vT,'GenericStartStopHandlerImpl',160),ng=IJ(vT,'GenericStartStopHandlerImpl$GenericSubscriptionEntry',161),qh=IJ(vT,'StateMachine',141),og=IJ(vT,'GenericStartStopHandlerImpl$StartStopState',162),zf=IJ(vT,'GenericConcentratorImpl',116),yf=IJ(vT,'GenericConcentratorImpl$2',118),Bf=IJ(vT,'GenericConnectionMetaData',120),Ve=IJ(wT,yT,76),mg=IJ(vT,'GenericSessionImpl',152),lg=IJ(vT,'GenericSessionImpl$SessionState',159),kg=IJ(vT,'GenericSessionImpl$GenericConsumerMessage',158),gg=IJ(vT,'GenericSessionImpl$2',154),hg=IJ(vT,'GenericSessionImpl$3',155),ig=IJ(vT,'GenericSessionImpl$4',156),jg=IJ(vT,'GenericSessionImpl$5',157),ci=IJ(zT,'AbstractCollection',226),si=IJ(zT,'AbstractSet',267),Ai=IJ(zT,'HashSet',287),bi=IJ(nT,'UnsupportedOperationException',265),Oh=IJ(nT,yT,247),fg=IJ(vT,'GenericSemaphoreImpl',150),eg=IJ(vT,'GenericSemaphoreImpl$1',151),qi=IJ(zT,'AbstractMap',97),hi=IJ(zT,'AbstractHashMap',96),zi=IJ(zT,'HashMap',95),ei=IJ(zT,'AbstractHashMap$EntrySet',266),di=IJ(zT,'AbstractHashMap$EntrySetIterator',268),pi=IJ(zT,'AbstractMapEntry',270),fi=IJ(zT,'AbstractHashMap$MapEntryNull',269),gi=IJ(zT,'AbstractHashMap$MapEntryString',271),mi=IJ(zT,'AbstractMap$1',274),li=IJ(zT,'AbstractMap$1$1',275),oi=IJ(zT,'AbstractMap$2',276),ni=IJ(zT,'AbstractMap$2$1',277),Ef=IJ(vT,'GenericDestinationFactory',123),ki=IJ(zT,'AbstractList',225),vi=IJ(zT,'Collections$EmptyList',282),xi=IJ(zT,'Collections$EmptySet',283),wi=IJ(zT,'Collections$EmptySet$1',284),ui=IJ(zT,'Collections$2',281),ii=IJ(zT,'AbstractList$IteratorImpl',272),ji=IJ(zT,'AbstractList$ListIteratorImpl',273),Ei=IJ(zT,'LinkedHashMap',288),Ii=IJ(zT,'MapEntryImpl',290),Bi=IJ(zT,'LinkedHashMap$ChainEntry',289),Di=IJ(zT,'LinkedHashMap$EntrySet',291),Ci=IJ(zT,'LinkedHashMap$EntrySet$EntryIterator',292),ri=IJ(zT,'AbstractSequentialList',224),Hi=IJ(zT,'LinkedList',223),Fi=IJ(zT,'LinkedList$ListIteratorImpl',293),Gi=IJ(zT,'LinkedList$Node',294),Gg=IJ(vT,'JmsChannelFilter',176),Fg=IJ(vT,'JmsChannelFilter$JmsChannelFilterState',177),hf=IJ(vT,'BumpCodecImpl',91),eh=IJ(vT,'JmsDataType',192),Si=HJ(AT,'JmsDataType;',314,eh),Mg=IJ(vT,'JmsChannelImpl',178),Lg=IJ(vT,'JmsChannelImpl$ChannelState',183),Hg=IJ(vT,'JmsChannelImpl$1',179),Ig=IJ(vT,'JmsChannelImpl$2',180),Jg=IJ(vT,'JmsChannelImpl$3',181),Kg=IJ(vT,'JmsChannelImpl$4',182),uh=IJ(BT,'AtomicInteger',218),wh=IJ(BT,'Hashtable',221),zh=IJ(BT,'Properties',227),yh=IJ(BT,'Properties$1',228),ti=IJ(zT,'ArrayList',278),tg=IJ(vT,'GenericSubscriptionMessageProcessor',166),Zh=IJ(nT,'StringBuffer',262),If=IJ(vT,'GenericException',102),th=IJ(BT,'AtomicBoolean',217),Xf=IJ(vT,'GenericMessageProcessorAdapter',113),wf=IJ(vT,'GenericBroadcastHandler',112),Ki=IJ(zT,'Vector',297),qf=IJ(vT,'ConnectionFailedException',104),Ke=IJ(CT,'Event',29),xe=IJ(DT,'GwtEvent',28),Ge=IJ(xT,'Window$ClosingEvent',56),ze=IJ(DT,'HandlerManager',32),He=IJ(xT,'Window$WindowHandlers',57),Ie=IJ(CT,'Event$Type',31),we=IJ(DT,'GwtEvent$Type',30),Je=IJ(CT,'EventBus',35),Ne=IJ(CT,'SimpleEventBus',34),ye=IJ(DT,'HandlerManager$Bus',33),Le=IJ(CT,'SimpleEventBus$1',62),Me=IJ(CT,'SimpleEventBus$2',63),oh=IJ(vT,'JmsWebSocketChannel',212),Te=IJ(uT,'WebSocket',69),Re=IJ(uT,'WebSocket$MessageEvent',71),Qe=IJ(uT,'WebSocket$CloseEvent',70),cj=HJ('[[Ljava.lang.',rT,315,bj),nf=IJ(vT,'BumpFrame',93),lf=JJ(vT,'BumpFrame$FrameCode',98,Aq),Qi=HJ(AT,'BumpFrame$FrameCode;',316,lf),mf=JJ(vT,'BumpFrame$HeaderValueTypes',100,Oq),Ri=HJ(AT,'BumpFrame$HeaderValueTypes;',317,mf),kf=IJ(vT,'BumpFrame$1',94),ve=IJ('com.google.gwt.event.logical.shared.','CloseEvent',27),Ji=IJ(zT,'NoSuchElementException',295),Ph=IJ(nT,'IndexOutOfBoundsException',248),Ue=IJ(wT,'AlreadyFulfilledFutureException',75),vh=IJ(BT,'CopyOnWriteArrayList',220),Cg=IJ(vT,'GenericTransaction',172),vf=IJ(vT,'GenericBaseMessageImpl',111),Wf=IJ(vT,'GenericMessageImpl',115),Of=IJ(vT,'GenericMapMessageImpl',133),Nf=IJ(vT,'GenericMapMessageImpl$1',134),Vf=IJ(vT,'GenericMessageImpl$1',142),bf=IJ(wT,'TransactionRolledBackException',84),ug=IJ(vT,'GenericSubscription',165),Se=IJ(uT,'WebSocketException',72),gh=IJ(vT,'JmsExtension',204),Ui=HJ(AT,'JmsExtension;',318,gh),fh=JJ(vT,'JmsExtension$Kind',205,VF),Ti=HJ(AT,'JmsExtension$Kind;',319,fh),nh=IJ(vT,'JmsPropertiesContent',175),mh=IJ(vT,'JmsPropertiesContent$Property',211),Vi=HJ(AT,'JmsPropertiesContent$Property;',320,mh),lh=IJ(vT,'JmsPropertiesContent$1',210),rg=IJ(vT,'GenericSubscriberDeletion',164),rh=IJ(vT,'TransactionNotCommittedException',214),xf=IJ(vT,'GenericBytesMessageImpl',114),We=IJ(wT,'InvalidDestinationException',78),Yf=IJ(vT,'GenericMessageProducerImpl',143),Uf=IJ(vT,'GenericMessageConsumerImpl',135),Ag=IJ(vT,'GenericTopicSubscriberImpl',171),Tf=IJ(vT,'GenericMessageConsumerImpl$ConsumerState',140),Pf=IJ(vT,'GenericMessageConsumerImpl$1',136),Rf=IJ(vT,'GenericMessageConsumerImpl$2',137),Qf=IJ(vT,'GenericMessageConsumerImpl$2$1',138),Sf=IJ(vT,'GenericMessageConsumerImpl$3',139),xg=IJ(vT,'GenericTextMessageImpl',169),Ae=IJ(DT,'LegacyHandlerWrapper',36),bg=IJ(vT,'GenericRedeliveryHandler',132),Vg=IJ(vT,'JmsDataType$JmsBooleanDataType',193),Xg=IJ(vT,'JmsDataType$JmsByteDataType',195),Wg=IJ(vT,'JmsDataType$JmsByteArrayDataType',194),Yg=IJ(vT,'JmsDataType$JmsCharDataType',196),Zg=IJ(vT,'JmsDataType$JmsDoubleDataType',197),$g=IJ(vT,'JmsDataType$JmsFloatDataType',198),_g=IJ(vT,'JmsDataType$JmsIntegerDataType',199),ah=IJ(vT,'JmsDataType$JmsLongDataType',200),bh=IJ(vT,'JmsDataType$JmsNullDataType',201),ch=IJ(vT,'JmsDataType$JmsShortDataType',202),dh=IJ(vT,'JmsDataType$JmsStringDataType',203),$e=IJ(wT,'MessageFormatException',81),Th=IJ(nT,'NumberFormatException',257),af=IJ(wT,'MessageNotWriteableException',83),Ff=IJ(vT,'GenericDestinationImpl',124),$f=IJ(vT,'GenericQueueImpl',145),vg=IJ(vT,'GenericTemporaryQueueImpl',167),cg=IJ(vT,'GenericRemoteTemporaryQueueImpl',147),yg=IJ(vT,'GenericTopicImpl',149),wg=IJ(vT,'GenericTemporaryTopicImpl',168),dg=IJ(vT,'GenericRemoteTemporaryTopicImpl',148),Zf=IJ(vT,'GenericMessageQueueImpl',144),yi=IJ(zT,'Comparators$1',286),sg=IJ(vT,'GenericSubscriptionHandler',128),_e=IJ(wT,'MessageNotReadableException',82),Cf=IJ(vT,'GenericCreation',121),Oe=IJ(CT,ET,38),Be=IJ(DT,ET,37),Df=IJ(vT,'GenericDeletion',122),_f=IJ(vT,'GenericQueueSubscriptionHandler',146),Mf=IJ(vT,'GenericGuaranteedRedeliveryHandler',131),Bg=IJ(vT,'GenericTopicSubscriptionHandler',127),Hf=IJ(vT,'GenericDurableSubscriptionHandler',126),zg=IJ(vT,'GenericTopicRedeliveryHandler',170),xh=IJ(BT,'LinkedBlockingQueue',222),of=IJ(vT,'ConnectionDisconnectedException',101),pf=IJ(vT,'ConnectionDroppedException',103),ph=IJ(vT,'ReconnectFailedException',213),Eg=IJ(vT,'IndexedPropertiesContent',174),jf=IJ(vT,'BumpException',92),Af=IJ(vT,'GenericConnected',119),Gf=IJ(vT,'GenericDisconnected',125),tf=IJ(vT,'ConnectionRestoredException',108),sf=IJ(vT,'ConnectionInterruptedException',107),Ye=IJ(wT,'JMSSecurityException',79),ag=IJ(vT,'GenericReceiptImpl',110),uf=IJ(vT,'GenericAckReceipt',109),qg=IJ(vT,'GenericSubscribeReceipt',163),Dg=IJ(vT,'GenericUnsubscribeReceipt',173);$stats && $stats({moduleName:'JmsClient',sessionId:$sessionId,subSystem:'startup',evtGroup:'moduleStartup',millis:(new Date()).getTime(),type:'moduleEvalEnd'});if (JmsClient && JmsClient.onScriptLoad)JmsClient.onScriptLoad(gwtOnLoad);})();